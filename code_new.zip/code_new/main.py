import sys
from PyQt5 import QtWidgets
from functions import Parkinson_analyzer
from PyQt5.QtGui import QIcon


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    mainWindow = Parkinson_analyzer()
    mainWindow.show()
    sys.exit(app.exec_())
