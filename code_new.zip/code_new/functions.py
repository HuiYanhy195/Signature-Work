from PyQt5 import QtWidgets
from PyQt5.QtWidgets import  QMessageBox, QFileDialog, QGraphicsView, QGraphicsScene, QGraphicsPixmapItem
from PyQt5.QtGui import QPixmap, QPainter, QFont,  QPen, QImage, QIcon
from PyQt5.QtCore import Qt, QRect
from PyQt5.QtCore import QDate, QRect, Qt
from Ui_analysis import Ui_MainWindow
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from PyQt5.QtPrintSupport import QPrinter
import webbrowser
import tempfile
import os
import csv
import io
import numpy as np
from PIL import Image


class Parkinson_analyzer(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.setWindowIcon(QIcon('logo.jpg'))
        self.ui.setupUi(self)
        
        #drawing parameters
        self.drawing_stroke = 0
        self.drawing_data = []
        self.drawing_test_tag = ''
        
        #rhythm parameters
        self.rhythm_data = []
        self.rhythm_count = 0
        self.rhythm_pixel_to_center = 0
        self.rhythm_count_tag = ''
        self.rhythm_pixel_tag = ''
        
        #staright walking parameters
        self.walking_acc_x = []
        self.walking_acc_y = []
        self.walking_acc_z = []
        self.walking_gyro_x = []
        self.walking_gyro_y = []
        self.walking_gyro_z = []
        self.walking_mag_x = []
        self.walking_mag_y = []
        self.walking_mag_z = []
        self.walking_acc_x_tag = ''
        self.walking_acc_y_tag = ''
        self.walking_acc_z_tag = ''
        self.walking_gyro_x_tag = ''
        self.walking_gyro_y_tag = ''
        self.walking_gyro_z_tag = ''
        self.walking_mag_x_tag = ''
        self.walking_mag_y_tag = ''
        self.walking_mag_z_tag = ''
        
        #postural tremor parameters
        self.postural_tremor_acc_x = []
        self.postural_tremor_acc_y = []
        self.postural_tremor_acc_z = []
        self.postural_tremor_gyro_x = []
        self.postural_tremor_gyro_y = []
        self.postural_tremor_gyro_z = []
        self.postural_tremor_mag_x = []
        self.postural_tremor_mag_y = []
        self.postural_tremor_mag_z = []
        self.postural_tremor_acc_x_tag = ''
        self.postural_tremor_acc_y_tag = ''
        self.postural_tremor_acc_z_tag = ''
        self.postural_tremor_gyro_x_tag = ''
        self.postural_tremor_gyro_y_tag = ''
        self.postural_tremor_gyro_z_tag = ''
        self.postural_tremor_mag_x_tag = ''
        self.postural_tremor_mag_y_tag = ''
        self.postural_tremor_mag_z_tag = ''
        
        #static tremor parameters
        self.static_tremor_acc_x = []
        self.static_tremor_acc_y = []
        self.static_tremor_acc_z = []
        self.static_tremor_gyro_x = []
        self.static_tremor_gyro_y = []
        self.static_tremor_gyro_z = []
        self.static_tremor_mag_x = []
        self.static_tremor_mag_y = []
        self.static_tremor_mag_z = []
        self.static_tremor_acc_x_tag = ''
        self.static_tremor_acc_y_tag = ''
        self.static_tremor_acc_z_tag = ''
        self.static_tremor_gyro_x_tag = ''
        self.static_tremor_gyro_y_tag = ''
        self.static_tremor_gyro_z_tag = ''
        self.static_tremor_mag_x_tag = ''
        self.static_tremor_mag_y_tag = ''
        self.static_tremor_mag_z_tag = ''
        
        #turning parameters
        self.turning_acc_x = []
        self.turning_acc_y = []
        self.turning_acc_z = []
        self.turning_gyro_x = []
        self.turning_gyro_y = []
        self.turning_gyro_z = []
        self.turning_mag_x = []
        self.turning_mag_y = []
        self.turning_mag_z = []
        self.turning_acc_x_tag = ''
        self.turning_acc_y_tag = ''
        self.turning_acc_z_tag = ''
        self.turning_gyro_x_tag = ''
        self.turning_gyro_y_tag = ''
        self.turning_gyro_z_tag = ''
        self.turning_mag_x_tag = ''
        self.turning_mag_y_tag = ''
        self.turning_mag_z_tag = ''
        
        self.drawing_test_clicked = False
        self.rhythm_test_clicked = False
        self.walking_test_clicked = False
        self.tremor_test_clicked = False
        self.turning_test_clicked = False
        


        
        #use basic data of health people as standard of comparison
        #method: divide using quartile formula
        
        #drawing test
        # analyze
        #static  data注释
        # acc（x,y,z） 是手机测定的x y z方向的加速度 表示用户运动的加速情况
        #gyro （x,y,z）是手机测定的x y z方向的回转偏移量 也就是倾斜情况 表示用户身体平衡情况
        #magnetic （x,y,z）是手机测定的x y z方向的磁场位置 也就是用户所在位置距离起点的方向（不一定是测试开始的起点） 表示用户位置
        
        
        
        self.ui.import_Button.clicked.connect(self.import_action)
        self.ui.actionHelp.triggered.connect(self.show_info)
        self.ui.link_button.clicked.connect(self.open_link)
        self.ui.photo_button.clicked.connect(self.get_user_picture)
        self.ui.clear_button.clicked.connect(self.clear_scenes)
        self.ui.drawing_button.clicked.connect(self.analyze_drawing_test)
        self.ui.rhythm_button.clicked.connect(self.analyze_rhythm_test)
        self.ui.walking_button.clicked.connect(self.analyze_walking_test)
        self.ui.tremor_button.clicked.connect(self.analyze_tremor_test)
        self.ui.turning_button.clicked.connect(self.analyze_turning_test)
        self.ui.export_button.clicked.connect(self.export_pdf)
        self.ui.actionImport_User_Info.triggered.connect(self.import_user_info)
    
    def reset_variables(self):
        self.drawing_stroke = 0
        self.drawing_data = []
        self.drawing_test_tag = ''
        
        #rhythm parameters
        self.rhythm_data = []
        self.rhythm_count = 0
        self.rhythm_pixel_to_center = 0
        self.rhythm_count_tag = ''
        self.rhythm_pixel_tag = ''
        
        #staright walking parameters
        self.walking_acc_x = []
        self.walking_acc_y = []
        self.walking_acc_z = []
        self.walking_gyro_x = []
        self.walking_gyro_y = []
        self.walking_gyro_z = []
        self.walking_mag_x = []
        self.walking_mag_y = []
        self.walking_mag_z = []
        self.walking_acc_x_tag = ''
        self.walking_acc_y_tag = ''
        self.walking_acc_z_tag = ''
        self.walking_gyro_x_tag = ''
        self.walking_gyro_y_tag = ''
        self.walking_gyro_z_tag = ''
        self.walking_mag_x_tag = ''
        self.walking_mag_y_tag = ''
        self.walking_mag_z_tag = ''
        
        #postural tremor parameters
        self.postural_tremor_acc_x = []
        self.postural_tremor_acc_y = []
        self.postural_tremor_acc_z = []
        self.postural_tremor_gyro_x = []
        self.postural_tremor_gyro_y = []
        self.postural_tremor_gyro_z = []
        self.postural_tremor_mag_x = []
        self.postural_tremor_mag_y = []
        self.postural_tremor_mag_z = []
        self.postural_tremor_acc_x_tag = ''
        self.postural_tremor_acc_y_tag = ''
        self.postural_tremor_acc_z_tag = ''
        self.postural_tremor_gyro_x_tag = ''
        self.postural_tremor_gyro_y_tag = ''
        self.postural_tremor_gyro_z_tag = ''
        self.postural_tremor_mag_x_tag = ''
        self.postural_tremor_mag_y_tag = ''
        self.postural_tremor_mag_z_tag = ''
        
        #static tremor parameters
        self.static_tremor_acc_x = []
        self.static_tremor_acc_y = []
        self.static_tremor_acc_z = []
        self.static_tremor_gyro_x = []
        self.static_tremor_gyro_y = []
        self.static_tremor_gyro_z = []
        self.static_tremor_mag_x = []
        self.static_tremor_mag_y = []
        self.static_tremor_mag_z = []
        self.static_tremor_acc_x_tag = ''
        self.static_tremor_acc_y_tag = ''
        self.static_tremor_acc_z_tag = ''
        self.static_tremor_gyro_x_tag = ''
        self.static_tremor_gyro_y_tag = ''
        self.static_tremor_gyro_z_tag = ''
        self.static_tremor_mag_x_tag = ''
        self.static_tremor_mag_y_tag = ''
        self.static_tremor_mag_z_tag = ''
        
        #turning parameters
        self.turning_acc_x = []
        self.turning_acc_y = []
        self.turning_acc_z = []
        self.turning_gyro_x = []
        self.turning_gyro_y = []
        self.turning_gyro_z = []
        self.turning_mag_x = []
        self.turning_mag_y = []
        self.turning_mag_z = []
        self.turning_acc_x_tag = ''
        self.turning_acc_y_tag = ''
        self.turning_acc_z_tag = ''
        self.turning_gyro_x_tag = ''
        self.turning_gyro_y_tag = ''
        self.turning_gyro_z_tag = ''
        self.turning_mag_x_tag = ''
        self.turning_mag_y_tag = ''
        self.turning_mag_z_tag = ''
        
        self.drawing_test_clicked = False
        self.rhythm_test_clicked = False
        self.walking_test_clicked = False
        self.tremor_test_clicked = False
        self.turning_test_clicked = False


    def import_user_info(self):
        filename, _ = QFileDialog.getOpenFileName(filter="TXT Files (*.txt)")
        # 打开并读取CSV文件
        if filename:
            with open(filename, mode='r', encoding='utf-8') as txt_file:
                for line in txt_file:
                    if line.startswith("Name="):
                        name = line.split('=')[1].strip()
                        self.ui.name_lineEdit.setText(name)
                    if line.startswith("Age="):
                        age = line.split('=')[1].strip()
                        self.ui.age_lineEdit.setText(age)
                    if line.startswith("Address="):
                        address = line.split('=')[1].strip()
                        self.ui.address_lineEdit.setText(address)
                    if line.startswith("Medicine1="):
                        medicine1 = line.split('=')[1].strip()
                        self.ui.medicine1_lineEdit.setText(medicine1)
                    if line.startswith("Dosage1="):
                        dosage1 = line.split('=')[1].strip()
                        self.ui.dosage1_lineEdit.setText(dosage1)
                    if line.startswith("Medicine2="):
                        medicine2 = line.split('=')[1].strip()
                        self.ui.medicine2_lineEdit.setText(medicine2)
                    if line.startswith("Dosage2="):
                        dosage2 = line.split('=')[1].strip()
                        self.ui.dosage2_lineEdit.setText(dosage2)
                    if line.startswith("Medicine3="):
                        medicine3 = line.split('=')[1].strip()
                        self.ui.medicine3_lineEdit.setText(medicine3)
                    if line.startswith("Dosage3="):
                        dosage3 = line.split('=')[1].strip()
                        self.ui.dosage3_lineEdit.setText(dosage3)
        else:
            QMessageBox.information(self, "warning", "No TXT file chosen！‌")
            

    def import_action(self):
        self.reset_variables()
        folder_path = QtWidgets.QFileDialog.getExistingDirectory(None, "Choose folder", "")
        self.folderpath = folder_path
        # 打印用户选择的文件夹路径
        if folder_path:
            self.ui.folderpath_label.setText(folder_path)
            self.treat_data(folder_path)
        else:
            QMessageBox.information(self, "warning", "No folder chosen！‌")
            self.ui.folderpath_label.setText('')
            self.ui.drawing_button.setDisabled(True)
            self.ui.rhythm_button.setDisabled(True)
            self.ui.walking_button.setDisabled(True)
            self.ui.tremor_button.setDisabled(True)
            self.ui.turning_button.setDisabled(True)
            self.ui.export_button.setDisabled(True)
            
        
    def treat_data(self, path):
        for filename in os.listdir(path):
            
            # 处理Drawing Test
            if filename == 'Drawing Test.csv':
                # 拼接完整的文件路径
                file_path = os.path.join(path, filename)
                # 打开并读取CSV文件
                with open(file_path, mode='r', encoding='utf-8') as csv_file:
                    csv_reader = csv.reader(csv_file)
                    # 迭代CSV文件中的每一行
                    for row in csv_reader:
                        self.drawing_data.append(row[0])  
                self.drawing_stroke = int(self.drawing_data[1])
                
            # 处理Rhythm Test
            if filename == 'Rhythm Test.csv':
                file_path = os.path.join(path, filename)
                # 打开并读取CSV文件
                with open(file_path, mode='r', encoding='utf-8') as csv_file:
                    csv_reader = csv.reader(csv_file)
                    next(csv_reader)
                    # 迭代CSV文件中的每一行
                    for row in csv_reader:
                        if len(row) >= 6:
                            self.rhythm_data.append(round(float(row[5]), 3))  
                self.rhythm_count = len(self.rhythm_data)
                rhythm_data_sum = 0
                for i in range(len(self.rhythm_data)):
                    rhythm_data_sum += self.rhythm_data[i]
                self.rhythm_pixel_to_center = round(rhythm_data_sum / self.rhythm_count, 3)
                
                #处理Walking Test
            if filename == 'Straight Walking Test.csv':
                file_path = os.path.join(path, filename)
                # 打开并读取CSV文件
                with open(file_path, mode='r', encoding='utf-8') as csv_file:
                    csv_reader = csv.reader(csv_file)
                    next(csv_reader)
                    # 迭代CSV文件中的每一行
                    for row in csv_reader:
                        if len(row) >= 10:
                            #处理acc
                            self.walking_acc_x.append(round(float(row[1]), 3))  
                            self.walking_acc_y.append(round(float(row[2]), 3))  
                            self.walking_acc_z.append(round(float(row[3]), 3))  
                            #处理gyro
                            self.walking_gyro_x.append(round(float(row[4]), 3))  
                            self.walking_gyro_y.append(round(float(row[5]), 3))  
                            self.walking_gyro_z.append(round(float(row[6]), 3)) 
                            #处理magnetic
                            self.walking_mag_x.append(round(float(row[7]), 3))  
                            self.walking_mag_y.append(round(float(row[8]), 3))  
                            self.walking_mag_z.append(round(float(row[9]), 3)) 
                            
                walking_acc_x_sum = 0
                for i in self.walking_acc_x:
                    walking_acc_x_sum += i
                self.walking_acc_x_avg = round(walking_acc_x_sum / len(self.walking_acc_x), 4)
                walking_acc_y_sum = 0
                for i in self.walking_acc_y:
                    walking_acc_y_sum += i
                self.walking_acc_y_avg = round(walking_acc_y_sum / len(self.walking_acc_y), 4)
                walking_acc_z_sum = 0
                for i in self.walking_acc_z:
                    walking_acc_z_sum += i
                self.walking_acc_z_avg = round(walking_acc_z_sum / len(self.walking_acc_z), 4)
                
                walking_gyro_x_sum = 0
                for i in self.walking_gyro_x:
                    walking_gyro_x_sum += i
                self.walking_gyro_x_avg = round(walking_gyro_x_sum / len(self.walking_gyro_x), 4)
                walking_gyro_y_sum = 0
                for i in self.walking_gyro_y:
                    walking_gyro_y_sum += i
                self.walking_gyro_y_avg = round(walking_gyro_y_sum / len(self.walking_gyro_y), 4)
                walking_gyro_z_sum = 0
                for i in self.walking_gyro_z:
                    walking_gyro_z_sum += i
                self.walking_gyro_z_avg = round(walking_gyro_z_sum / len(self.walking_gyro_z), 4)
                
                walking_mag_data_x = [0 for i in range(len(self.walking_mag_x)-1)]  
                for i in range( len(self.walking_mag_x)-1):
                    walking_mag_data_x[i] = abs(self.walking_mag_x[i+1] - self.walking_mag_x[i])
                self.walking_mag_x_max = round(max(walking_mag_data_x), 4)
                walking_mag_data_y = [0 for i in range(len(self.walking_mag_y)-1)]  
                for i in range( len(self.walking_mag_y)-1):
                    walking_mag_data_y[i] = abs(self.walking_mag_y[i+1] - self.walking_mag_y[i])
                self.walking_mag_y_max = round(max(walking_mag_data_y), 4)
                walking_mag_data_z = [0 for i in range(len(self.walking_mag_z)-1)]  
                for i in range( len(self.walking_mag_z)-1):
                    walking_mag_data_z[i] = abs(self.walking_mag_z[i+1] - self.walking_mag_z[i])
                self.walking_mag_z_max = round(max(walking_mag_data_z), 4)
                
            if filename == 'Postural Tremor Test.csv':
                file_path = os.path.join(path, filename)
                # 打开并读取CSV文件
                with open(file_path, mode='r', encoding='utf-8') as csv_file:
                    csv_reader = csv.reader(csv_file)
                    next(csv_reader)
                    # 迭代CSV文件中的每一行
                    for row in csv_reader:
                        if len(row) >= 10:
                            #处理acc
                            self.postural_tremor_acc_x.append(round(float(row[1]), 3))  
                            self.postural_tremor_acc_y.append(round(float(row[2]), 3))  
                            self.postural_tremor_acc_z.append(round(float(row[3]), 3))  
                            #处理gyro
                            self.postural_tremor_gyro_x.append(round(float(row[4]), 3))  
                            self.postural_tremor_gyro_y.append(round(float(row[5]), 3))  
                            self.postural_tremor_gyro_z.append(round(float(row[6]), 3)) 
                            #处理magnetic
                            self.postural_tremor_mag_x.append(round(float(row[7]), 3))  
                            self.postural_tremor_mag_y.append(round(float(row[8]), 3))  
                            self.postural_tremor_mag_z.append(round(float(row[9]), 3)) 
                            
                postural_tremor_acc_x_sum = 0
                for i in self.postural_tremor_acc_x:
                    postural_tremor_acc_x_sum += i
                self.postural_tremor_acc_x_avg = round(postural_tremor_acc_x_sum / len(self.postural_tremor_acc_x), 4)
                postural_tremor_acc_y_sum = 0
                for i in self.postural_tremor_acc_y:
                    postural_tremor_acc_y_sum += i
                self.postural_tremor_acc_y_avg = round(postural_tremor_acc_y_sum / len(self.postural_tremor_acc_y), 4)
                postural_tremor_acc_z_sum = 0
                for i in self.postural_tremor_acc_z:
                    postural_tremor_acc_z_sum += i
                self.postural_tremor_acc_z_avg = round(postural_tremor_acc_z_sum / len(self.postural_tremor_acc_z), 4)
                
                postural_tremor_gyro_x_sum = 0
                for i in self.postural_tremor_gyro_x:
                    postural_tremor_gyro_x_sum += i
                self.postural_tremor_gyro_x_avg = round(postural_tremor_gyro_x_sum / len(self.postural_tremor_gyro_x), 4)
                postural_tremor_gyro_y_sum = 0
                for i in self.postural_tremor_gyro_y:
                    postural_tremor_gyro_y_sum += i
                self.postural_tremor_gyro_y_avg = round(postural_tremor_gyro_y_sum / len(self.postural_tremor_gyro_y), 4)
                postural_tremor_gyro_z_sum = 0
                for i in self.postural_tremor_gyro_z:
                    postural_tremor_gyro_z_sum += i
                self.postural_tremor_gyro_z_avg = round(postural_tremor_gyro_z_sum / len(self.postural_tremor_gyro_z), 4)
                
                postural_tremor_mag_data_x = [0 for i in range(len(self.postural_tremor_mag_x)-1)]  
                for i in range( len(self.postural_tremor_mag_x)-1):
                    postural_tremor_mag_data_x[i] = abs(self.postural_tremor_mag_x[i+1] - self.postural_tremor_mag_x[i])
                self.postural_tremor_mag_x_max = round(max(postural_tremor_mag_data_x), 4)
                postural_tremor_mag_data_y = [0 for i in range(len(self.postural_tremor_mag_y)-1)]  
                for i in range( len(self.postural_tremor_mag_y)-1):
                    postural_tremor_mag_data_y[i] = abs(self.postural_tremor_mag_y[i+1] - self.postural_tremor_mag_y[i])
                self.postural_tremor_mag_y_max = round(max(postural_tremor_mag_data_y), 4)
                postural_tremor_mag_data_z = [0 for i in range(len(self.postural_tremor_mag_z)-1)]  
                for i in range( len(self.postural_tremor_mag_z)-1):
                    postural_tremor_mag_data_z[i] = abs(self.postural_tremor_mag_z[i+1] - self.postural_tremor_mag_z[i])
                self.postural_tremor_mag_z_max = round(max(postural_tremor_mag_data_z), 4)
                
            if filename == 'Static Tremor Test.csv':
                file_path = os.path.join(path, filename)
                # 打开并读取CSV文件
                with open(file_path, mode='r', encoding='utf-8') as csv_file:
                    csv_reader = csv.reader(csv_file)
                    next(csv_reader)
                    # 迭代CSV文件中的每一行
                    for row in csv_reader:
                        if len(row) >= 10:
                            #处理acc
                            self.static_tremor_acc_x.append(round(float(row[1]), 3))  
                            self.static_tremor_acc_y.append(round(float(row[2]), 3))  
                            self.static_tremor_acc_z.append(round(float(row[3]), 3))  
                            #处理gyro
                            self.static_tremor_gyro_x.append(round(float(row[4]), 3))  
                            self.static_tremor_gyro_y.append(round(float(row[5]), 3))  
                            self.static_tremor_gyro_z.append(round(float(row[6]), 3)) 
                            #处理magnetic
                            self.static_tremor_mag_x.append(round(float(row[7]), 3))  
                            self.static_tremor_mag_y.append(round(float(row[8]), 3))  
                            self.static_tremor_mag_z.append(round(float(row[9]), 3)) 
                            
                static_tremor_acc_x_sum = 0
                for i in self.static_tremor_acc_x:
                    static_tremor_acc_x_sum += i
                self.static_tremor_acc_x_avg = round(static_tremor_acc_x_sum / len(self.static_tremor_acc_x), 4)
                static_tremor_acc_y_sum = 0
                for i in self.static_tremor_acc_y:
                    static_tremor_acc_y_sum += i
                self.static_tremor_acc_y_avg = round(static_tremor_acc_y_sum / len(self.static_tremor_acc_y), 4)
                static_tremor_acc_z_sum = 0
                for i in self.static_tremor_acc_z:
                    static_tremor_acc_z_sum += i
                self.static_tremor_acc_z_avg = round(static_tremor_acc_z_sum / len(self.static_tremor_acc_z), 4)
                
                static_tremor_gyro_x_sum = 0
                for i in self.static_tremor_gyro_x:
                    static_tremor_gyro_x_sum += i
                self.static_tremor_gyro_x_avg = round(static_tremor_gyro_x_sum / len(self.static_tremor_gyro_x), 4)
                static_tremor_gyro_y_sum = 0
                for i in self.static_tremor_gyro_y:
                    static_tremor_gyro_y_sum += i
                self.static_tremor_gyro_y_avg = round(static_tremor_gyro_y_sum / len(self.static_tremor_gyro_y), 4)
                static_tremor_gyro_z_sum = 0
                for i in self.static_tremor_gyro_z:
                    static_tremor_gyro_z_sum += i
                self.static_tremor_gyro_z_avg = round(static_tremor_gyro_z_sum / len(self.static_tremor_gyro_z), 4)
                
                static_tremor_mag_data_x = [0 for i in range(len(self.static_tremor_mag_x)-1)]  
                for i in range( len(self.static_tremor_mag_x)-1):
                    static_tremor_mag_data_x[i] = abs(self.static_tremor_mag_x[i+1] - self.static_tremor_mag_x[i])
                self.static_tremor_mag_x_max = round(max(static_tremor_mag_data_x), 4)
                static_tremor_mag_data_y = [0 for i in range(len(self.static_tremor_mag_y)-1)]  
                for i in range( len(self.static_tremor_mag_y)-1):
                    static_tremor_mag_data_y[i] = abs(self.static_tremor_mag_y[i+1] - self.static_tremor_mag_y[i])
                self.static_tremor_mag_y_max = round(max(static_tremor_mag_data_y), 4)
                static_tremor_mag_data_z = [0 for i in range(len(self.static_tremor_mag_z)-1)]  
                for i in range( len(self.static_tremor_mag_z)-1):
                    static_tremor_mag_data_z[i] = abs(self.static_tremor_mag_z[i+1] - self.static_tremor_mag_z[i])
                self.static_tremor_mag_z_max = round(max(static_tremor_mag_data_z), 4)
                
            if filename == 'Turning Test.csv':
                file_path = os.path.join(path, filename)
                # 打开并读取CSV文件
                with open(file_path, mode='r', encoding='utf-8') as csv_file:
                    csv_reader = csv.reader(csv_file)
                    next(csv_reader)
                    # 迭代CSV文件中的每一行
                    for row in csv_reader:
                        if len(row) >= 10:
                            #处理acc
                            self.turning_acc_x.append(round(float(row[1]), 3))  
                            self.turning_acc_y.append(round(float(row[2]), 3))  
                            self.turning_acc_z.append(round(float(row[3]), 3))  
                            #处理gyro
                            self.turning_gyro_x.append(round(float(row[4]), 3))  
                            self.turning_gyro_y.append(round(float(row[5]), 3))  
                            self.turning_gyro_z.append(round(float(row[6]), 3)) 
                            #处理magnetic
                            self.turning_mag_x.append(round(float(row[7]), 3))  
                            self.turning_mag_y.append(round(float(row[8]), 3))  
                            self.turning_mag_z.append(round(float(row[9]), 3)) 
                            
                turning_acc_x_sum = 0
                for i in self.turning_acc_x:
                    turning_acc_x_sum += i
                self.turning_acc_x_avg = round(turning_acc_x_sum / len(self.turning_acc_x), 4)
                turning_acc_y_sum = 0
                for i in self.turning_acc_y:
                    turning_acc_y_sum += i
                self.turning_acc_y_avg = round(turning_acc_y_sum / len(self.turning_acc_y), 4)
                turning_acc_z_sum = 0
                for i in self.turning_acc_z:
                    turning_acc_z_sum += i
                self.turning_acc_z_avg = round(turning_acc_z_sum / len(self.turning_acc_z), 4)
                
                turning_gyro_x_sum = 0
                for i in self.turning_gyro_x:
                    turning_gyro_x_sum += i
                self.turning_gyro_x_avg = round(turning_gyro_x_sum / len(self.turning_gyro_x), 4)
                turning_gyro_y_sum = 0
                for i in self.turning_gyro_y:
                    turning_gyro_y_sum += i
                self.turning_gyro_y_avg = round(turning_gyro_y_sum / len(self.turning_gyro_y), 4)
                turning_gyro_z_sum = 0
                for i in self.turning_gyro_z:
                    turning_gyro_z_sum += i
                self.turning_gyro_z_avg = round(turning_gyro_z_sum / len(self.turning_gyro_z), 4)
                
                turning_mag_data_x = [0 for i in range(len(self.turning_mag_x)-1)]  
                for i in range( len(self.turning_mag_x)-1):
                    turning_mag_data_x[i] = abs(self.turning_mag_x[i+1] - self.turning_mag_x[i])
                self.turning_mag_x_max = round(max(turning_mag_data_x), 4)
                turning_mag_data_y = [0 for i in range(len(self.turning_mag_y)-1)]  
                for i in range( len(self.turning_mag_y)-1):
                    turning_mag_data_y[i] = abs(self.turning_mag_y[i+1] - self.turning_mag_y[i])
                self.turning_mag_y_max = round(max(turning_mag_data_y), 4)
                turning_mag_data_z = [0 for i in range(len(self.turning_mag_z)-1)]  
                for i in range( len(self.turning_mag_z)-1):
                    turning_mag_data_z[i] = abs(self.turning_mag_z[i+1] - self.turning_mag_z[i])
                self.turning_mag_z_max = round(max(turning_mag_data_z), 4)
                
                
    def analyze_drawing_test(self):
        self.drawing_test_clicked = True
        
        
        #drawing test
        # 选用drawing test的stroke次数，测定用户绘画所用的屏幕点击次数，影响手部灵敏度
        # stroke次数高 表明绘画过程中肌肉的精确控制能力差
        
        # count = 15
        # average = 9
        # range = 7-15
        # standard deviation = 3.204
        #Q1 = 7     3-7 ----  0%-25%
        #Q2 = 8     7-8 ---- 25%-50%
        #Q3 = 11    8-11 ---- 50%-75%
        #Q4 = 15    11-15 ---- 75%-100%
        if self.drawing_stroke == 0:
            QMessageBox.information(self, "warning", "No drawing test data!")
            self.drawing_test_clicked = False
            return
            
        #构建展示部分
        self.scene1 = QGraphicsScene()
        self.ui.drawing_graphicsview.setScene(self.scene1)

        # 获取视口的矩形区域
        fig = Figure()
        ax = fig.add_subplot(111)
        #处理五条基本数据划分的区域
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values = [3, 7, 8, 11, 15]  # 四个部分的数据值

        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars = ax.bar(x, values, width, color=colors)

        # 添加比较值的标记线
        ax.axhline(y=self.drawing_stroke, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax.set_xlabel('Quartiles')
        ax.set_ylabel('Values')
        ax.set_title('Stroke')
        ax.set_xticks(x)
        ax.set_xticklabels(categories)
        ax.legend(loc='upper left')


        # 将 figure 转换为 QPixmap
        png_filename = os.path.join(tempfile.gettempdir(), 'drawing.png')
        canvas = FigureCanvas(fig)
        canvas.print_png(png_filename)
        pixmap = QPixmap(png_filename)
        # 将 QPixmap 添加到 QGraphicsScene
        item = QGraphicsPixmapItem(pixmap)
        self.scene1.addItem(item)
        os.remove(png_filename)
        
        #处理绘画测试tag
        
        if self.drawing_stroke < 3:
            self.drawing_test_tag = '0'
        elif 3 <= self.drawing_stroke < 7:
            self.drawing_test_tag = '1'
        elif 7 <= self.drawing_stroke < 8:
            self.drawing_test_tag = '2'
        elif 8 <= self.drawing_stroke < 11:
            self.drawing_test_tag = '3'
        elif 11<= self.drawing_stroke <= 15:
            self.drawing_test_tag = '4'
        elif self.drawing_stroke > 15:
            self.drawing_test_tag = '5'
            
            
            
            
    def analyze_rhythm_test(self):
        self.rhythm_test_clicked = True
        
        #rhythm test
        #选用rhythm test的click 次数和关于圆心的距离，测算用户点击数量和精确情况，影响距离判断和肌肉连续收缩情况
        # click次数过高 表明肌肉控制能力差 以至于手部频繁点击
        # click次数过低 表明神经反应速度慢 点击动作迟缓
        # pixel to center数值过大表明点击圆形点的稳定性差
        
        #click count
        #number = 22
        #Q1 = 80.25     50-80.25 ----  0%-25%
        #Q2 = 135     80.25-135---- 25%-50%
        #Q3 = 240.5    135-240.5 ---- 50%-75%
        #Q4 = 289    240.5-289 ---- 75%-100%
        
        #pixel to center count
        #number = 22
        #Q1 = 15.485     8.770-15.485 ----  0%-25%
        #Q2 = 21.974     15.485-21.974---- 25%-50%
        #Q3 = 24.084   21.974-24.084 ---- 50%-75%
        #Q4 = 35.931    24.084-35.931 ---- 75%-100%
        
        if self.rhythm_count == 0:
            QMessageBox.information(self, "warning", "No rhythm test data!")
            self.rhythm_test_clicked = False
            return
        
        #构建展示部分
        self.scene2 = QGraphicsScene()
        self.ui.rhythm_graphicsview.setScene(self.scene2)

        # 获取视口的矩形区域
        fig1 = Figure()
        ax1 = fig1.add_subplot(111) 
        #处理五条基本数据划分的区域
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values1 = [50, 80.25, 135, 240.5, 289]  # 四个部分的数据值

        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars1 = ax1.bar(x, values1, width, color=colors)

        # 添加比较值的标记线
        ax1.axhline(y=self.rhythm_count, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax1.set_xlabel('Quartiles')
        ax1.set_ylabel('Values')
        ax1.set_title('Count')
        ax1.set_xticks(x)
        ax1.set_xticklabels(categories)
        ax1.legend(loc='upper left')
        
        png_filename_1 = os.path.join(tempfile.gettempdir(), 'rhythm_count.png')
        canvas_1 = FigureCanvas(fig1)
        canvas_1.print_png(png_filename_1)
        pixmap_1 = QPixmap(png_filename_1)
        # 将 QPixmap 添加到 QGraphicsScene
        item_1 = QGraphicsPixmapItem(pixmap_1)
        item_1.setPos(0, 0)
        self.scene2.addItem(item_1)
        os.remove(png_filename_1)
        
        
        # 处理pixel to center
        fig2 = Figure()
        ax2 = fig2.add_subplot(111)
        #处理五条基本数据划分的区域
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values2 = [8.770, 15.485, 21.974, 24.084, 35.931]  # 四个部分的数据值

        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars2 = ax2.bar(x, values2, width, color=colors)

        # 添加比较值的标记线
        ax2.axhline(y=self.rhythm_pixel_to_center, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax2.set_xlabel('Quartiles')
        ax2.set_ylabel('Values')
        ax2.set_title('Pixel To Center')
        ax2.set_xticks(x)
        ax2.set_xticklabels(categories)
        ax2.legend(loc='upper left')


        # 将 figure 转换为 QPixmap
        png_filename_2 = os.path.join(tempfile.gettempdir(), 'rhythm_pixel_to_center.png')
        canvas_2 = FigureCanvas(fig2)
        canvas_2.print_png(png_filename_2)
        pixmap_2 = QPixmap(png_filename_2)
        # 将 QPixmap 添加到 QGraphicsScene
        item_2 = QGraphicsPixmapItem(pixmap_2)
        item_2.setPos(650, 0)
        self.scene2.addItem(item_2)
        os.remove(png_filename_2)
        
        # 处理rhythm test tag
        #count
        if self.rhythm_count < 50:
            self.rhythm_count_tag = '0'
        elif 50 <= self.rhythm_count < 80.25:
            self.rhythm_count_tag = '1'
        elif 80.25 <= self.rhythm_count < 135:
            self.rhythm_count_tag = '2'
        elif 135 <= self.rhythm_count < 240.5:
            self.rhythm_count_tag = '3'
        elif 240.5 <= self.rhythm_count <= 289:
            self.rhythm_count_tag = '4'
        elif self.rhythm_count > 289:
            self.rhythm_count_tag = '5'
        
        #pixel to center
        if self.rhythm_pixel_to_center < 8.770:
            self.rhythm_pixel_tag = '0'
        elif 8.770 <= self.rhythm_pixel_to_center < 15.485:
            self.rhythm_pixel_tag = '1'
        elif 15.485 <= self.rhythm_pixel_to_center < 21.974:
            self.rhythm_pixel_tag = '2'
        elif 21.974 <= self.rhythm_pixel_to_center < 24.084:
            self.rhythm_pixel_tag = '3'
        elif 24.084 <= self.rhythm_pixel_to_center <= 35.931:
            self.rhythm_pixel_tag = '4'
        elif self.rhythm_pixel_to_center > 35.931:
            self.rhythm_pixel_tag = '5'
    
    
    
    
    def analyze_walking_test(self):
        self.walking_test_clicked = True
        #处理raw data展示部分
        if len(self.walking_acc_x) == 0:
            QMessageBox.information(self, "warning", "No walking test data!")
            self.walking_test_clicked = False
            return
            
        #构建展示部分
        self.scene3 = QGraphicsScene()
        self.ui.walking_raw_graphicsview.setScene(self.scene3)
        
        # 获取视口的矩形区域
        fig1 = Figure()
        ax1 = fig1.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.walking_acc_x))]
        y_acc_x = self.walking_acc_x
        y_gyro_x = self.walking_gyro_x
        y_mag_x = self.walking_mag_x
        
        ax1.plot(x, y_acc_x, color='blue', linestyle='-', label = 'acceleration')
        ax1.plot(x, y_gyro_x, color='green', linestyle='-', label = 'gyroscope')
        ax1.plot(x, y_mag_x, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax1.legend()
        ax1.set_title('X Axis Data')
        
        png_filename_1 = os.path.join(tempfile.gettempdir(), 'walking_rawdata_x.png')
        canvas_1 = FigureCanvas(fig1)
        canvas_1.print_png(png_filename_1)
        pixmap_1 = QPixmap(png_filename_1)
        # 将 QPixmap 添加到 QGraphicsScene
        item_1 = QGraphicsPixmapItem(pixmap_1)
        item_1.setPos(0, 0)
        self.scene3.addItem(item_1)
        os.remove(png_filename_1)
        
        fig2 = Figure()
        ax2 = fig2.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.walking_acc_y))]
        y_acc_y = self.walking_acc_y
        y_gyro_y = self.walking_gyro_y
        y_mag_y = self.walking_mag_y
        
        ax2.plot(x, y_acc_y, color='blue', linestyle='-', label = 'acceleration')
        ax2.plot(x, y_gyro_y, color='green', linestyle='-', label = 'gyroscope')
        ax2.plot(x, y_mag_y, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax2.legend()
        ax2.set_title('Y Axis Data')
        
        png_filename_2 = os.path.join(tempfile.gettempdir(), 'walking_rawdata_y.png')
        canvas_2 = FigureCanvas(fig2)
        canvas_2.print_png(png_filename_2)
        pixmap_2 = QPixmap(png_filename_2)
        # 将 QPixmap 添加到 QGraphicsScene
        item_2 = QGraphicsPixmapItem(pixmap_2)
        item_2.setPos(650, 0)
        self.scene3.addItem(item_2)
        os.remove(png_filename_2)
        
        fig3 = Figure()
        ax3 = fig3.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.walking_acc_z))]
        y_acc_z = self.walking_acc_z
        y_gyro_z= self.walking_gyro_z
        y_mag_z = self.walking_mag_z
        
        ax3.plot(x, y_acc_z, color='blue', linestyle='-', label = 'acceleration')
        ax3.plot(x, y_gyro_z, color='green', linestyle='-', label = 'gyroscope')
        ax3.plot(x, y_mag_z, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax3.legend()
        ax3.set_title('Z Axis Data')
        
        png_filename_3 = os.path.join(tempfile.gettempdir(), 'walking_rawdata_z.png')
        canvas_3 = FigureCanvas(fig3)
        canvas_3.print_png(png_filename_3)
        pixmap_3 = QPixmap(png_filename_3)
        # 将 QPixmap 添加到 QGraphicsScene
        item_3 = QGraphicsPixmapItem(pixmap_3)
        item_3.setPos(1300, 0)
        self.scene3.addItem(item_3)
        os.remove(png_filename_3)
        
        #处理treated data展示部分
        
        #straight walking test
        # 根据分析用户直线行走过程中手机测量数据，对用户行走时身体协调情况进行分析
        # acc (x y z) 标明加速度 
        # x方向加速度过大则表明移动较快   加速度小则表明移动迟缓
        # y方向加速度过大则左右移动快  难以保持直线行走
        # z方向加速度过大则上下移动快 可能有膝盖弯曲等情况
        # gyro (x y z) 标明陀螺仪 即倾斜程度
        # x方向陀螺仪参数大则步伐不稳定 肌肉控制能力较差
        # y方向陀螺仪参数大则左右不稳定 容易向侧方向跌倒
        # z方向陀螺仪参数大则上下不稳定 容易前倾或后仰
        # mag 参数表明相对位置 此处取差距最大值处理
        # 对应方向参数大则表明对应方向快速偏移较多 对应方向稳定性差
        
        #对于采集的九种数据分别进行处理
        
        # acc x 
        # number = 19
        # Q0 = -0.3184
        # Q1 = -0.0802
        # Q2 = 0.0130
        # Q3 = 0.0996
        # Q4 = 0.6867
        
        # acc y 
        # number = 19
        # Q0 = -1.4380
        # Q1 = -0.5942
        # Q2 = -0.2266
        # Q3 = -0.1648
        # Q4 = 0.0745
        
        # acc z 
        # number = 19
        # Q0 = -0.4608
        # Q1 = 0.0257
        # Q2 = 0.1124
        # Q3 = 0.2432
        # Q4 = 0.5012
        
        
        #构建展示部分
        self.scene4 = QGraphicsScene()
        self.ui.walking_treated_graphicsview.setScene(self.scene4)

        # 获取视口的矩形区域
        fig4 = Figure()
        ax4 = fig4.add_subplot(111)
        #处理五条基本数据划分的区域
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values1 = [-0.3184, -0.0802, 0.0130, 0.0996, 0.6867]  # 四个部分的数据值
        values1_new = [i + 0.5 for i in values1]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars1 = ax4.bar(x, values1_new, width, bottom=-0.5, color=colors)

        # 添加比较值的标记线
        ax4.axhline(y=self.walking_acc_x_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax4.set_xlabel('Quartiles')
        ax4.set_ylabel('Values')
        ax4.set_title('Acceleration X')
        ax4.set_xticks(x)
        ax4.set_xticklabels(categories)
        ax4.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_4= os.path.join(tempfile.gettempdir(), 'walking_treated_acc_x.png')
        canvas_4 = FigureCanvas(fig4)
        canvas_4.print_png(png_filename_4)
        pixmap_4 = QPixmap(png_filename_4)
        # 将 QPixmap 添加到 QGraphicsScene
        item_4 = QGraphicsPixmapItem(pixmap_4)
        item_4.setPos(0, 0)
        self.scene4.addItem(item_4)
        os.remove(png_filename_4)
        
        fig5 = Figure()
        ax5 = fig5.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values2 = [ -1.4380,-0.5942,  -0.2266, -0.1648,  0.0745]  # 四个部分的数据值
        values2_new = [i + 2 for i in values2]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars2 = ax5.bar(x, values2_new, width, bottom=-2, color=colors)

        # 添加比较值的标记线
        ax5.axhline(y=self.walking_acc_y_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax5.set_xlabel('Quartiles')
        ax5.set_ylabel('Values')
        ax5.set_title('Acceleration Y')
        ax5.set_xticks(x)
        ax5.set_xticklabels(categories)
        ax5.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_5= os.path.join(tempfile.gettempdir(), 'walking_treated_acc_y.png')
        canvas_5 = FigureCanvas(fig5)
        canvas_5.print_png(png_filename_5)
        pixmap_5 = QPixmap(png_filename_5)
        # 将 QPixmap 添加到 QGraphicsScene
        item_5 = QGraphicsPixmapItem(pixmap_5)
        item_5.setPos(650, 0)
        self.scene4.addItem(item_5)
        os.remove(png_filename_5)
        
        fig6 = Figure()
        ax6 = fig6.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values3 = [  -0.4608,0.0257,  0.1124,  0.2432,  0.5012]  # 四个部分的数据值
        values3_new = [i + 0.5 for i in values3]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars3 = ax6.bar(x, values3_new, width, bottom=-0.5, color=colors)

        # 添加比较值的标记线
        ax6.axhline(y=self.walking_acc_z_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax6.set_xlabel('Quartiles')
        ax6.set_ylabel('Values')
        ax6.set_title('Acceleration Z')
        ax6.set_xticks(x)
        ax6.set_xticklabels(categories)
        ax6.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_6= os.path.join(tempfile.gettempdir(), 'walking_treated_acc_z.png')
        canvas_6 = FigureCanvas(fig6)
        canvas_6.print_png(png_filename_6)
        pixmap_6 = QPixmap(png_filename_6)
        # 将 QPixmap 添加到 QGraphicsScene
        item_6 = QGraphicsPixmapItem(pixmap_6)
        item_6.setPos(1300, 0)
        self.scene4.addItem(item_6)
        os.remove(png_filename_6)
        
        #处理walking test tag(acc)
        if self.walking_acc_x_avg < -0.3184:
            self.walking_acc_x_tag = '0'
        elif -0.3184 <= self.walking_acc_x_avg < -0.0802:
            self.walking_acc_x_tag = '1'
        elif -0.0802 <= self.walking_acc_x_avg < 0.0130:
            self.walking_acc_x_tag = '2'
        elif 0.0130 <= self.walking_acc_x_avg < 0.0996:
            self.walking_acc_x_tag = '3'
        elif 0.0996 <= self.walking_acc_x_avg <= 0.6867:
            self.walking_acc_x_tag = '4'
        elif self.walking_acc_x_avg > 0.6867:
            self.walking_acc_x_tag = '5'
            
        if self.walking_acc_y_avg < -1.4380:
            self.walking_acc_y_tag = '0'
        elif -1.4380 <= self.walking_acc_y_avg < -0.5942:
            self.walking_acc_y_tag = '1'
        elif -0.5942 <= self.walking_acc_y_avg < -0.2266:
            self.walking_acc_y_tag = '2'
        elif -0.2266 <= self.walking_acc_y_avg < -0.1648:
            self.walking_acc_y_tag = '3'
        elif -0.1648 <= self.walking_acc_y_avg <= 0.0745:
            self.walking_acc_y_tag = '4'
        elif self.walking_acc_y_avg > 0.0745:
            self.walking_acc_y_tag = '5'

        if self.walking_acc_z_avg < -0.4608:
            self.walking_acc_z_tag = '0'
        elif -0.4608 <= self.walking_acc_z_avg < 0.0257:
            self.walking_acc_z_tag = '1'
        elif 0.0257 <= self.walking_acc_z_avg < 0.1124:
            self.walking_acc_z_tag = '2'
        elif 0.1124 <= self.walking_acc_z_avg < 0.2432:
            self.walking_acc_z_tag = '3'
        elif 0.2432 <= self.walking_acc_z_avg <= 0.5012:
            self.walking_acc_z_tag = '4'
        elif self.walking_acc_z_avg > 0.5012:
            self.walking_acc_z_tag = '5'
        
        #gyro x 
        # number = 19
        # Q0 = -0.3553
        # Q1 = -0.1365
        # Q2 = -0.0245
        # Q3 = 0.0341
        # Q4 = 0.1197
        
        # gyro y 
        # number = 19
        # Q0 = -0.5134
        # Q1 = -0.2171
        # Q2 = -0.0293
        # Q3 = 0.1316
        # Q4 = 0.4537
        
        # gyro z 
        # number = 19
        # Q0 = -0.0862
        # Q1 = -0.0332
        # Q2 = -0.0074
        # Q3 = 0.0249
        # Q4 = 0.1076
        
        fig7 = Figure()
        ax7 = fig7.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values4 = [  -0.3553,-0.1365,   -0.0245, 0.0341,   0.1197]  # 四个部分的数据值
        values4_new = [i + 0.5 for i in values4]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars4 = ax7.bar(x, values4_new, width, bottom=-0.5, color=colors)

        # 添加比较值的标记线
        ax7.axhline(y=self.walking_gyro_x_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax7.set_xlabel('Quartiles')
        ax7.set_ylabel('Values')
        ax7.set_title('Gyroscope X')
        ax7.set_xticks(x)
        ax7.set_xticklabels(categories)
        ax7.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_7= os.path.join(tempfile.gettempdir(), 'walking_treated_gyro_x.png')
        canvas_7 = FigureCanvas(fig7)
        canvas_7.print_png(png_filename_7)
        pixmap_7 = QPixmap(png_filename_7)
        # 将 QPixmap 添加到 QGraphicsScene
        item_7 = QGraphicsPixmapItem(pixmap_7)
        item_7.setPos(1950, 0)
        self.scene4.addItem(item_7)
        os.remove(png_filename_7)
        
        fig8 = Figure()
        ax8 = fig8.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values5 = [  -0.5134, -0.2171,  -0.0293, 0.1316, 0.4537]  # 四个部分的数据值
        values5_new = [i + 0.7 for i in values5]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars5 = ax8.bar(x, values5_new, width, bottom=-0.7, color=colors)

        # 添加比较值的标记线
        ax8.axhline(y=self.walking_gyro_y_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax8.set_xlabel('Quartiles')
        ax8.set_ylabel('Values')
        ax8.set_title('Gyroscope Y')
        ax8.set_xticks(x)
        ax8.set_xticklabels(categories)
        ax8.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_8= os.path.join(tempfile.gettempdir(), 'walking_treated_gyro_y.png')
        canvas_8 = FigureCanvas(fig8)
        canvas_8.print_png(png_filename_8)
        pixmap_8 = QPixmap(png_filename_8)
        # 将 QPixmap 添加到 QGraphicsScene
        item_8= QGraphicsPixmapItem(pixmap_8)
        item_8.setPos(2600, 0)
        self.scene4.addItem(item_8)
        os.remove(png_filename_8)
        
        fig9 = Figure()
        ax9 = fig9.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values6 = [ -0.0862, -0.0332,  -0.0074, 0.0249, 0.1076]  # 四个部分的数据值
        values6_new = [i + 0.2 for i in values6]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars6 = ax9.bar(x, values6_new, width, bottom=-0.2, color=colors)

        # 添加比较值的标记线
        ax9.axhline(y=self.walking_gyro_z_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax9.set_xlabel('Quartiles')
        ax9.set_ylabel('Values')
        ax9.set_title('Gyroscope Z')
        ax9.set_xticks(x)
        ax9.set_xticklabels(categories)
        ax9.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_9= os.path.join(tempfile.gettempdir(), 'walking_treated_gyro_z.png')
        canvas_9 = FigureCanvas(fig9)
        canvas_9.print_png(png_filename_9)
        pixmap_9 = QPixmap(png_filename_9)
        # 将 QPixmap 添加到 QGraphicsScene
        item_9= QGraphicsPixmapItem(pixmap_9)
        item_9.setPos(3250, 0)
        self.scene4.addItem(item_9)
        os.remove(png_filename_9)
        
        #处理walking test tag(gyro)
        if self.walking_gyro_x_avg < -0.3553:
            self.walking_gyro_x_tag = '0'
        elif -0.3553 <= self.walking_gyro_x_avg < -0.1365:
            self.walking_gyro_x_tag = '1'
        elif -0.1365 <= self.walking_gyro_x_avg < -0.0245:
            self.walking_gyro_x_tag = '2'
        elif -0.0245 <= self.walking_gyro_x_avg < 0.0341:
            self.walking_gyro_x_tag = '3'
        elif 0.0341 <= self.walking_gyro_x_avg <= 0.1197:
            self.walking_gyro_x_tag = '4'
        elif self.walking_gyro_x_avg > 0.1197:
            self.walking_gyro_x_tag = '5'
        
        if self.walking_gyro_y_avg < -0.5134:
            self.walking_gyro_y_tag = '0'
        elif -0.5134 <= self.walking_gyro_y_avg < -0.2171:
            self.walking_gyro_y_tag = '1'
        elif -0.2171 <= self.walking_gyro_y_avg < -0.0293:
            self.walking_gyro_y_tag = '2'
        elif -0.0293 <= self.walking_gyro_y_avg < 0.1316:
            self.walking_gyro_y_tag = '3'
        elif 0.1316 <= self.walking_gyro_y_avg <= 0.4537:
            self.walking_gyro_y_tag = '4'
        elif self.walking_gyro_y_avg > 0.4537:
            self.walking_gyro_y_tag = '5'

        if self.walking_gyro_z_avg <  -0.0862:
            self.walking_gyro_z_tag = '0'
        elif  -0.0862 <= self.walking_gyro_z_avg < -0.0332:
            self.walking_gyro_z_tag = '1'
        elif -0.0332 <= self.walking_gyro_z_avg < -0.0074:
            self.walking_gyro_z_tag = '2'
        elif -0.0074 <= self.walking_gyro_z_avg < 0.0249:
            self.walking_gyro_z_tag = '3'
        elif 0.0249 <= self.walking_gyro_z_avg <= 0.1076:
            self.walking_gyro_z_tag = '4'
        elif self.walking_gyro_z_avg > 0.1076:
            self.walking_gyro_z_tag = '5'
        
        #mag x 
        # number = 19
        # Q0 = 4.7214
        # Q1 = 7.3688
        # Q2 = 9.5160
        # Q3 = 16.8125
        # Q4 = 35.2875
        
        # mag y 
        # number = 19
        # Q0 = 4.1358
        # Q1 = 5.5688
        # Q2 = 12.7734
        # Q3 = 22.4813
        # Q4 = 33.7696
        
        # mag z 
        # number = 19
        # Q0 = 4.9654
        # Q1 = 7.2346
        # Q2 = 9.2250
        # Q3 = 11.1000
        # Q4 = 30.4375
        
        fig10 = Figure()
        ax10 = fig10.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values7 = [  4.7214, 7.3688,  9.5160, 16.8125, 35.2875]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars7 = ax10.bar(x, values7, width, color=colors)

        # 添加比较值的标记线
        ax10.axhline(y=self.walking_mag_x_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax10.set_xlabel('Quartiles')
        ax10.set_ylabel('Values')
        ax10.set_title('Coordination X')
        ax10.set_xticks(x)
        ax10.set_xticklabels(categories)
        ax10.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_10= os.path.join(tempfile.gettempdir(), 'walking_treated_mag_x.png')
        canvas_10 = FigureCanvas(fig10)
        canvas_10.print_png(png_filename_10)
        pixmap_10 = QPixmap(png_filename_10)
        # 将 QPixmap 添加到 QGraphicsScene
        item_10= QGraphicsPixmapItem(pixmap_10)
        item_10.setPos(3900, 0)
        self.scene4.addItem(item_10)
        os.remove(png_filename_10)
        
        fig11 = Figure()
        ax11 = fig11.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values8 = [ 4.1358, 5.5688,  12.7734, 22.4813,  33.7696]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars8= ax11.bar(x, values8, width, color=colors)

        # 添加比较值的标记线
        ax11.axhline(y=self.walking_mag_y_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax11.set_xlabel('Quartiles')
        ax11.set_ylabel('Values')
        ax11.set_title('Coordination Y')
        ax11.set_xticks(x)
        ax11.set_xticklabels(categories)
        ax11.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_11= os.path.join(tempfile.gettempdir(), 'walking_treated_mag_y.png')
        canvas_11 = FigureCanvas(fig11)
        canvas_11.print_png(png_filename_11)
        pixmap_11 = QPixmap(png_filename_11)
        # 将 QPixmap 添加到 QGraphicsScene
        item_11= QGraphicsPixmapItem(pixmap_11)
        item_11.setPos(4550, 0)
        self.scene4.addItem(item_11)
        os.remove(png_filename_11)
        
        fig12 = Figure()
        ax12 = fig12.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values9 = [ 4.9654, 7.2346,  9.2250, 11.1000,  30.4375]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars9= ax12.bar(x, values9, width, color=colors)

        # 添加比较值的标记线
        ax12.axhline(y=self.walking_mag_z_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax12.set_xlabel('Quartiles')
        ax12.set_ylabel('Values')
        ax12.set_title('Coordination Z')
        ax12.set_xticks(x)
        ax12.set_xticklabels(categories)
        ax12.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_12= os.path.join(tempfile.gettempdir(), 'walking_treated_mag_z.png')
        canvas_12 = FigureCanvas(fig12)
        canvas_12.print_png(png_filename_12)
        pixmap_12 = QPixmap(png_filename_12)
        # 将 QPixmap 添加到 QGraphicsScene
        item_12= QGraphicsPixmapItem(pixmap_12)
        item_12.setPos(5200, 0)
        self.scene4.addItem(item_12)
        os.remove(png_filename_12)

        #处理walking test tag(mag)
        if self.walking_mag_x_max < 4.7214:
            self.walking_mag_x_tag = '0'
        elif 4.7214 <= self.walking_mag_x_max < 7.3688:
            self.walking_mag_x_tag = '1'
        elif 7.3688 <= self.walking_mag_x_max < 9.5160:
            self.walking_mag_x_tag = '2'
        elif 9.5160 <= self.walking_mag_x_max < 16.8125:
            self.walking_mag_x_tag = '3'
        elif 16.8125 <= self.walking_mag_x_max <= 35.2875:
           self.walking_mag_x_tag = '4'
        elif self.walking_mag_x_max > 35.2875:
            self.walking_mag_x_tag = '5'

        if self.walking_mag_y_max < 4.1358:
            self.walking_mag_y_tag = '0'
        elif 4.1358 <= self.walking_mag_y_max < 5.5688:
            self.walking_mag_y_tag = '1'
        elif 5.5688 <= self.walking_mag_y_max < 12.7734:
            self.walking_mag_y_tag = '2'
        elif 12.7734 <= self.walking_mag_y_max < 22.4813:
            self.walking_mag_y_tag = '3'
        elif 22.4813 <= self.walking_mag_y_max <= 33.7696:
           self.walking_mag_y_tag = '4'
        elif self.walking_mag_y_max > 33.7696:
            self.walking_mag_y_tag = '5'
        
        if self.walking_mag_z_max < 4.9654:
            self.walking_mag_z_tag = '0'
        elif 4.9654 <= self.walking_mag_z_max < 7.2346:
            self.walking_mag_z_tag = '1'
        elif 7.2346 <= self.walking_mag_z_max < 9.2250:
            self.walking_mag_z_tag = '2'
        elif 9.2250 <= self.walking_mag_z_max < 11.1000:
            self.walking_mag_z_tag = '3'
        elif 11.1000 <= self.walking_mag_z_max <= 30.4375:
           self.walking_mag_z_tag = '4'
        elif self.walking_mag_z_max > 30.4375:
            self.walking_mag_z_tag = '5'
            
            
    def analyze_tremor_test(self): 
        self.tremor_test_clicked = True
        # 由于包含postural 和 static 两部分组成，分别进行处理
        self.analyze_postural_tremor()
        self.analyze_static_tremor()
        
    
    def analyze_postural_tremor(self):
        #处理raw data展示部分
        if len(self.postural_tremor_acc_x) == 0:
            QMessageBox.information(self, "warning", "No postural tremor test data!")
            self.postural_tremor_test_clicked = False
            return
            
        #构建展示部分
        self.scene5 = QGraphicsScene()
        self.ui.postural_tremor_raw_graphicsview.setScene(self.scene5)
        
        # 获取视口的矩形区域
        fig1 = Figure()
        ax1 = fig1.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.postural_tremor_acc_x))]
        y_acc_x = self.postural_tremor_acc_x
        y_gyro_x = self.postural_tremor_gyro_x
        y_mag_x = self.postural_tremor_mag_x
        
        ax1.plot(x, y_acc_x, color='blue', linestyle='-', label = 'acceleration')
        ax1.plot(x, y_gyro_x, color='green', linestyle='-', label = 'gyroscope')
        ax1.plot(x, y_mag_x, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax1.legend()
        ax1.set_title('X Axis Data')
        
        png_filename_1 = os.path.join(tempfile.gettempdir(), 'postural_tremor_rawdata_x.png')
        canvas_1 = FigureCanvas(fig1)
        canvas_1.print_png(png_filename_1)
        pixmap_1 = QPixmap(png_filename_1)
        # 将 QPixmap 添加到 QGraphicsScene
        item_1 = QGraphicsPixmapItem(pixmap_1)
        item_1.setPos(0, 0)
        self.scene5.addItem(item_1)
        os.remove(png_filename_1)
        
        fig2 = Figure()
        ax2 = fig2.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.postural_tremor_acc_y))]
        y_acc_y = self.postural_tremor_acc_y
        y_gyro_y = self.postural_tremor_gyro_y
        y_mag_y = self.postural_tremor_mag_y
        
        ax2.plot(x, y_acc_y, color='blue', linestyle='-', label = 'acceleration')
        ax2.plot(x, y_gyro_y, color='green', linestyle='-', label = 'gyroscope')
        ax2.plot(x, y_mag_y, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax2.legend()
        ax2.set_title('Y Axis Data')
        
        png_filename_2 = os.path.join(tempfile.gettempdir(), 'postural_tremor_rawdata_y.png')
        canvas_2 = FigureCanvas(fig2)
        canvas_2.print_png(png_filename_2)
        pixmap_2 = QPixmap(png_filename_2)
        # 将 QPixmap 添加到 QGraphicsScene
        item_2 = QGraphicsPixmapItem(pixmap_2)
        item_2.setPos(650, 0)
        self.scene5.addItem(item_2)
        os.remove(png_filename_2)
        
        fig3 = Figure()
        ax3 = fig3.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.postural_tremor_acc_z))]
        y_acc_z = self.postural_tremor_acc_z
        y_gyro_z= self.postural_tremor_gyro_z
        y_mag_z = self.postural_tremor_mag_z
        
        ax3.plot(x, y_acc_z, color='blue', linestyle='-', label = 'acceleration')
        ax3.plot(x, y_gyro_z, color='green', linestyle='-', label = 'gyroscope')
        ax3.plot(x, y_mag_z, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax3.legend()
        ax3.set_title('Z Axis Data')
        
        png_filename_3 = os.path.join(tempfile.gettempdir(), 'postural_tremor_rawdata_z.png')
        canvas_3 = FigureCanvas(fig3)
        canvas_3.print_png(png_filename_3)
        pixmap_3 = QPixmap(png_filename_3)
        # 将 QPixmap 添加到 QGraphicsScene
        item_3 = QGraphicsPixmapItem(pixmap_3)
        item_3.setPos(1300, 0)
        self.scene5.addItem(item_3)
        os.remove(png_filename_3)
        
        #处理treated data展示部分
        
        #postural tremor test
        #根据分析用户手臂伸直时手机的相对数据，确认肌肉控制和手臂抖动情况
        # acc (x y z) 表明加速度
        # x方向加速度大则表明手臂前后移动较大 手臂肌肉控制力差
        # y方向加速度大则表明手臂左右移动较大 手臂肌肉控制力差
        # z方向加速度大则表明手臂上下移动较大 手臂肌肉控制力差
        # gyro (x y z) 表明陀螺仪 即倾斜程度
        # x方向陀螺仪参数大则表明手臂容易前后摇摆
        # y方向陀螺仪参数大则表明手臂容易左右摇摆
        # z方向陀螺仪参数大则表明手臂容易上下摇摆
        # mag (x y z)为相对位置 此处进行差距最大值处理
        # x方向参数大则表明手臂存在前后快速摇摆现象
        # y方向参数大则表明手臂存在左右快速摇摆现象
        # z方向参数大则表明手臂存在上下快速摇摆现象
        
        #对于采集的九种数据分别进行处理
        
        # acc x 
        # number = 19
        # Q0 = -0.2129
        # Q1 = -0.0799
        # Q2 = -0.0489
        # Q3 = 0.0197
        # Q4 = 0.2018
        
        # acc y 
        # number = 19
        # Q0 = -0.2354
        # Q1 = -0.0642
        # Q2 = -0.0131
        # Q3 = 0.1104
        # Q4 = 0.2445
        
        # acc z 
        # number = 19
        # Q0 = -0.3124
        # Q1 = -0.0707
        # Q2 = -0.0027
        # Q3 = 0.0556
        # Q4 = 0.2365
        
        
        #构建展示部分
        self.scene6 = QGraphicsScene()
        self.ui.postural_tremor_treated_graphicsview.setScene(self.scene6)

        # 获取视口的矩形区域
        fig4 = Figure()
        ax4 = fig4.add_subplot(111)
        #处理五条基本数据划分的区域
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values1 = [-0.2129, -0.0799, -0.0489, 0.0197, 0.2018]  # 四个部分的数据值
        values1_new = [i + 0.4 for i in values1]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars1 = ax4.bar(x, values1_new, width, bottom=-0.4, color=colors)

        # 添加比较值的标记线
        ax4.axhline(y=self.postural_tremor_acc_x_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax4.set_xlabel('Quartiles')
        ax4.set_ylabel('Values')
        ax4.set_title('Acceleration X')
        ax4.set_xticks(x)
        ax4.set_xticklabels(categories)
        ax4.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_4= os.path.join(tempfile.gettempdir(), 'postural_tremor_treated_acc_x.png')
        canvas_4 = FigureCanvas(fig4)
        canvas_4.print_png(png_filename_4)
        pixmap_4 = QPixmap(png_filename_4)
        # 将 QPixmap 添加到 QGraphicsScene
        item_4 = QGraphicsPixmapItem(pixmap_4)
        item_4.setPos(0, 0)
        self.scene6.addItem(item_4)
        os.remove(png_filename_4)
        
        fig5 = Figure()
        ax5 = fig5.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values2 = [ -0.2354,-0.0642,  -0.0131, 0.1104,   0.2445]  # 四个部分的数据值
        values2_new = [i + 0.4 for i in values2]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars2 = ax5.bar(x, values2_new, width, bottom=-0.4, color=colors)

        # 添加比较值的标记线
        ax5.axhline(y=self.postural_tremor_acc_y_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax5.set_xlabel('Quartiles')
        ax5.set_ylabel('Values')
        ax5.set_title('Acceleration Y')
        ax5.set_xticks(x)
        ax5.set_xticklabels(categories)
        ax5.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_5= os.path.join(tempfile.gettempdir(), 'postural_tremor_treated_acc_y.png')
        canvas_5 = FigureCanvas(fig5)
        canvas_5.print_png(png_filename_5)
        pixmap_5 = QPixmap(png_filename_5)
        # 将 QPixmap 添加到 QGraphicsScene
        item_5 = QGraphicsPixmapItem(pixmap_5)
        item_5.setPos(650, 0)
        self.scene6.addItem(item_5)
        os.remove(png_filename_5)
        
        fig6 = Figure()
        ax6 = fig6.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values3 = [  -0.3124,-0.0707, -0.0027,  0.0556,  0.2365]  # 四个部分的数据值
        values3_new = [i + 0.4 for i in values3]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars3 = ax6.bar(x, values3_new, width, bottom=-0.4, color=colors)

        # 添加比较值的标记线
        ax6.axhline(y=self.postural_tremor_acc_z_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax6.set_xlabel('Quartiles')
        ax6.set_ylabel('Values')
        ax6.set_title('Acceleration Z')
        ax6.set_xticks(x)
        ax6.set_xticklabels(categories)
        ax6.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_6= os.path.join(tempfile.gettempdir(), 'postural_tremor_treated_acc_z.png')
        canvas_6 = FigureCanvas(fig6)
        canvas_6.print_png(png_filename_6)
        pixmap_6 = QPixmap(png_filename_6)
        # 将 QPixmap 添加到 QGraphicsScene
        item_6 = QGraphicsPixmapItem(pixmap_6)
        item_6.setPos(1300, 0)
        self.scene6.addItem(item_6)
        os.remove(png_filename_6)
        
        #处理postural tremor test tag(acc)
        if self.postural_tremor_acc_x_avg < -0.2129:
            self.postural_tremor_acc_x_tag = '0'
        elif -0.2129 <= self.postural_tremor_acc_x_avg < -0.0799:
            self.postural_tremor_acc_x_tag = '1'
        elif -0.0799 <= self.postural_tremor_acc_x_avg < -0.0489:
            self.postural_tremor_acc_x_tag = '2'
        elif -0.0489 <= self.postural_tremor_acc_x_avg < 0.0197:
            self.postural_tremor_acc_x_tag = '3'
        elif 0.0197 <= self.postural_tremor_acc_x_avg <= 0.2018:
            self.postural_tremor_acc_x_tag = '4'
        elif self.postural_tremor_acc_x_avg > 0.2018:
            self.postural_tremor_acc_x_tag = '5'
   
        if self.postural_tremor_acc_y_avg < -0.2354:
            self.postural_tremor_acc_y_tag = '0'
        elif -0.2354 <= self.postural_tremor_acc_y_avg < -0.0642:
            self.postural_tremor_acc_y_tag = '1'
        elif -0.0642 <= self.postural_tremor_acc_y_avg < -0.0131:
            self.postural_tremor_acc_y_tag = '2'
        elif -0.0131 <= self.postural_tremor_acc_y_avg < 0.1104:
            self.postural_tremor_acc_y_tag = '3'
        elif 0.1104 <= self.postural_tremor_acc_y_avg <= 0.2445 :
            self.postural_tremor_acc_y_tag = '4'
        elif self.postural_tremor_acc_y_avg > 0.2445 :
            self.postural_tremor_acc_y_tag = '5'

        if self.postural_tremor_acc_z_avg < -0.3124:
            self.postural_tremor_acc_z_tag = '0'
        elif -0.3124 <= self.postural_tremor_acc_z_avg < -0.0707:
            self.postural_tremor_acc_z_tag = '1'
        elif -0.0707 <= self.postural_tremor_acc_z_avg < -0.0027:
            self.postural_tremor_acc_z_tag = '2'
        elif -0.0027 <= self.postural_tremor_acc_z_avg < 0.0556:
            self.postural_tremor_acc_z_tag = '3'
        elif 0.0556 <= self.postural_tremor_acc_z_avg <= 0.2365:
            self.postural_tremor_acc_z_tag = '4'
        elif self.postural_tremor_acc_z_avg > 0.2365:
            self.postural_tremor_acc_z_tag = '5'    
        
        #gyro x 
        # number = 19
        # Q0 = -0.0350
        # Q1 = 0.0115
        # Q2 = 0.0661
        # Q3 = 0.0945
        # Q4 = 0.1651
        
        # gyro y 
        # number = 19
        # Q0 = -0.2503
        # Q1 = -0.2076
        # Q2 = -0.1916
        # Q3 = -0.0203
        # Q4 = 0.1881
        
        # gyro z 
        # number = 19
        # Q0 = -0.0783
        # Q1 = 0.0111
        # Q2 = 0.0428
        # Q3 = 0.0720
        # Q4 = 0.1541
        
        
        # 获取视口的矩形区域
        fig7 = Figure()
        ax7 = fig7.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values4 = [ -0.0350,0.0115, 0.0661,  0.0945, 0.1651]  # 四个部分的数据值
        values4_new = [i + 0.1 for i in values4]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars4 = ax7.bar(x, values4_new, width, bottom=-0.1, color=colors)

        # 添加比较值的标记线
        ax7.axhline(y=self.postural_tremor_gyro_x_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax7.set_xlabel('Quartiles')
        ax7.set_ylabel('Values')
        ax7.set_title('Gyroscope X')
        ax7.set_xticks(x)
        ax7.set_xticklabels(categories)
        ax7.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_7= os.path.join(tempfile.gettempdir(), '.postural_tremor_treated_gyro_x.png')
        canvas_7 = FigureCanvas(fig7)
        canvas_7.print_png(png_filename_7)
        pixmap_7 = QPixmap(png_filename_7)
        # 将 QPixmap 添加到 QGraphicsScene
        item_7 = QGraphicsPixmapItem(pixmap_7)
        item_7.setPos(1950, 0)
        self.scene6.addItem(item_7)
        os.remove(png_filename_7)
        
        fig8 = Figure()
        ax8 = fig8.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values5 = [ -0.2503, -0.2076, -0.1916,  -0.0203, 0.1881]  # 四个部分的数据值
        values5_new = [i + 0.3 for i in values5]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars5 = ax8.bar(x, values5_new, width, bottom=-0.3, color=colors)

        # 添加比较值的标记线
        ax8.axhline(y=self.postural_tremor_gyro_y_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax8.set_xlabel('Quartiles')
        ax8.set_ylabel('Values')
        ax8.set_title('Gyroscope Y')
        ax8.set_xticks(x)
        ax8.set_xticklabels(categories)
        ax8.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_8= os.path.join(tempfile.gettempdir(), 'postural_tremor_treated_gyro_y.png')
        canvas_8 = FigureCanvas(fig8)
        canvas_8.print_png(png_filename_8)
        pixmap_8 = QPixmap(png_filename_8)
        # 将 QPixmap 添加到 QGraphicsScene
        item_8= QGraphicsPixmapItem(pixmap_8)
        item_8.setPos(2600, 0)
        self.scene6.addItem(item_8)
        os.remove(png_filename_8)
        
        fig9 = Figure()
        ax9 = fig9.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values6 = [ -0.0783, 0.0111,  0.0428, 0.0720, 0.1541]  # 四个部分的数据值
        values6_new = [i + 0.1 for i in values6]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars6 = ax9.bar(x, values6_new, width, bottom=-0.1, color=colors)

        # 添加比较值的标记线
        ax9.axhline(y=self.postural_tremor_gyro_z_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax9.set_xlabel('Quartiles')
        ax9.set_ylabel('Values')
        ax9.set_title('Gyroscope Z')
        ax9.set_xticks(x)
        ax9.set_xticklabels(categories)
        ax9.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_9= os.path.join(tempfile.gettempdir(), 'postural_tremor_treated_gyro_z.png')
        canvas_9 = FigureCanvas(fig9)
        canvas_9.print_png(png_filename_9)
        pixmap_9 = QPixmap(png_filename_9)
        # 将 QPixmap 添加到 QGraphicsScene
        item_9= QGraphicsPixmapItem(pixmap_9)
        item_9.setPos(3250, 0)
        self.scene6.addItem(item_9)
        os.remove(png_filename_9)
        
        #处理walking test tag(gyro)
        if self.postural_tremor_gyro_x_avg < -0.0350:
            self.postural_tremor_gyro_x_tag = '0'
        elif -0.0350 <= self.postural_tremor_gyro_x_avg < 0.0115:
            self.postural_tremor_gyro_x_tag = '1'
        elif 0.0115 <= self.postural_tremor_gyro_x_avg < 0.0661:
            self.postural_tremor_gyro_x_tag = '2'
        elif 0.0661 <= self.postural_tremor_gyro_x_avg < 0.0945:
            self.postural_tremor_gyro_x_tag = '3'
        elif 0.0945 <= self.postural_tremor_gyro_x_avg <= 0.1651:
            self.postural_tremor_gyro_x_tag = '4'
        elif self.postural_tremor_gyro_x_avg > 0.1651:
            self.postural_tremor_gyro_x_tag = '5'

        if self.postural_tremor_gyro_y_avg < -0.2503:
            self.postural_tremor_gyro_y_tag = '0'
        elif -0.2503 <= self.postural_tremor_gyro_y_avg < -0.2076:
            self.postural_tremor_gyro_y_tag = '1'
        elif -0.2076 <= self.postural_tremor_gyro_y_avg < -0.1916:
            self.postural_tremor_gyro_y_tag = '2'
        elif -0.1916 <= self.postural_tremor_gyro_y_avg < -0.0203:
            self.postural_tremor_gyro_y_tag = '3'
        elif -0.0203 <= self.postural_tremor_gyro_y_avg <= 0.1881:
            self.postural_tremor_gyro_y_tag = '4'
        elif self.postural_tremor_gyro_y_avg > 0.1881:
            self.postural_tremor_gyro_y_tag = '5'

        if self.postural_tremor_gyro_z_avg <  -0.0783:
            self.postural_tremor_gyro_z_tag = '0'
        elif  -0.0783 <= self.postural_tremor_gyro_z_avg < 0.0111:
            self.postural_tremor_gyro_z_tag = '1'
        elif 0.0111 <= self.postural_tremor_gyro_z_avg < 0.0428:
            self.postural_tremor_gyro_z_tag = '2'
        elif 0.0428 <= self.postural_tremor_gyro_z_avg < 0.0720:
            self.postural_tremor_gyro_z_tag = '3'
        elif 0.0720 <= self.postural_tremor_gyro_z_avg <= 0.1541:
            self.postural_tremor_gyro_z_tag = '4'
        elif self.postural_tremor_gyro_z_avg > 0.1541:
            self.postural_tremor_gyro_z_tag = '5'
        
        #mag x 
        # number = 19
        # Q0 = 3.2063
        # Q1 = 5.4563
        # Q2 = 6.8808
        # Q3 = 15.3125
        # Q4 = 26.8750
        
        # mag y 
        # number = 19
        # Q0 = 1.8666
        # Q1 = 2.8125
        # Q2 = 4.8800
        # Q3 = 11.1875
        # Q4 = 34.4284
        
        # mag z 
        # number = 19
        # Q0 = 2.5312
        # Q1 = 10.1382
        # Q2 = 11.4558
        # Q3 = 19.0320
        # Q4 = 44.8125
        
        # 获取视口的矩形区域
        fig10 = Figure()
        ax10 = fig10.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values7 = [  3.2063, 5.4563,  6.8808, 15.3125, 26.8750]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars7 = ax10.bar(x, values7, width, color=colors)

        # 添加比较值的标记线
        ax10.axhline(y=self.postural_tremor_mag_x_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax10.set_xlabel('Quartiles')
        ax10.set_ylabel('Values')
        ax10.set_title('Coordination X')
        ax10.set_xticks(x)
        ax10.set_xticklabels(categories)
        ax10.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_10= os.path.join(tempfile.gettempdir(), 'postural_tremor_treated_mag_x.png')
        canvas_10 = FigureCanvas(fig10)
        canvas_10.print_png(png_filename_10)
        pixmap_10 = QPixmap(png_filename_10)
        # 将 QPixmap 添加到 QGraphicsScene
        item_10= QGraphicsPixmapItem(pixmap_10)
        item_10.setPos(3900, 0)
        self.scene6.addItem(item_10)
        os.remove(png_filename_10)
        
        fig11 = Figure()
        ax11 = fig11.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values8 = [ 1.8666, 2.8125,  4.8800,11.1875,  34.4284]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars8= ax11.bar(x, values8, width, color=colors)

        # 添加比较值的标记线
        ax11.axhline(y=self.postural_tremor_mag_y_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax11.set_xlabel('Quartiles')
        ax11.set_ylabel('Values')
        ax11.set_title('Coordination Y')
        ax11.set_xticks(x)
        ax11.set_xticklabels(categories)
        ax11.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_11= os.path.join(tempfile.gettempdir(), 'postural_tremor_treated_mag_y.png')
        canvas_11 = FigureCanvas(fig11)
        canvas_11.print_png(png_filename_11)
        pixmap_11 = QPixmap(png_filename_11)
        # 将 QPixmap 添加到 QGraphicsScene
        item_11= QGraphicsPixmapItem(pixmap_11)
        item_11.setPos(4550, 0)
        self.scene6.addItem(item_11)
        os.remove(png_filename_11)
        
        fig12 = Figure()
        ax12 = fig12.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values9 = [2.5312, 10.1382, 11.4558, 19.0320,  44.8125]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars9= ax12.bar(x, values9, width, color=colors)

        # 添加比较值的标记线
        ax12.axhline(y=self.postural_tremor_mag_z_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax12.set_xlabel('Quartiles')
        ax12.set_ylabel('Values')
        ax12.set_title('Coordination Z')
        ax12.set_xticks(x)
        ax12.set_xticklabels(categories)
        ax12.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_12= os.path.join(tempfile.gettempdir(), 'walking_treated_mag_z.png')
        canvas_12 = FigureCanvas(fig12)
        canvas_12.print_png(png_filename_12)
        pixmap_12 = QPixmap(png_filename_12)
        # 将 QPixmap 添加到 QGraphicsScene
        item_12= QGraphicsPixmapItem(pixmap_12)
        item_12.setPos(5200, 0)
        self.scene6.addItem(item_12)
        os.remove(png_filename_12)


        #处理walking test tag(mag)
        if self.postural_tremor_mag_x_max < 3.2063:
            self.postural_tremor_mag_x_tag = '0'
        elif 3.2063 <= self.postural_tremor_mag_x_max < 5.4563:
            self.postural_tremor_mag_x_tag = '1'
        elif 5.4563 <= self.postural_tremor_mag_x_max < 6.8808:
            self.postural_tremor_mag_x_tag = '2'
        elif 6.8808 <= self.postural_tremor_mag_x_max < 15.3125:
            self.postural_tremor_mag_x_tag = '3'
        elif 15.3125 <= self.postural_tremor_mag_x_max <= 26.8750:
           self.postural_tremor_mag_x_tag = '4'
        elif self.postural_tremor_mag_x_max > 26.8750:
            self.postural_tremor_mag_x_tag = '5'

        if self.postural_tremor_mag_y_max < 1.8666:
            self.postural_tremor_mag_y_tag = '0'
        elif 1.8666 <= self.postural_tremor_mag_y_max < 2.8125:
            self.postural_tremor_mag_y_tag = '1'
        elif 2.8125 <= self.postural_tremor_mag_y_max < 4.8800:
            self.postural_tremor_mag_y_tag = '2'
        elif 4.8800 <= self.postural_tremor_mag_y_max < 11.1875:
            self.postural_tremor_mag_y_tag = '3'
        elif 11.1875 <= self.postural_tremor_mag_y_max <= 34.4284:
           self.postural_tremor_mag_y_tag = '4'
        elif self.postural_tremor_mag_y_max > 34.4284:
            self.postural_tremor_mag_y_tag = '5'

        if self.postural_tremor_mag_z_max < 2.5312:
            self.postural_tremor_mag_z_tag = '0'
        elif 2.5312 <= self.postural_tremor_mag_z_max < 10.1382:
            self.postural_tremor_mag_z_tag = '1'
        elif 10.1382 <= self.postural_tremor_mag_z_max < 11.4558:
            self.postural_tremor_mag_z_tag = '2'
        elif 11.4558 <= self.postural_tremor_mag_z_max < 19.0320:
            self.postural_tremor_mag_z_tag = '3'
        elif 19.0320 <= self.postural_tremor_mag_z_max <= 44.8125:
           self.postural_tremor_mag_z_tag = '4'
        elif self.postural_tremor_mag_z_max > 44.8125:
            self.postural_tremor_mag_z_tag = '5'
    


    def analyze_static_tremor(self):
        #处理raw data展示部分
        if len(self.static_tremor_acc_x) == 0:
            QMessageBox.information(self, "warning", "No static tremor test data!")
            self.static_tremor_test_clicked = False
            if self.postural_tremor_test_clicked == False and self.static_tremor_test_clicked == False:
                self.tremor_test_clicked = False
            return
            
        #构建展示部分
        self.scene7 = QGraphicsScene()
        self.ui.static_tremor_raw_graphicsview.setScene(self.scene7)
        
        # 获取视口的矩形区域
        fig1 = Figure()
        ax1 = fig1.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.static_tremor_acc_x))]
        y_acc_x = self.static_tremor_acc_x
        y_gyro_x = self.static_tremor_gyro_x
        y_mag_x = self.static_tremor_mag_x
        
        ax1.plot(x, y_acc_x, color='blue', linestyle='-', label = 'acceleration')
        ax1.plot(x, y_gyro_x, color='green', linestyle='-', label = 'gyroscope')
        ax1.plot(x, y_mag_x, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax1.legend()
        ax1.set_title('X Axis Data')
        
        png_filename_1 = os.path.join(tempfile.gettempdir(), 'static_tremor_rawdata_x.png')
        canvas_1 = FigureCanvas(fig1)
        canvas_1.print_png(png_filename_1)
        pixmap_1 = QPixmap(png_filename_1)
        # 将 QPixmap 添加到 QGraphicsScene
        item_1 = QGraphicsPixmapItem(pixmap_1)
        item_1.setPos(0, 0)
        self.scene7.addItem(item_1)
        os.remove(png_filename_1)
        
        fig2 = Figure()
        ax2 = fig2.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.static_tremor_acc_y))]
        y_acc_y = self.static_tremor_acc_y
        y_gyro_y = self.static_tremor_gyro_y
        y_mag_y = self.static_tremor_mag_y
        
        ax2.plot(x, y_acc_y, color='blue', linestyle='-', label = 'acceleration')
        ax2.plot(x, y_gyro_y, color='green', linestyle='-', label = 'gyroscope')
        ax2.plot(x, y_mag_y, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax2.legend()
        ax2.set_title('Y Axis Data')
        
        png_filename_2 = os.path.join(tempfile.gettempdir(), 'static_tremor_rawdata_y.png')
        canvas_2 = FigureCanvas(fig2)
        canvas_2.print_png(png_filename_2)
        pixmap_2 = QPixmap(png_filename_2)
        # 将 QPixmap 添加到 QGraphicsScene
        item_2 = QGraphicsPixmapItem(pixmap_2)
        item_2.setPos(650, 0)
        self.scene7.addItem(item_2)
        os.remove(png_filename_2)
        
        fig3 = Figure()
        ax3 = fig3.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.static_tremor_acc_z))]
        y_acc_z = self.static_tremor_acc_z
        y_gyro_z= self.static_tremor_gyro_z
        y_mag_z = self.static_tremor_mag_z
        
        ax3.plot(x, y_acc_z, color='blue', linestyle='-', label = 'acceleration')
        ax3.plot(x, y_gyro_z, color='green', linestyle='-', label = 'gyroscope')
        ax3.plot(x, y_mag_z, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax3.legend()
        ax3.set_title('Z Axis Data')
        
        png_filename_3 = os.path.join(tempfile.gettempdir(), 'static_tremor_rawdata_z.png')
        canvas_3 = FigureCanvas(fig3)
        canvas_3.print_png(png_filename_3)
        pixmap_3 = QPixmap(png_filename_3)
        # 将 QPixmap 添加到 QGraphicsScene
        item_3 = QGraphicsPixmapItem(pixmap_3)
        item_3.setPos(1300, 0)
        self.scene7.addItem(item_3)
        os.remove(png_filename_3)
        
        #处理treated data展示部分
        
        #static tremor test
        #根据分析用户坐在椅子上时手机的相对数据，确认肌肉控制和手腕抖动情况
        # acc (x y z) 表明加速度
        # x方向加速度大则表明手腕前后移动较大 手腕肌肉控制力差
        # y方向加速度大则表明手腕左右移动较大 手腕肌肉控制力差
        # z方向加速度大则表明手腕上下移动较大 手腕肌肉控制力差
        # gyro (x y z) 表明陀螺仪 即倾斜程度
        # x方向陀螺仪参数大则表明手腕容易前后摇摆
        # y方向陀螺仪参数大则表明手腕容易左右摇摆
        # z方向陀螺仪参数大则表明手腕容易上下摇摆
        # mag (x y z)为相对位置 此处进行差距最大值处理
        # x方向参数大则表明手腕存在前后快速摇摆现象
        # y方向参数大则表明手腕存在左右快速摇摆现象
        # z方向参数大则表明手腕存在上下快速摇摆现象
        
        #对于采集的九种数据分别进行处理
        
        # acc x 
        # number = 19
        # Q0 = -0.0876
        # Q1 = -0.0637
        # Q2 = -0.0361
        # Q3 = 0.0018
        # Q4 = 0.3451
        
        # acc y 
        # number = 19
        # Q0 = -0.1439
        # Q1 = -0.0829
        # Q2 = -0.0343
        # Q3 = 0.0027
        # Q4 = 0.1078
        
        # acc z 
        # number = 19
        # Q0 = -0.1269
        # Q1 = -0.0587
        # Q2 = -0.0009
        # Q3 = 0.0216
        # Q4 = 0.0781
        
        
        #构建展示部分
        self.scene8 = QGraphicsScene()
        self.ui.static_tremor_treated_graphicsview.setScene(self.scene8)

        # 获取视口的矩形区域
        fig4 = Figure()
        ax4 = fig4.add_subplot(111)
        #处理五条基本数据划分的区域
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values1 = [-0.0876, -0.0637, -0.0361, 0.0018, 0.3451]  # 四个部分的数据值
        values1_new = [i + 0.1 for i in values1]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars1 = ax4.bar(x, values1_new, width, bottom=-0.1, color=colors)

        # 添加比较值的标记线
        ax4.axhline(y=self.static_tremor_acc_x_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax4.set_xlabel('Quartiles')
        ax4.set_ylabel('Values')
        ax4.set_title('Acceleration X')
        ax4.set_xticks(x)
        ax4.set_xticklabels(categories)
        ax4.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_4= os.path.join(tempfile.gettempdir(), 'static_tremor_treated_acc_x.png')
        canvas_4 = FigureCanvas(fig4)
        canvas_4.print_png(png_filename_4)
        pixmap_4 = QPixmap(png_filename_4)
        # 将 QPixmap 添加到 QGraphicsScene
        item_4 = QGraphicsPixmapItem(pixmap_4)
        item_4.setPos(0, 0)
        self.scene8.addItem(item_4)
        os.remove(png_filename_4)
        
        fig5 = Figure()
        ax5 = fig5.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values2 = [ -0.1439, -0.0829,  -0.0343,  0.0027,   0.1078]  # 四个部分的数据值
        values2_new = [i + 0.2 for i in values2]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars2 = ax5.bar(x, values2_new, width, bottom=-0.2, color=colors)

        # 添加比较值的标记线
        ax5.axhline(y=self.static_tremor_acc_y_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax5.set_xlabel('Quartiles')
        ax5.set_ylabel('Values')
        ax5.set_title('Acceleration Y')
        ax5.set_xticks(x)
        ax5.set_xticklabels(categories)
        ax5.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_5= os.path.join(tempfile.gettempdir(), 'static_tremor_treated_acc_y.png')
        canvas_5 = FigureCanvas(fig5)
        canvas_5.print_png(png_filename_5)
        pixmap_5 = QPixmap(png_filename_5)
        # 将 QPixmap 添加到 QGraphicsScene
        item_5 = QGraphicsPixmapItem(pixmap_5)
        item_5.setPos(650, 0)
        self.scene8.addItem(item_5)
        os.remove(png_filename_5)
        
        fig6 = Figure()
        ax6 = fig6.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values3 = [ -0.1269,-0.0587, -0.0009, 0.0216, 0.0781]  # 四个部分的数据值
        values3_new = [i + 0.2 for i in values3]
        # Q0 = -0.1269
        # Q1 = -0.0587
        # Q2 = -0.0009
        # Q3 = 0.0216
        # Q4 = 0.0781
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars3 = ax6.bar(x, values3_new, width, bottom=-0.2, color=colors)

        # 添加比较值的标记线
        ax6.axhline(y=self.static_tremor_acc_z_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax6.set_xlabel('Quartiles')
        ax6.set_ylabel('Values')
        ax6.set_title('Acceleration Z')
        ax6.set_xticks(x)
        ax6.set_xticklabels(categories)
        ax6.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_6= os.path.join(tempfile.gettempdir(), 'static_tremor_treated_acc_z.png')
        canvas_6 = FigureCanvas(fig6)
        canvas_6.print_png(png_filename_6)
        pixmap_6 = QPixmap(png_filename_6)
        # 将 QPixmap 添加到 QGraphicsScene
        item_6 = QGraphicsPixmapItem(pixmap_6)
        item_6.setPos(1300, 0)
        self.scene8.addItem(item_6)
        os.remove(png_filename_6)
        
        #处理postural tremor test tag(acc)
        if self.static_tremor_acc_x_avg < -0.0876:
            self.static_tremor_acc_x_tag = '0'
        elif -0.0876 <= self.static_tremor_acc_x_avg < -0.0637:
            self.static_tremor_acc_x_tag = '1'
        elif -0.0637 <= self.static_tremor_acc_x_avg < -0.0361:
            self.static_tremor_acc_x_tag = '2'
        elif -0.0361 <= self.static_tremor_acc_x_avg < 0.0018:
            self.static_tremor_acc_x_tag = '3'
        elif 0.0018 <= self.static_tremor_acc_x_avg <=  0.3451:
            self.static_tremor_acc_x_tag = '4'
        elif self.static_tremor_acc_x_avg >  0.3451:
            self.static_tremor_acc_x_tag = '5'

        if self.static_tremor_acc_y_avg < -0.1439:
            self.static_tremor_acc_y_tag = '0'
        elif -0.1439 <= self.static_tremor_acc_y_avg < -0.0829:
            self.static_tremor_acc_y_tag = '1'
        elif -0.0829 <= self.static_tremor_acc_y_avg < -0.0343:
            self.static_tremor_acc_y_tag = '2'
        elif -0.0343 <= self.static_tremor_acc_y_avg <  0.0027:
            self.static_tremor_acc_y_tag = '3'
        elif  0.0027 <= self.static_tremor_acc_y_avg <= 0.1078 :
            self.static_tremor_acc_y_tag = '4'
        elif self.static_tremor_acc_y_avg > 0.1078 :
            self.static_tremor_acc_y_tag = '5'

        if self.static_tremor_acc_z_avg <  -0.1269:
            self.static_tremor_acc_z_tag = '0'
        elif -0.1269 <= self.static_tremor_acc_z_avg < -0.0587:
            self.static_tremor_acc_z_tag = '1'
        elif -0.0587 <= self.static_tremor_acc_z_avg < -0.0009:
            self.static_tremor_acc_z_tag = '2'
        elif -0.0009 <= self.static_tremor_acc_z_avg < 0.0216:
            self.static_tremor_acc_z_tag = '3'
        elif 0.0216 <= self.static_tremor_acc_z_avg <=  0.0781:
            self.static_tremor_acc_z_tag = '4'
        elif self.static_tremor_acc_z_avg >  0.0781:
            self.static_tremor_acc_z_tag = '5'    
        
        #gyro x 
        # number = 19
        # Q0 = -0.0607
        # Q1 = -0.0224
        # Q2 = -0.0030
        # Q3 = 0.0904
        # Q4 = 0.1215
        
        # gyro y 
        # number = 19
        # Q0 = -0.2445
        # Q1 = -0.1739
        # Q2 = -0.0101
        # Q3 = 0.0027
        # Q4 = 0.0148
        
        # gyro z 
        # number = 19
        # Q0 = -0.0330
        # Q1 = -0.0206
        # Q2 = -0.0004
        # Q3 = 0.0046
        # Q4 = 0.0515
        
        
        # 获取视口的矩形区域
        fig7 = Figure()
        ax7 = fig7.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values4 = [ -0.0607,-0.0224, -0.0030,  0.0904, 0.1215]  # 四个部分的数据值
        values4_new = [i + 0.1 for i in values4]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars4 = ax7.bar(x, values4_new, width, bottom=-0.1, color=colors)

        # 添加比较值的标记线
        ax7.axhline(y=self.static_tremor_gyro_x_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax7.set_xlabel('Quartiles')
        ax7.set_ylabel('Values')
        ax7.set_title('Gyroscope X')
        ax7.set_xticks(x)
        ax7.set_xticklabels(categories)
        ax7.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_7= os.path.join(tempfile.gettempdir(), 'static_tremor_treated_gyro_x.png')
        canvas_7 = FigureCanvas(fig7)
        canvas_7.print_png(png_filename_7)
        pixmap_7 = QPixmap(png_filename_7)
        # 将 QPixmap 添加到 QGraphicsScene
        item_7 = QGraphicsPixmapItem(pixmap_7)
        item_7.setPos(1950, 0)
        self.scene8.addItem(item_7)
        os.remove(png_filename_7)
        
        fig8 = Figure()
        ax8 = fig8.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values5 = [ -0.2445, -0.1739, -0.0101,  0.0027, 0.0148]  # 四个部分的数据值
        values5_new = [i + 0.3 for i in values5]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars5 = ax8.bar(x, values5_new, width, bottom=-0.3, color=colors)

        # 添加比较值的标记线
        ax8.axhline(y=self.static_tremor_gyro_y_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax8.set_xlabel('Quartiles')
        ax8.set_ylabel('Values')
        ax8.set_title('Gyroscope Y')
        ax8.set_xticks(x)
        ax8.set_xticklabels(categories)
        ax8.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_8= os.path.join(tempfile.gettempdir(), 'static_tremor_treated_gyro_y.png')
        canvas_8 = FigureCanvas(fig8)
        canvas_8.print_png(png_filename_8)
        pixmap_8 = QPixmap(png_filename_8)
        # 将 QPixmap 添加到 QGraphicsScene
        item_8= QGraphicsPixmapItem(pixmap_8)
        item_8.setPos(2600, 0)
        self.scene8.addItem(item_8)
        os.remove(png_filename_8)
        
        fig9 = Figure()
        ax9 = fig9.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values6 = [-0.0330, -0.0206,  -0.0004, 0.0046, 0.0515]  # 四个部分的数据值
        values6_new = [i + 0.1 for i in values6]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars6 = ax9.bar(x, values6_new, width, bottom=-0.1, color=colors)

        # 添加比较值的标记线
        ax9.axhline(y=self.static_tremor_gyro_z_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax9.set_xlabel('Quartiles')
        ax9.set_ylabel('Values')
        ax9.set_title('Gyroscope Z')
        ax9.set_xticks(x)
        ax9.set_xticklabels(categories)
        ax9.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_9= os.path.join(tempfile.gettempdir(), 'static_tremor_treated_gyro_z.png')
        canvas_9 = FigureCanvas(fig9)
        canvas_9.print_png(png_filename_9)
        pixmap_9 = QPixmap(png_filename_9)
        # 将 QPixmap 添加到 QGraphicsScene
        item_9= QGraphicsPixmapItem(pixmap_9)
        item_9.setPos(3250, 0)
        self.scene8.addItem(item_9)
        os.remove(png_filename_9)
        
        
        #处理walking test tag(gyro)
        if self.static_tremor_gyro_x_avg < -0.0607:
            self.static_tremor_gyro_x_tag = '0'
        elif -0.0607 <= self.static_tremor_gyro_x_avg < -0.0224:
            self.static_tremor_gyro_x_tag = '1'
        elif -0.0224 <= self.static_tremor_gyro_x_avg < -0.0030:
            self.static_tremor_gyro_x_tag = '2'
        elif -0.0030 <= self.static_tremor_gyro_x_avg < 0.0904:
            self.static_tremor_gyro_x_tag = '3'
        elif 0.0904 <= self.static_tremor_gyro_x_avg <= 0.1215:
            self.static_tremor_gyro_x_tag = '4'
        elif self.static_tremor_gyro_x_avg > 0.1215:
            self.static_tremor_gyro_x_tag = '5'

        if self.static_tremor_gyro_y_avg < -0.2445:
            self.static_tremor_gyro_y_tag = '0'
        elif -0.2445 <= self.static_tremor_gyro_y_avg < -0.1739:
            self.static_tremor_gyro_y_tag = '1'
        elif -0.1739 <= self.static_tremor_gyro_y_avg < -0.0101:
            self.static_tremor_gyro_y_tag = '2'
        elif -0.0101 <= self.static_tremor_gyro_y_avg < 0.0027:
            self.static_tremor_gyro_y_tag = '3'
        elif 0.0027 <= self.static_tremor_gyro_y_avg <= 0.0148:
            self.static_tremor_gyro_y_tag = '4'
        elif self.static_tremor_gyro_y_avg > 0.0148:
            self.static_tremor_gyro_y_tag = '5'
        
        if self.static_tremor_gyro_z_avg < -0.0330:
            self.static_tremor_gyro_z_tag = '0'
        elif -0.0330 <= self.static_tremor_gyro_z_avg <  -0.0206:
            self.static_tremor_gyro_z_tag = '1'
        elif  -0.0206 <= self.static_tremor_gyro_z_avg < -0.0004:
            self.static_tremor_gyro_z_tag = '2'
        elif -0.0004 <= self.static_tremor_gyro_z_avg < 0.0046:
            self.static_tremor_gyro_z_tag = '3'
        elif 0.0046 <= self.static_tremor_gyro_z_avg <= 0.0515:
            self.static_tremor_gyro_z_tag = '4'
        elif self.static_tremor_gyro_z_avg > 0.0515:
            self.static_tremor_gyro_z_tag = '5'
        
        #mag x 
        # number = 19
        # Q0 = 0.3172
        # Q1 = 1.2000
        # Q2 = 4.3066
        # Q3 = 7.0000
        # Q4 = 9.2500
        
        # mag y 
        # number = 19
        # Q0 = 0.1220
        # Q1 = 2.5000
        # Q2 = 3.7088
        # Q3 = 5.3192
        # Q4 = 10.8750
        
        # mag z 
        # number = 19
        # Q0 = 0.2928
        # Q1 = 0.9150
        # Q2 = 9.2354
        # Q3 = 12.9970
        # Q4 = 16.9375
        
        # 获取视口的矩形区域
        fig10 = Figure()
        ax10 = fig10.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values7 = [  0.3172, 1.2000,  4.3066, 7.0000, 9.2500]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars7 = ax10.bar(x, values7, width, color=colors)

        # 添加比较值的标记线
        ax10.axhline(y=self.static_tremor_mag_x_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax10.set_xlabel('Quartiles')
        ax10.set_ylabel('Values')
        ax10.set_title('Coordination X')
        ax10.set_xticks(x)
        ax10.set_xticklabels(categories)
        ax10.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_10= os.path.join(tempfile.gettempdir(), 'static_tremor_treated_mag_x.png')
        canvas_10 = FigureCanvas(fig10)
        canvas_10.print_png(png_filename_10)
        pixmap_10 = QPixmap(png_filename_10)
        # 将 QPixmap 添加到 QGraphicsScene
        item_10= QGraphicsPixmapItem(pixmap_10)
        item_10.setPos(3900, 0)
        self.scene8.addItem(item_10)
        os.remove(png_filename_10)
        
        fig11 = Figure()
        ax11 = fig11.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values8 = [ 0.1220, 2.5000,  3.7088,5.3192,   10.8750]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars8= ax11.bar(x, values8, width, color=colors)

        # 添加比较值的标记线
        ax11.axhline(y=self.static_tremor_mag_y_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax11.set_xlabel('Quartiles')
        ax11.set_ylabel('Values')
        ax11.set_title('Coordination Y')
        ax11.set_xticks(x)
        ax11.set_xticklabels(categories)
        ax11.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_11= os.path.join(tempfile.gettempdir(), 'static_tremor_treated_mag_y.png')
        canvas_11 = FigureCanvas(fig11)
        canvas_11.print_png(png_filename_11)
        pixmap_11 = QPixmap(png_filename_11)
        # 将 QPixmap 添加到 QGraphicsScene
        item_11= QGraphicsPixmapItem(pixmap_11)
        item_11.setPos(4550, 0)
        self.scene8.addItem(item_11)
        os.remove(png_filename_11)
        
        fig12 = Figure()
        ax12 = fig12.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values9 = [ 0.2928, 0.9150, 9.2354, 12.9970,  16.9375]  # 四个部分的数据值
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars9= ax12.bar(x, values9, width, color=colors)

        # 添加比较值的标记线
        ax12.axhline(y=self.static_tremor_mag_z_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax12.set_xlabel('Quartiles')
        ax12.set_ylabel('Values')
        ax12.set_title('Coordination Z')
        ax12.set_xticks(x)
        ax12.set_xticklabels(categories)
        ax12.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_12= os.path.join(tempfile.gettempdir(), 'static_treated_mag_z.png')
        canvas_12 = FigureCanvas(fig12)
        canvas_12.print_png(png_filename_12)
        pixmap_12 = QPixmap(png_filename_12)
        # 将 QPixmap 添加到 QGraphicsScene
        item_12= QGraphicsPixmapItem(pixmap_12)
        item_12.setPos(5200, 0)
        self.scene8.addItem(item_12)
        os.remove(png_filename_12)

        #处理walking test tag(mag)
        if self.static_tremor_mag_x_max <  0.3172:
            self.static_tremor_mag_x_tag = '0'
        elif  0.3172 <= self.static_tremor_mag_x_max < 1.2000:
            self.static_tremor_mag_x_tag = '1'
        elif 1.2000 <= self.static_tremor_mag_x_max < 4.3066:
            self.static_tremor_mag_x_tag = '2'
        elif 4.3066 <= self.static_tremor_mag_x_max < 7.0000:
            self.static_tremor_mag_x_tag = '3'
        elif 7.0000 <= self.static_tremor_mag_x_max <=  9.25000:
           self.static_tremor_mag_x_tag = '4'
        elif self.static_tremor_mag_x_max > 9.2500:
            self.static_tremor_mag_x_tag = '5'

        if self.static_tremor_mag_y_max < 0.1220:
            self.static_tremor_mag_y_tag = '0'
        elif 0.1220 <= self.static_tremor_mag_y_max < 2.5000:
            self.static_tremor_mag_y_tag = '1'
        elif 2.5000 <= self.static_tremor_mag_y_max < 3.7088:
            self.static_tremor_mag_y_tag = '2'
        elif 3.7088 <= self.static_tremor_mag_y_max < 5.3192:
            self.static_tremor_mag_y_tag = '3'
        elif 5.3192 <= self.static_tremor_mag_y_max <= 10.8750:
           self.static_tremor_mag_y_tag = '4'
        elif self.static_tremor_mag_y_max > 10.8750:
            self.static_tremor_mag_y_tag = '5'

        if self.static_tremor_mag_z_max < 0.2928:
            self.static_tremor_mag_z_tag = '0'
        elif 0.2928 <= self.static_tremor_mag_z_max < 0.9150:
            self.static_tremor_mag_z_tag = '1'
        elif 0.9150 <= self.static_tremor_mag_z_max < 9.2354:
            self.static_tremor_mag_z_tag = '2'
        elif 9.2354 <= self.static_tremor_mag_z_max < 12.9970:
            self.static_tremor_mag_z_tag = '3'
        elif 12.9970 <= self.static_tremor_mag_z_max <= 16.9375:
           self.static_tremor_mag_z_tag = '4'
        elif self.static_tremor_mag_z_max > 16.9375:
            self.static_tremor_mag_z_tag = '5'
        
    
    def analyze_turning_test(self):
        self.turning_test_clicked = True
        #处理raw data展示部分
        if len(self.turning_acc_x) == 0:
            QMessageBox.information(self, "warning", "No turning test data!")
            self.turning_test_clicked = False
            return
        #构建展示部分
        self.scene9 = QGraphicsScene()
        self.ui.turning_raw_graphicsview.setScene(self.scene9)
        
        # 获取视口的矩形区域
        fig1 = Figure()
        ax1 = fig1.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.turning_acc_x))]
        y_acc_x = self.turning_acc_x
        y_gyro_x = self.turning_gyro_x
        y_mag_x = self.turning_mag_x
        
        ax1.plot(x, y_acc_x, color='blue', linestyle='-', label = 'acceleration')
        ax1.plot(x, y_gyro_x, color='green', linestyle='-', label = 'gyroscope')
        ax1.plot(x, y_mag_x, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax1.legend()
        ax1.set_title('X Axis Data')
        
        png_filename_1 = os.path.join(tempfile.gettempdir(), 'turning_rawdata_x.png')
        canvas_1 = FigureCanvas(fig1)
        canvas_1.print_png(png_filename_1)
        pixmap_1 = QPixmap(png_filename_1)
        # 将 QPixmap 添加到 QGraphicsScene
        item_1 = QGraphicsPixmapItem(pixmap_1)
        item_1.setPos(0, 0)
        self.scene9.addItem(item_1)
        os.remove(png_filename_1)
        
        fig2 = Figure()
        ax2 = fig2.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.turning_acc_y))]
        y_acc_y = self.turning_acc_y
        y_gyro_y = self.turning_gyro_y
        y_mag_y = self.turning_mag_y
        
        ax2.plot(x, y_acc_y, color='blue', linestyle='-', label = 'acceleration')
        ax2.plot(x, y_gyro_y, color='green', linestyle='-', label = 'gyroscope')
        ax2.plot(x, y_mag_y, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax2.legend()
        ax2.set_title('Y Axis Data')
        
        png_filename_2 = os.path.join(tempfile.gettempdir(), 'turning_rawdata_y.png')
        canvas_2 = FigureCanvas(fig2)
        canvas_2.print_png(png_filename_2)
        pixmap_2 = QPixmap(png_filename_2)
        # 将 QPixmap 添加到 QGraphicsScene
        item_2 = QGraphicsPixmapItem(pixmap_2)
        item_2.setPos(650, 0)
        self.scene9.addItem(item_2)
        os.remove(png_filename_2)
        
        fig3 = Figure()
        ax3 = fig3.add_subplot(111) 
        #处理五条基本数据划分的区域
        x = [i+1 for i in range(len(self.turning_acc_z))]
        y_acc_z = self.turning_acc_z
        y_gyro_z= self.turning_gyro_z
        y_mag_z = self.turning_mag_z
        
        ax3.plot(x, y_acc_z, color='blue', linestyle='-', label = 'acceleration')
        ax3.plot(x, y_gyro_z, color='green', linestyle='-', label = 'gyroscope')
        ax3.plot(x, y_mag_z, color='orange', linestyle='-', label = 'coordinate')
        #画出用户数据所在位置（红线）
        ax3.legend()
        ax3.set_title('Z Axis Data')
        
        png_filename_3 = os.path.join(tempfile.gettempdir(), 'turning_rawdata_z.png')
        canvas_3 = FigureCanvas(fig3)
        canvas_3.print_png(png_filename_3)
        pixmap_3 = QPixmap(png_filename_3)
        # 将 QPixmap 添加到 QGraphicsScene
        item_3 = QGraphicsPixmapItem(pixmap_3)
        item_3.setPos(1300, 0)
        self.scene9.addItem(item_3)
        os.remove(png_filename_3)
        
        #处理treated data展示部分
        
        #turning test
        # 根据分析用户直线行走和转向过程中手机测量数据，对用户行走时身体协调情况进行分析
        # acc (x y z) 标明加速度 
        # x方向加速度过大则表明移动较快   加速度小则表明移动迟缓
        # y方向加速度过大则左右移动快  转向时距离差距较大
        # z方向加速度过大则上下移动快 可能有膝盖弯曲等情况
        # gyro (x y z) 标明陀螺仪 即倾斜程度
        # x方向陀螺仪参数大则步伐不稳定 肌肉控制能力较差
        # y方向陀螺仪参数大则左右不稳定 容易向侧方向跌倒
        # z方向陀螺仪参数大则上下不稳定 容易前倾或后仰
        # mag 参数表明相对位置 此处取差距最大值处理
        # x z对应方向参数大则表明对应方向快速偏移较多 对应方向稳定性差
        # y方向参数大则表明转向时侧方向偏移较多 转向时身体控制力差
        
        # acc x 
        # number = 19
        # Q0 = -0.1980
        # Q1 = -0.0600
        # Q2 = 0.0078
        # Q3 = 0.0251
        # Q4 = 0.2169
        
        # acc y 
        # number = 19
        # Q0 = -0.2378
        # Q1 = -0.2136
        # Q2 = -0.0778
        # Q3 = -0.0345
        # Q4 = 0.0359
        
        # acc z 
        # number = 19
        # Q0 = -0.1041
        # Q1 = -0.0306
        # Q2 = 0.0111
        # Q3 = 0.0449
        # Q4 = 0.1815
        
        
        #构建展示部分
        self.scene10 = QGraphicsScene()
        self.ui.turning_treated_graphicsview.setScene(self.scene10)

        # 获取视口的矩形区域
        fig4 = Figure()
        ax4 = fig4.add_subplot(111)
        #处理五条基本数据划分的区域
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values1 = [-0.1980, -0.0600, 0.0078, 0.0251, 0.2169]  # 四个部分的数据值
        values1_new = [i + 0.3 for i in values1]

        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars1 = ax4.bar(x, values1_new, width, bottom=-0.3, color=colors)

        # 添加比较值的标记线
        ax4.axhline(y=self.turning_acc_x_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax4.set_xlabel('Quartiles')
        ax4.set_ylabel('Values')
        ax4.set_title('Acceleration X')
        ax4.set_xticks(x)
        ax4.set_xticklabels(categories)
        ax4.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_4= os.path.join(tempfile.gettempdir(), 'turning_treated_acc_x.png')
        canvas_4 = FigureCanvas(fig4)
        canvas_4.print_png(png_filename_4)
        pixmap_4 = QPixmap(png_filename_4)
        # 将 QPixmap 添加到 QGraphicsScene
        item_4 = QGraphicsPixmapItem(pixmap_4)
        item_4.setPos(0, 0)
        self.scene10.addItem(item_4)
        os.remove(png_filename_4)
        
        fig5 = Figure()
        ax5 = fig5.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values2 = [ -0.2378, -0.2136,  -0.0778, -0.0345, 0.0359]  # 四个部分的数据值
        values2_new = [i + 0.3 for i in values2]

        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars2 = ax5.bar(x, values2_new, width, bottom=-0.3, color=colors)

        # 添加比较值的标记线
        ax5.axhline(y=self.turning_acc_y_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax5.set_xlabel('Quartiles')
        ax5.set_ylabel('Values')
        ax5.set_title('Acceleration Y')
        ax5.set_xticks(x)
        ax5.set_xticklabels(categories)
        ax5.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_5= os.path.join(tempfile.gettempdir(), 'turning_treated_acc_y.png')
        canvas_5 = FigureCanvas(fig5)
        canvas_5.print_png(png_filename_5)
        pixmap_5 = QPixmap(png_filename_5)
        # 将 QPixmap 添加到 QGraphicsScene
        item_5 = QGraphicsPixmapItem(pixmap_5)
        item_5.setPos(650, 0)
        self.scene10.addItem(item_5)
        os.remove(png_filename_5)
        
        fig6 = Figure()
        ax6 = fig6.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values3 = [ -0.1041,-0.0306,  0.0111,  0.0449,  0.1815]  # 四个部分的数据值
        values3_new = [i + 0.2 for i in values3]
        
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars3 = ax6.bar(x, values3_new, width, bottom=-0.2, color=colors)

        # 添加比较值的标记线
        ax6.axhline(y=self.turning_acc_z_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax6.set_xlabel('Quartiles')
        ax6.set_ylabel('Values')
        ax6.set_title('Acceleration Z')
        ax6.set_xticks(x)
        ax6.set_xticklabels(categories)
        ax6.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_6= os.path.join(tempfile.gettempdir(), 'turning_treated_acc_z.png')
        canvas_6 = FigureCanvas(fig6)
        canvas_6.print_png(png_filename_6)
        pixmap_6 = QPixmap(png_filename_6)
        # 将 QPixmap 添加到 QGraphicsScene
        item_6 = QGraphicsPixmapItem(pixmap_6)
        item_6.setPos(1300, 0)
        self.scene10.addItem(item_6)
        os.remove(png_filename_6)
        
        #处理turning test tag(acc)
        if self.turning_acc_x_avg < -0.1980:
            self.turning_acc_x_tag = '0'
        elif -0.1980 <= self.turning_acc_x_avg < -0.0600:
            self.turning_acc_x_tag = '1'
        elif -0.0600 <= self.turning_acc_x_avg < 0.0078:
            self.turning_acc_x_tag = '2'
        elif 0.0078 <= self.turning_acc_x_avg < 0.0251:
            self.turning_acc_x_tag = '3'
        elif 0.0251 <= self.turning_acc_x_avg <= 0.2169:
            self.turning_acc_x_tag = '4'
        elif self.turning_acc_x_avg > 0.2169:
            self.turning_acc_x_tag = '5'

        if self.turning_acc_y_avg < -0.2378:
            self.turning_acc_y_tag = '0'
        elif -0.2378 <= self.turning_acc_y_avg < -0.2136:
            self.turning_acc_y_tag = '1'
        elif -0.2136 <= self.turning_acc_y_avg < -0.0778:
            self.turning_acc_y_tag = '2'
        elif -0.0778 <= self.turning_acc_y_avg < -0.0345:
            self.turning_acc_y_tag = '3'
        elif -0.0345 <= self.turning_acc_y_avg <= 0.0359:
            self.turning_acc_y_tag = '4'
        elif self.turning_acc_y_avg > 0.0359:
            self.turning_acc_y_tag = '5'
            
        if self.turning_acc_z_avg < -0.1041:
            self.turning_acc_z_tag = '0'
        elif -0.1041 <= self.turning_acc_z_avg < -0.0306:
            self.turning_acc_z_tag = '1'
        elif -0.0306 <= self.turning_acc_z_avg < 0.0111:
            self.turning_acc_z_tag = '2'
        elif 0.0111 <= self.turning_acc_z_avg < 0.0449:
            self.turning_acc_z_tag = '3'
        elif 0.0449 <= self.turning_acc_z_avg <= 0.1815:
            self.turning_acc_z_tag = '4'
        elif self.turning_acc_z_avg > 0.1815:
            self.turning_acc_z_tag = '5'
        
        #gyro x 
        # number = 19
        # Q0 = -0.0751
        # Q1 = -0.0119
        # Q2 = 0.0111
        # Q3 = 0.0404
        # Q4 = 0.1181
        
        # gyro y 
        # number = 19
        # Q0 = -0.1413
        # Q1 = -0.0301
        # Q2 = 0.0377
        # Q3 = 0.1172
        # Q4 = 0.2453
        
        # gyro z 
        # number = 19
        # Q0 = -0.1212
        # Q1 = -0.0462
        # Q2 = 0.0246
        # Q3 = 0.0582
        # Q4 = 0.0999
        
        
        # 获取视口的矩形区域
        fig7 = Figure()
        ax7 = fig7.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values4 = [  -0.0751,-0.0119,  0.0111,  0.0404,  0.1181]  # 四个部分的数据值
        values4_new = [i + 0.1 for i in values4]
    
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars4 = ax7.bar(x, values4_new, width, bottom=-0.1, color=colors)

        # 添加比较值的标记线
        ax7.axhline(y=self.turning_gyro_x_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax7.set_xlabel('Quartiles')
        ax7.set_ylabel('Values')
        ax7.set_title('Gyroscope X')
        ax7.set_xticks(x)
        ax7.set_xticklabels(categories)
        ax7.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_7= os.path.join(tempfile.gettempdir(), 'turning_treated_gyro_x.png')
        canvas_7 = FigureCanvas(fig7)
        canvas_7.print_png(png_filename_7)
        pixmap_7 = QPixmap(png_filename_7)
        # 将 QPixmap 添加到 QGraphicsScene
        item_7 = QGraphicsPixmapItem(pixmap_7)
        item_7.setPos(1950, 0)
        self.scene10.addItem(item_7)
        os.remove(png_filename_7)
        
        fig8 = Figure()
        ax8 = fig8.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values5 = [  -0.1413, -0.0301,  0.0377, 0.1172, 0.2453]  # 四个部分的数据值
        values5_new = [i + 0.2 for i in values5]

        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars5 = ax8.bar(x, values5_new, width, bottom=-0.2, color=colors)

        # 添加比较值的标记线
        ax8.axhline(y=self.turning_gyro_y_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax8.set_xlabel('Quartiles')
        ax8.set_ylabel('Values')
        ax8.set_title('Gyroscope Y')
        ax8.set_xticks(x)
        ax8.set_xticklabels(categories)
        ax8.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_8= os.path.join(tempfile.gettempdir(), 'turning_treated_gyro_y.png')
        canvas_8 = FigureCanvas(fig8)
        canvas_8.print_png(png_filename_8)
        pixmap_8 = QPixmap(png_filename_8)
        # 将 QPixmap 添加到 QGraphicsScene
        item_8= QGraphicsPixmapItem(pixmap_8)
        item_8.setPos(2600, 0)
        self.scene10.addItem(item_8)
        os.remove(png_filename_8)
        
        fig9 = Figure()
        ax9 = fig9.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values6 = [ -0.1212, -0.0462,  0.0246, 0.0582, 0.0999]  # 四个部分的数据值
        values6_new = [i + 0.2 for i in values6]
        
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars6 = ax9.bar(x, values6_new, width, bottom=-0.2, color=colors)

        # 添加比较值的标记线
        ax9.axhline(y=self.turning_gyro_z_avg, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax9.set_xlabel('Quartiles')
        ax9.set_ylabel('Values')
        ax9.set_title('Gyroscope Z')
        ax9.set_xticks(x)
        ax9.set_xticklabels(categories)
        ax9.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_9= os.path.join(tempfile.gettempdir(), 'turning_treated_gyro_z.png')
        canvas_9 = FigureCanvas(fig9)
        canvas_9.print_png(png_filename_9)
        pixmap_9 = QPixmap(png_filename_9)
        # 将 QPixmap 添加到 QGraphicsScene
        item_9= QGraphicsPixmapItem(pixmap_9)
        item_9.setPos(3250, 0)
        self.scene10.addItem(item_9)
        os.remove(png_filename_9)
        
        #处理turning test tag(gyro)
        if self.turning_gyro_x_avg < -0.0751:
            self.turning_gyro_x_tag = '0'
        elif -0.0751 <= self.turning_gyro_x_avg < -0.0119:
            self.turning_gyro_x_tag = '1'
        elif -0.0119 <= self.turning_gyro_x_avg < 0.0111:
            self.turning_gyro_x_tag = '2'
        elif 0.0111 <= self.turning_gyro_x_avg < 0.0404:
            self.turning_gyro_x_tag = '3'
        elif 0.0404 <= self.turning_gyro_x_avg <= 0.1181:
            self.turning_gyro_x_tag = '4'
        elif self.turning_gyro_x_avg > 0.1181:
            self.turning_gyro_x_tag = '5'

        if self.turning_gyro_y_avg < -0.1413:
            self.turning_gyro_y_tag = '0'
        elif  -0.1413 <= self.turning_gyro_y_avg < -0.0301:
            self.turning_gyro_y_tag = '1'
        elif -0.0301 <= self.turning_gyro_y_avg < 0.0377:
            self.turning_gyro_y_tag = '2'
        elif 0.0377 <= self.turning_gyro_y_avg < 0.1172:
            self.turning_gyro_y_tag = '3'
        elif 0.1172 <= self.turning_gyro_y_avg <= 0.2453:
            self.turning_gyro_y_tag = '4'
        elif self.turning_gyro_y_avg > 0.2453:
            self.turning_gyro_y_tag = '5'

        if self.turning_gyro_z_avg <  -0.1212:
            self.turning_gyro_z_tag = '0'
        elif  -0.1212 <= self.turning_gyro_z_avg < -0.0462:
            self.turning_gyro_z_tag = '1'
        elif -0.0462 <= self.turning_gyro_z_avg < 0.0246:
            self.turning_gyro_z_tag = '2'
        elif  0.0246 <= self.turning_gyro_z_avg < 0.0582:
            self.turning_gyro_z_tag = '3'
        elif 0.0582 <= self.turning_gyro_z_avg <= 0.0999:
            self.turning_gyro_z_tag = '4'
        elif self.turning_gyro_z_avg > 0.0999:
            self.turning_gyro_z_tag = '5'
        
        #mag x 
        # number = 19
        # Q0 = 4.2000
        # Q1 = 6.1854
        # Q2 = 9.4062
        # Q3 = 15.5625
        # Q4 = 27.8125
        
        # mag y 
        # number = 19
        # Q0 = 4.6125
        # Q1 = 7.0688
        # Q2 = 8.9438
        # Q3 = 17.8486
        # Q4 = 30.5000
        
        # mag z 
        # number = 19
        # Q0 = 3.5380
        # Q1 = 5.5022
        # Q2 = 8.0625
        # Q3 = 25.6250
        # Q4 = 37.8688
        
        # 获取视口的矩形区域
        fig10 = Figure()
        ax10 = fig10.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values7 = [  4.2000, 6.1854,  9.4062,  15.5625,  27.8125]  # 四个部分的数据值

       
        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars7 = ax10.bar(x, values7, width, color=colors)

        # 添加比较值的标记线
        ax10.axhline(y=self.turning_mag_x_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax10.set_xlabel('Quartiles')
        ax10.set_ylabel('Values')
        ax10.set_title('Coordination X')
        ax10.set_xticks(x)
        ax10.set_xticklabels(categories)
        ax10.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_10= os.path.join(tempfile.gettempdir(), 'turning_treated_mag_x.png')
        canvas_10 = FigureCanvas(fig10)
        canvas_10.print_png(png_filename_10)
        pixmap_10 = QPixmap(png_filename_10)
        # 将 QPixmap 添加到 QGraphicsScene
        item_10= QGraphicsPixmapItem(pixmap_10)
        item_10.setPos(3900, 0)
        self.scene10.addItem(item_10)
        os.remove(png_filename_10)
        
        fig11 = Figure()
        ax11 = fig11.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values8 = [ 4.6125, 7.0688,  8.9438, 17.8486,  30.5000]  # 四个部分的数据值
       

        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars8= ax11.bar(x, values8, width, color=colors)

        # 添加比较值的标记线
        ax11.axhline(y=self.turning_mag_y_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax11.set_xlabel('Quartiles')
        ax11.set_ylabel('Values')
        ax11.set_title('Coordination Y')
        ax11.set_xticks(x)
        ax11.set_xticklabels(categories)
        ax11.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_11= os.path.join(tempfile.gettempdir(), 'turning_treated_mag_y.png')
        canvas_11 = FigureCanvas(fig11)
        canvas_11.print_png(png_filename_11)
        pixmap_11 = QPixmap(png_filename_11)
        # 将 QPixmap 添加到 QGraphicsScene
        item_11= QGraphicsPixmapItem(pixmap_11)
        item_11.setPos(4550, 0)
        self.scene10.addItem(item_11)
        os.remove(png_filename_11)
        
        fig12 = Figure()
        ax12 = fig12.add_subplot(111)
        categories = ['below 0%', '0%-25%', '25%-50%', '50%-75%', '75%-100%']
        values9 = [  3.5380, 5.5022,  8.0625, 25.6250,  37.8688]  # 四个部分的数据值

        # 设置柱状图的位置和宽度
        x = np.arange(len(categories))  # 柱状图的位置
        width = 0.35  # 柱状图的宽度

        # 定义颜色
        colors = [(20/255, 216/255, 230/255), (0/255, 0/255, 255/255), 'orange', (230/255, 180/255, 60/255) , 'green']  

        # 绘制柱状图
        bars9= ax12.bar(x, values9, width, color=colors)

        # 添加比较值的标记线
        ax12.axhline(y=self.turning_mag_z_max, color='red', linestyle='-', label='Patient Data Value')

        # 添加标签和标题
        ax12.set_xlabel('Quartiles')
        ax12.set_ylabel('Values')
        ax12.set_title('Coordination Z')
        ax12.set_xticks(x)
        ax12.set_xticklabels(categories)
        ax12.legend(loc='upper left')

        # 将 figure 转换为 QPixmap
        png_filename_12= os.path.join(tempfile.gettempdir(), 'turning_treated_mag_z.png')
        canvas_12 = FigureCanvas(fig12)
        canvas_12.print_png(png_filename_12)
        pixmap_12 = QPixmap(png_filename_12)
        # 将 QPixmap 添加到 QGraphicsScene
        item_12= QGraphicsPixmapItem(pixmap_12)
        item_12.setPos(5200, 0)
        self.scene10.addItem(item_12)
        os.remove(png_filename_12)

        #处理turning test tag(mag)
        if self.turning_mag_x_max < 4.2000:
            self.turning_mag_x_tag = '0'
        elif 4.2000 <= self.turning_mag_x_max < 6.1854:
            self.turning_mag_x_tag = '1'
        elif 6.1854 <= self.turning_mag_x_max < 9.4062:
            self.turning_mag_x_tag = '2'
        elif 9.4062 <= self.turning_mag_x_max < 15.5625:
            self.turning_mag_x_tag = '3'
        elif 15.5625 <= self.turning_mag_x_max <=  27.8125:
           self.turning_mag_x_tag = '4'
        elif self.turning_mag_x_max > 27.8125:
            self.turning_mag_x_tag = '5'
        
        if self.turning_mag_y_max < 4.6125:
            self.turning_mag_y_tag = '0'
        elif 4.6125 <= self.turning_mag_y_max < 7.0688:
            self.turning_mag_y_tag = '1'
        elif 7.0688 <= self.turning_mag_y_max < 8.9438:
            self.turning_mag_y_tag = '2'
        elif 8.9438 <= self.turning_mag_y_max < 17.8486:
            self.turning_mag_y_tag = '3'
        elif 17.8486 <= self.turning_mag_y_max <= 30.5000:
           self.turning_mag_y_tag = '4'
        elif self.turning_mag_y_max > 30.5000:
            self.turning_mag_y_tag = '5'

        if self.turning_mag_z_max < 3.5380:
            self.turning_mag_z_tag = '0'
        elif 3.5380 <= self.turning_mag_z_max < 5.5022:
            self.turning_mag_z_tag = '1'
        elif 5.5022 <= self.turning_mag_z_max < 8.0625:
            self.turning_mag_z_tag = '2'
        elif 8.0625 <= self.turning_mag_z_max < 25.6250:
            self.turning_mag_z_tag = '3'
        elif 25.6250 <= self.turning_mag_z_max <=  37.8688:
           self.turning_mag_z_tag = '4'
        elif self.turning_mag_z_max >  37.8688:
            self.turning_mag_z_tag = '5'
            
            
    def show_info(self):
        msgBox = QMessageBox()
        msgBox.setIcon(QMessageBox.Information)
        msgBox.setText(" This is the Data Analysis app designed by Hui Yan\n It is designed to be used with the Parkinson Testing app '纽蓝'\n Contact Info: \n Email: hui.yan348@dukekunshan.edu.cn \n Number: +86 15050120954")
        msgBox.setWindowTitle("Information")
        msgBox.exec_()
     
     
    #treat user's input information
    def get_user_info(self):
        self.name = self.ui.name_lineEdit.text()
        self.age = self.ui.age_lineEdit.text()
        self.address= self.ui.address_lineEdit.text()
        self.medicine1 = self.ui.medicine1_lineEdit.text()
        self.dosage1 = self.ui.dosage1_lineEdit.text()
        self.medicine2 = self.ui.medicine2_lineEdit.text()
        self.dosage2 = self.ui.dosage2_lineEdit.text()
        self.medicine3 = self.ui.medicine3_lineEdit.text()
        self.dosage3 = self.ui.dosage3_lineEdit.text()
    
    def get_user_picture(self):
        options = QFileDialog.Options()
        fileName, _ = QFileDialog.getOpenFileName(self, "QFileDialog.getOpenFileName()", "",
                                                  "Image files (*.jpg *.gif *.png)", options=options)
        if fileName:
            self.photo_address = fileName
        else:
            QMessageBox.information(self, "warning", "No picture chosen！‌")
    

    def clear_scenes(self):
        if hasattr(self, 'scene1'):
            self.scene1.clear()
        if hasattr(self, 'scene2'):
            self.scene2.clear()
        if hasattr(self, 'scene3'):
            self.scene3.clear()
        if hasattr(self, 'scene4'):
            self.scene4.clear()
        if hasattr(self, 'scene5'):
            self.scene5.clear()
        if hasattr(self, 'scene6'):
            self.scene6.clear()
        if hasattr(self, 'scene7'):
            self.scene7.clear()
        if hasattr(self, 'scene8'):
            self.scene8.clear()
        if hasattr(self, 'scene9'):
            self.scene9.clear()
        if hasattr(self, 'scene10'):
            self.scene10.clear()
            
        self.drawing_test_clicked = False
        self.rhythm_test_clicked = False
        self.walking_test_clicked = False
        self.tremor_test_clicked = False
        self.turning_test_clicked = False
    
    
    def export_pdf(self):
        #选择要导出的pdf文件
        template_path = os.path.join(self.folderpath, "template.pdf")

        # 检查是否存在 template.pdf
        if os.path.exists(template_path):
            filename, _ = QFileDialog.getSaveFileName(None, "Save PDF File", "", "PDF Files (*.pdf)")
        else:
            # 不存在，创建一个空的 template.pdf 文件
            with open(template_path, 'wb') as f:
                pass  # 创建空文件

            # 文件路径就直接使用 template.pdf
            filename = template_path


        if filename:
            printer = QPrinter()
            printer.setOutputFormat(QPrinter.PdfFormat)
            printer.setOutputFileName(filename)

            painter = QPainter(printer)

            
            # 右侧添加简单介绍
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(QRect(0,0, printer.pageRect().width(), 20),Qt.AlignCenter,"Test report of Parkinson Analyzer")
            painter.drawText(QRect(0,20, printer.pageRect().width(), 20),Qt.AlignCenter, "The data of the report is from Parkinson testing app ‘纽蓝’ ")
            
            
            
            # 设置笔属性
            pen = QPen()
            pen.setColor(Qt.black)
            pen.setWidth(2)
            painter.setPen(pen)
            # 画出水平分割线
            painter.drawLine(0, 50, printer.pageRect().width(), 50)
            # 标题
            font = QFont("Arial", 20)
            font.setBold(True)
            painter.setFont(font)
            today = QDate.currentDate().toString("yyyy-MM-dd")

            # 拼接内容
            text = f"Parkinson Analysis Report ({today})"

            # 打印在同一行，居中对齐
            painter.drawText(QRect(0, 80, printer.pageRect().width(), 50), 
                            Qt.AlignCenter, 
                            text)
            
            # 第一部分：用户信息
            self.get_user_info()
            #标题
            font = QFont("Arial", 16)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(QRect(0,150, printer.pageRect().width(), 40),Qt.AlignLeft, "User Information")
            #表格部分
            #姓名
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(50,200, 100, 50),Qt.AlignCenter, "Name")
            painter.drawRect(QRect(50,200, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(150,200, 150, 50),Qt.AlignCenter, self.name)
            painter.drawRect(QRect(150,200, 150, 50))
            #年龄
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(300, 200, 100, 50),Qt.AlignCenter, "Age")
            painter.drawRect(QRect(300,200, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(400,200, 100, 50),Qt.AlignCenter, self.age)
            painter.drawRect(QRect(400,200, 100, 50))
            #住址
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(500,200, 100, 50),Qt.AlignCenter, "Address")
            painter.drawRect(QRect(500,200, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(600,200, 250, 50),Qt.AlignCenter, self.address)
            painter.drawRect(QRect(600,200, 250, 50))
            #用药
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(50,250, 150, 150),Qt.AlignCenter, "Pharmacy")
            painter.drawRect(QRect(50,250, 150, 150))
            #药物1
            painter.drawText(QRect(200,250, 100, 50),Qt.AlignCenter, "Medicine 1")
            painter.drawRect(QRect(200,250, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(300,250, 150, 50),Qt.AlignCenter, self.medicine1)
            painter.drawRect(QRect(300,250, 150, 50))
            #用量1
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(450,250, 100, 50),Qt.AlignCenter, "Dosage 1")
            painter.drawRect(QRect(450,250, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(550,250, 150, 50),Qt.AlignCenter, self.dosage1)
            painter.drawRect(QRect(550,250, 150, 50))
            #药物2
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(200,300, 100, 50),Qt.AlignCenter, "Medicine 2")
            painter.drawRect(QRect(200,300, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(300,300, 150, 50),Qt.AlignCenter, self.medicine2)
            painter.drawRect(QRect(300,300, 150, 50))
            #用量2
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(450,300, 100, 50),Qt.AlignCenter, "Dosage 2")
            painter.drawRect(QRect(450,300, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(550,300, 150, 50),Qt.AlignCenter, self.dosage2)
            painter.drawRect(QRect(550,300, 150, 50))
            #药物3
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(200,350, 100, 50),Qt.AlignCenter, "Medicine 3")
            painter.drawRect(QRect(200,350, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(300,350, 150, 50),Qt.AlignCenter, self.medicine3)
            painter.drawRect(QRect(300,350, 150, 50))
            #用量3
            font = QFont("Arial", 10)
            painter.setFont(font)
            painter.drawText(QRect(450,350, 100, 50),Qt.AlignCenter, "Dosage 3")
            painter.drawRect(QRect(450,350, 100, 50))
            font = QFont("Arial", 6)
            painter.setFont(font)
            painter.drawText(QRect(550,350, 150, 50),Qt.AlignCenter, self.dosage3)
            painter.drawRect(QRect(550,350, 150, 50))
            font = QFont("Arial", 10)
            painter.setFont(font)
            #照片
            if hasattr(self, 'photo_address'):
                # 打印照片在合适位置
                img = Image.open(self.photo_address)
                img_byte_arr = io.BytesIO()
                img.save(img_byte_arr, format='PNG')
                qimage = QImage()
                qimage.loadFromData(img_byte_arr.getvalue())
                pixmap = QPixmap.fromImage(qimage)
                painter.drawPixmap(700, 250, 150, 150, pixmap)
            
            painter.drawRect(QRect(700,250, 150, 150))
            
            # 第二部分：测试结果
            font = QFont("Arial", 16)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(QRect(0,450, printer.pageRect().width(), 40),Qt.AlignLeft, "Test Results and Analysis")
            #1.drawing test
            font = QFont("Arial", 14)
            font.setBold(True)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50,500, 300, 35),Qt.AlignLeft, "Drawing Test")
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,550, 200, 30),Qt.AlignLeft, "Test data")
            
            font = QFont("Arial", 12)
            painter.setFont(font)
            painter.drawText(QRect(150,600, 200, 30),Qt.AlignLeft, "Stroke")
            if self.drawing_test_clicked == True:
                painter.drawText(QRect(350,600, 150, 30),Qt.AlignCenter, str(self.drawing_stroke))
                if self.drawing_test_tag == '0':
                    drawing_stroke_judge = "below bottom line of healthy people"
                elif self.drawing_test_tag == '1':
                    drawing_stroke_judge = "between 0%-25% of healthy people"
                elif self.drawing_test_tag == '2':
                    drawing_stroke_judge = "between 25%-50% of healthy people"
                elif self.drawing_test_tag == '3':
                    drawing_stroke_judge = "between 50%-75% of healthy people"
                elif self.drawing_test_tag == '4':
                    drawing_stroke_judge = "between 75%-100% of healthy people"
                elif self.drawing_test_tag == '5':
                    drawing_stroke_judge = "above top line of healthy people"
                painter.drawText(QRect(500,600, 350, 30),Qt.AlignCenter, drawing_stroke_judge)
                
                
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,650, 200, 30),Qt.AlignLeft,  "Analysis")
            
            if self.drawing_test_clicked == True:
                font = QFont("Arial", 12)
                painter.setFont(font)
                drawing_explanation = 'the drawing test basically tests how many strikes you need to finish the clock drawing test'
                painter.drawText(QRect(100,700, 800, 30),Qt.AlignLeft, drawing_explanation)
                
                if self.drawing_test_tag == '5':
                    painter.drawText(QRect(150,730, 800, 30),Qt.AlignLeft, 'you have used more strokes than healthy people')
                    painter.drawText(QRect(150,760, 800, 30),Qt.AlignLeft, 'which indicates you may have hand tremor during the drawing process')
                    if 15 < self.drawing_stroke < 16.2:
                        painter.drawText(QRect(150,790, 800, 30),Qt.AlignLeft, 'your stroke data is within 10% over healthy people')
                        painter.drawText(QRect(150,820, 800, 30),Qt.AlignLeft, 'you may have low level of hand tremor')
                    elif 16.2 <= self.drawing_stroke < 17.4:
                        painter.drawText(QRect(150,790, 800, 30),Qt.AlignLeft, 'your stroke data is between 10%-20% over healthy people')
                        painter.drawText(QRect(150,820, 800, 30),Qt.AlignLeft, 'you may have medium level of hand tremor')
                    elif 17.4 <= self.drawing_stroke < 21:
                        painter.drawText(QRect(150,790, 800, 30),Qt.AlignLeft, 'your stroke data is between 20%-50% over healthy people')
                        painter.drawText(QRect(150,820, 800, 30),Qt.AlignLeft, 'you may have high level of hand tremor')
                    elif 21 <= self.drawing_stroke :
                        painter.drawText(QRect(150,790, 800, 30),Qt.AlignLeft, 'your stroke data is more than 50% over healthy people')
                        painter.drawText(QRect(150,820, 800, 30),Qt.AlignLeft, 'you may have severe hand tremor')
                else:
                    painter.drawText(QRect(150,730, 800, 30),Qt.AlignLeft, 'your strike data did not exceed the top line of healthy people')
                    painter.drawText(QRect(150,760, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
            
            #2.rhythm test
            font = QFont("Arial", 14)
            font.setBold(True)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50,900, 300, 35),Qt.AlignLeft, "Rhythm Test")
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,950, 200, 30),Qt.AlignLeft, "Test data")
            
            font = QFont("Arial", 12)
            painter.setFont(font)
            painter.drawText(QRect(150,1000, 200, 30),Qt.AlignLeft, "Count")
            painter.drawText(QRect(150,1030, 200, 30),Qt.AlignLeft, "Pixel to Center")
            if self.rhythm_test_clicked == True:
                painter.drawText(QRect(350,1000, 150, 30),Qt.AlignCenter, str(self.rhythm_count))
                painter.drawText(QRect(350,1030, 150, 30),Qt.AlignCenter, str(self.rhythm_pixel_to_center))
                if self.rhythm_count_tag == '0':
                    rhythm_count_judge = "below bottom line of healthy people"
                elif self.rhythm_count_tag == '1':
                    rhythm_count_judge = "between 0%-25% of healthy people"
                elif self.rhythm_count_tag == '2':
                    rhythm_count_judge = "between 25%-50% of healthy people"
                elif self.rhythm_count_tag == '3':
                    rhythm_count_judge = "between 50%-75% of healthy people"
                elif self.rhythm_count_tag == '4':
                    rhythm_count_judge = "between 75%-100% of healthy people"
                elif self.rhythm_count_tag == '5':
                    rhythm_count_judge = "above top line of healthy people"
                painter.drawText(QRect(500,1000, 350, 30),Qt.AlignCenter, rhythm_count_judge)
                if self.rhythm_pixel_tag == '0':
                    rhythm_pixel_judge = "below bottom line of healthy people"
                elif self.rhythm_pixel_tag == '1':
                    rhythm_pixel_judge = "between 0%-25% of healthy people"
                elif self.rhythm_pixel_tag == '2':
                    rhythm_pixel_judge = "between 25%-50% of healthy people"
                elif self.rhythm_pixel_tag == '3':
                    rhythm_pixel_judge = "between 50%-75% of healthy people"
                elif self.rhythm_pixel_tag == '4':
                    rhythm_pixel_judge = "between 75%-100% of healthy people"
                elif self.rhythm_pixel_tag == '5':
                    rhythm_pixel_judge = "above top line of healthy people"
                painter.drawText(QRect(500,1030, 350, 30),Qt.AlignCenter, rhythm_pixel_judge)
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,1100, 200, 30),Qt.AlignLeft, "Analysis")
            if self.rhythm_test_clicked == True:
                font = QFont("Arial", 12)
                painter.setFont(font)
                drawing_explanation = 'the rhythm test basically tests your click frequency and accuracy during the rhythm test'
                painter.drawText(QRect(100,1150, 800, 30),Qt.AlignLeft, drawing_explanation)
            
                if self.rhythm_count_tag == '0':
                    if 26 < self.rhythm_count <50:
                        painter.drawText(QRect(150,1180, 800, 30),Qt.AlignLeft, 'your count number is within 10% lower than healthy people')
                        painter.drawText(QRect(150,1210, 800, 30),Qt.AlignLeft, 'you may have low level of slow hand movement')
                    elif 2 < self.rhythm_count <=26:
                        painter.drawText(QRect(150,1180, 800, 30),Qt.AlignLeft, 'your count number is between 10%-20% lower than healthy people')
                        painter.drawText(QRect(150,1210, 800, 30),Qt.AlignLeft, 'you may have medium level of slow hand movement')
                    elif  self.rhythm_count <=2:
                        painter.drawText(QRect(150,1180, 800, 30),Qt.AlignLeft, 'your count number is between 20%-50% lower than healthy people')
                        painter.drawText(QRect(150,1210, 800, 30),Qt.AlignLeft, 'you may have high level of slow hand movement')
                elif self.rhythm_count_tag == '5':
                    if 289 < self.rhythm_count <313:
                        painter.drawText(QRect(150,1180, 800, 30),Qt.AlignLeft, 'your count number is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1210, 800, 30),Qt.AlignLeft, 'you may have low level of frequent hand movement')
                    elif 313 <= self.rhythm_count <337:
                        painter.drawText(QRect(150,1180, 800, 30),Qt.AlignLeft, 'your count number is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1210, 800, 30),Qt.AlignLeft, 'you may have medium level of frequent hand movement')
                    elif  337 <=self.rhythm_count <409:
                        painter.drawText(QRect(150,1180, 800, 30),Qt.AlignLeft, 'your count number is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1210, 800, 30),Qt.AlignLeft, 'you may have high level of frequent hand movement')
                    elif 409 <=self.rhythm_count :
                        painter.drawText(QRect(150,1180, 800, 30),Qt.AlignLeft, 'your count number is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1210, 800, 30),Qt.AlignLeft, 'you may have severe frequent hand movement')
                else:
                    painter.drawText(QRect(150,1180, 800, 30),Qt.AlignLeft, 'your count number is within the range of healthy people')
                    painter.drawText(QRect(150,1210, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.rhythm_pixel_tag == '5':
                    if 35.931 < self.rhythm_pixel_to_center <38.647:
                        painter.drawText(QRect(150,1240, 800, 30),Qt.AlignLeft, 'your pixel number is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1270, 800, 30),Qt.AlignLeft, 'you may have low level of finger tremor and poor muscle control')
                    elif 38.647 <= self.rhythm_count <41.363:
                        painter.drawText(QRect(150,1240, 800, 30),Qt.AlignLeft, 'your pixel number is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1270, 800, 30),Qt.AlignLeft, 'you may have medium level of finger tremor and poor muscle control')
                    elif  41.363 <=self.rhythm_count <49.511:
                        painter.drawText(QRect(150,1240, 800, 30),Qt.AlignLeft, 'your pixel number is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1270, 800, 30),Qt.AlignLeft, 'you may have high level of finger tremor and poor muscle control')
                    elif 49.511 <=self.rhythm_count :
                        painter.drawText(QRect(150,1240, 800, 30),Qt.AlignLeft, 'your pixel number is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1270, 800, 30),Qt.AlignLeft, 'you may have severe finger tremor and poor muscle control')
                else:
                    painter.drawText(QRect(150,1240, 800, 30),Qt.AlignLeft, 'your pixel number did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1270, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
            printer.newPage()
            printer.setResolution(QPrinter.HighResolution)
            
            
            # 右侧添加简单介绍
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(QRect(0,0, printer.pageRect().width(), 20),Qt.AlignCenter,"Test report of Parkinson Analyzer")
            painter.drawText(QRect(0,20, printer.pageRect().width(), 20),Qt.AlignCenter, "The data of the report is from Parkinson testing app ‘纽蓝’ ")
            
            
            
            # 设置笔属性
            pen = QPen()
            pen.setColor(Qt.black)
            pen.setWidth(2)
            painter.setPen(pen)
            # 画出水平分割线
            painter.drawLine(0, 50, printer.pageRect().width(), 50)
            
            # 3.walking test
            font = QFont("Arial", 14)
            font.setBold(True)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50, 75, 300, 35),Qt.AlignLeft, "Walking Test")
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,120, 200, 30),Qt.AlignLeft, "Raw data charts")
            
            if self.walking_test_clicked == True:
                painter.translate(0, 150)
                self.scene3.render(painter)
                painter.translate(0, -150)
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,400, 200, 30),Qt.AlignLeft, "Test data")
            
            font = QFont("Arial", 12)
            painter.setFont(font)
            painter.drawText(QRect(150,450, 200, 30),Qt.AlignLeft, "Acceleration(x)")
            painter.drawText(QRect(150,480, 200, 30),Qt.AlignLeft, "Acceleration(y)")
            painter.drawText(QRect(150,510, 200, 30),Qt.AlignLeft, "Acceleration(z)")
            painter.drawText(QRect(150,540, 200, 30),Qt.AlignLeft, "Gyroscope(x)")
            painter.drawText(QRect(150,570, 200, 30),Qt.AlignLeft, "Gyroscope(y)")
            painter.drawText(QRect(150,600, 200, 30),Qt.AlignLeft, "Gyroscope(z)")
            painter.drawText(QRect(150,630, 200, 30),Qt.AlignLeft, "Coordinate Gap(x)")
            painter.drawText(QRect(150,660, 200, 30),Qt.AlignLeft, "Coordinate Gap(y)")
            painter.drawText(QRect(150,690, 200, 30),Qt.AlignLeft, "Coordinate Gap(z)")
            if self.walking_test_clicked == True:
                painter.drawText(QRect(350,450, 150, 30),Qt.AlignCenter, str(self.walking_acc_x_avg))
                painter.drawText(QRect(350,480, 150, 30),Qt.AlignCenter, str(self.walking_acc_y_avg))
                painter.drawText(QRect(350,510, 150, 30),Qt.AlignCenter, str(self.walking_acc_z_avg))
                painter.drawText(QRect(350,540, 150, 30),Qt.AlignCenter, str(self.walking_gyro_x_avg))
                painter.drawText(QRect(350,570, 150, 30),Qt.AlignCenter, str(self.walking_gyro_y_avg))
                painter.drawText(QRect(350,600, 150, 30),Qt.AlignCenter, str(self.walking_gyro_z_avg))
                painter.drawText(QRect(350,630, 150, 30),Qt.AlignCenter, str(self.walking_mag_x_max))
                painter.drawText(QRect(350,660, 150, 30),Qt.AlignCenter, str(self.walking_mag_y_max))
                painter.drawText(QRect(350,690, 150, 30),Qt.AlignCenter, str(self.walking_mag_z_max))
                if self.walking_acc_x_tag == '0':
                    walking_acc_x_judge = "below bottom line of healthy people"
                elif self.walking_acc_x_tag == '1':
                    walking_acc_x_judge = "between 0%-25% of healthy people"
                elif self.walking_acc_x_tag == '2':
                    walking_acc_x_judge = "between 25%-50% of healthy people"
                elif self.walking_acc_x_tag == '3':
                    walking_acc_x_judge = "between 50%-75% of healthy people"
                elif self.walking_acc_x_tag == '4':
                    walking_acc_x_judge = "between 75%-100% of healthy people"
                elif self.walking_acc_x_tag == '5':
                    walking_acc_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,450, 350, 30),Qt.AlignCenter, walking_acc_x_judge)
                if self.walking_acc_y_tag == '0':
                    walking_acc_y_judge = "below bottom line of healthy people"
                elif self.walking_acc_y_tag == '1':
                    walking_acc_y_judge = "between 0%-25% of healthy people"
                elif self.walking_acc_y_tag == '2':
                    walking_acc_y_judge = "between 25%-50% of healthy people"
                elif self.walking_acc_y_tag == '3':
                    walking_acc_y_judge = "between 50%-75% of healthy people"
                elif self.walking_acc_y_tag == '4':
                    walking_acc_y_judge = "between 75%-100% of healthy people"
                elif self.walking_acc_y_tag == '5':
                    walking_acc_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,480, 350, 30),Qt.AlignCenter, walking_acc_y_judge)
                if self.walking_acc_z_tag == '0':
                    walking_acc_z_judge = "below bottom line of healthy people"
                elif self.walking_acc_z_tag == '1':
                    walking_acc_z_judge = "between 0%-25% of healthy people"
                elif self.walking_acc_z_tag == '2':
                    walking_acc_z_judge = "between 25%-50% of healthy people"
                elif self.walking_acc_z_tag == '3':
                    walking_acc_z_judge = "between 50%-75% of healthy people"
                elif self.walking_acc_z_tag == '4':
                    walking_acc_z_judge = "between 75%-100% of healthy people"
                elif self.walking_acc_z_tag == '5':
                    walking_acc_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,510, 350, 30),Qt.AlignCenter, walking_acc_z_judge)
                if self.walking_gyro_x_tag == '0':
                    walking_gyro_x_judge = "below bottom line of healthy people"
                elif self.walking_gyro_x_tag == '1':
                    walking_gyro_x_judge = "between 0%-25% of healthy people"
                elif self.walking_gyro_x_tag == '2':
                    walking_gyro_x_judge = "between 25%-50% of healthy people"
                elif self.walking_gyro_x_tag == '3':
                    walking_gyro_x_judge = "between 50%-75% of healthy people"
                elif self.walking_gyro_x_tag == '4':
                    walking_gyro_x_judge = "between 75%-100% of healthy people"
                elif self.walking_gyro_x_tag == '5':
                    walking_gyro_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,540, 350, 30),Qt.AlignCenter, walking_gyro_x_judge)
                if self.walking_gyro_y_tag == '0':
                    walking_gyro_y_judge = "below bottom line of healthy people"
                elif self.walking_gyro_y_tag == '1':
                    walking_gyro_y_judge = "between 0%-25% of healthy people"
                elif self.walking_gyro_y_tag == '2':
                    walking_gyro_y_judge = "between 25%-50% of healthy people"
                elif self.walking_gyro_y_tag == '3':
                    walking_gyro_y_judge = "between 50%-75% of healthy people"
                elif self.walking_gyro_y_tag == '4':
                    walking_gyro_y_judge = "between 75%-100% of healthy people"
                elif self.walking_gyro_y_tag == '5':
                    walking_gyro_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,570, 350, 30),Qt.AlignCenter, walking_gyro_y_judge)
                if self.walking_gyro_z_tag == '0':
                    walking_gyro_z_judge = "below bottom line of healthy people"
                elif self.walking_gyro_z_tag == '1':
                    walking_gyro_z_judge = "between 0%-25% of healthy people"
                elif self.walking_gyro_z_tag == '2':
                    walking_gyro_z_judge = "between 25%-50% of healthy people"
                elif self.walking_gyro_z_tag == '3':
                    walking_gyro_z_judge = "between 50%-75% of healthy people"
                elif self.walking_gyro_z_tag == '4':
                    walking_gyro_z_judge = "between 75%-100% of healthy people"
                elif self.walking_gyro_z_tag == '5':
                    walking_gyro_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,600, 350, 30),Qt.AlignCenter, walking_gyro_z_judge)
                if self.walking_mag_x_tag == '0':
                    walking_mag_x_judge = "below bottom line of healthy people"
                elif self.walking_mag_x_tag == '1':
                    walking_mag_x_judge = "between 0%-25% of healthy people"
                elif self.walking_mag_x_tag == '2':
                    walking_mag_x_judge = "between 25%-50% of healthy people"
                elif self.walking_mag_x_tag == '3':
                    walking_mag_x_judge = "between 50%-75% of healthy people"
                elif self.walking_mag_x_tag == '4':
                    walking_mag_x_judge = "between 75%-100% of healthy people"
                elif self.walking_mag_x_tag == '5':
                    walking_mag_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,630, 350, 30),Qt.AlignCenter, walking_mag_x_judge)
                if self.walking_mag_y_tag == '0':
                    walking_mag_y_judge = "below bottom line of healthy people"
                elif self.walking_mag_y_tag == '1':
                    walking_mag_y_judge = "between 0%-25% of healthy people"
                elif self.walking_mag_y_tag == '2':
                    walking_mag_y_judge = "between 25%-50% of healthy people"
                elif self.walking_mag_y_tag == '3':
                    walking_mag_y_judge = "between 50%-75% of healthy people"
                elif self.walking_mag_y_tag == '4':
                    walking_mag_y_judge = "between 75%-100% of healthy people"
                elif self.walking_mag_y_tag == '5':
                    walking_mag_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,660, 350, 30),Qt.AlignCenter, walking_mag_y_judge)
                if self.walking_mag_z_tag == '0':
                    walking_mag_z_judge = "below bottom line of healthy people"
                elif self.walking_mag_z_tag == '1':
                    walking_mag_z_judge = "between 0%-25% of healthy people"
                elif self.walking_mag_z_tag == '2':
                    walking_mag_z_judge = "between 25%-50% of healthy people"
                elif self.walking_mag_z_tag == '3':
                    walking_mag_z_judge = "between 50%-75% of healthy people"
                elif self.walking_mag_z_tag == '4':
                    walking_mag_z_judge = "between 75%-100% of healthy people"
                elif self.walking_mag_z_tag == '5':
                    walking_mag_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,690, 350, 30),Qt.AlignCenter, walking_mag_z_judge)
               
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,730, 200, 30),Qt.AlignLeft, "Analysis")
            if self.walking_test_clicked == True:
                font = QFont("Arial", 12)
                painter.setFont(font)
                walking_explanation = 'the walking test basically tests your body balance during the walking test'
                painter.drawText(QRect(100,780, 800, 30),Qt.AlignLeft, walking_explanation)
                #acc
                if self.walking_acc_x_tag == '0':
                    if -0.4189 < self.walking_acc_x_avg <= -0.3184:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is within 10% lower than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have low level of slow movement')
                    elif -0.5194 < self.walking_acc_x_avg <= -0.4189:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 10%-20% lower than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have medium level of slow movement')
                    elif  -0.8209 < self.walking_acc_x_avg <= -0.5194:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 20%-50% lower than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have high level of slow movement')
                    elif  self.walking_acc_x_avg <= -0.8209:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is more than 50% lower than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have severe slow movement')
                elif self.walking_acc_x_tag == '5':
                    if 0.6867 < self.walking_acc_x_avg <= 0.7872:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have low level of quick movement')
                    elif 0.7872 < self.walking_acc_x_avg <=0.8877:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have medium level of quick movement')
                    elif  0.8877 <self.walking_acc_x_avg <= 1.1892:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have high level of quick movement')
                    elif  self.walking_acc_x_avg > 1.1892:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have severe quick movement')
                else:
                    painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is within the range of healthy people')
                    painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.walking_acc_y_tag == '5':
                    if 0.0745 < self.walking_acc_y_avg <= 0.2228:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have low level of left-right body shaking')
                    elif 0.2228 < self.walking_acc_y_avg <=0.3711:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have medium level of left-right body shaking')
                    elif  0.3711 <self.walking_acc_y_avg <= 0.816:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have high level of left-right body shaking')
                    elif  self.walking_acc_y_avg > 0.816:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have severe left-right body shaking')
                else:
                    painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                    
                if self.walking_acc_z_tag == '5':
                    if 0.5012< self.walking_acc_z_avg <= 0.5974:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have low level of body unstability like knee bending')
                    elif 0.5974 < self.walking_acc_z_avg <=0.6936:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have medium level of body unstability like knee bending')
                    elif  0.6936 <self.walking_acc_z_avg <= 0.9822:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have high level of body unstability like knee bending')
                    elif  self.walking_acc_z_avg > 0.9822:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have severe body unstability like knee bending')
                else:
                    painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                #gyro
                if self.walking_gyro_x_tag == '5':
                    if 0.1197 < self.walking_gyro_x_avg <= 0.1672:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have low level of unsteady pace and poor muscle control')
                    elif 0.1672 < self.walking_gyro_x_avg <=0.2147:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have medium level of unsteady pace and poor muscle control')
                    elif  0.2147 <self.walking_gyro_x_avg <= 0.3572:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have high level of unsteady pace and poor muscle control')
                    elif  self.walking_gyro_x_avg > 0.3572:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have severe unsteady pace and poor muscle control')
                else:
                    painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                    
                if self.walking_gyro_y_tag == '5':
                    if 0.4537 < self.walking_gyro_y_avg <= 0.5504:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have low level of poor left-right body control and risk of falling')
                    elif 0.5504 < self.walking_gyro_y_avg <=0.6471:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have medium level of poor left-right body control and risk of falling')
                    elif  0.6471 <self.walking_gyro_y_avg <= 0.9372:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have high level of poor left-right body control and risk of falling')
                    elif  self.walking_gyro_y_avg > 0.9372:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have severe poor left-right body control and risk of falling')
                else:
                    painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.walking_gyro_z_tag == '5':
                    if 0.1076 < self.walking_gyro_z_avg<= 0.127:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have low level of poor up-down body control and risk of falling')
                    elif 0.127 < self.walking_gyro_z_avg <=0.1464:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have medium level of poor up-down body control and risk of falling')
                    elif  0.1464 <self.walking_gyro_z_avg <= 0.2046:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have high level of poor up-down body control and risk of falling')
                    elif  self.walking_gyro_z_avg > 0.2046:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have severe poor up-down body control and risk of falling')
                else:
                    painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                #mag
                if self.walking_mag_x_tag == '5':
                    if 35.2875 < self.walking_mag_x_max <= 38.3441:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have low level of unsteady forward-backward body control')
                    elif 38.3441 < self.walking_mag_x_max <=41.4007:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have medium level of unsteady forward-backward body control')
                    elif  41.4007 <self.walking_mag_x_max <= 50.5705:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have high level of unsteady forward-backward body control')
                    elif  self.walking_mag_x_max > 50.5705:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have severe unsteady forward-backward body control')
                else:
                    painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.walking_mag_y_tag == '5':
                    if 33.7696 < self.walking_mag_y_max <= 36.733:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have low level of unsteady left-right body control')
                    elif 36.733 < self.walking_mag_y_max <=39.6964:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have medium level of unsteady left-right body control')
                    elif  39.6964 <self.walking_mag_y_max <= 48.5866:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have high level of unsteady left-right body control')
                    elif  self.walking_mag_y_max > 48.5866:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have severe unsteady left-right body control')
                else:
                    painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.walking_mag_z_tag == '5':
                    if 30.4375 < self.walking_mag_z_max <= 32.9847:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have low level of unsteady up-down body control')
                    elif 32.9847 < self.walking_mag_z_max <=35.5379:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have medium level of unsteady up-down body control')
                    elif 35.5379 <self.walking_mag_z_max <= 43.1735:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have high level of unsteady up-down body control')
                    elif  self.walking_mag_z_max > 43.1735:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have severe unsteady up-down body control')
                else:
                    painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
            
            
            printer.newPage()
            printer.setResolution(QPrinter.HighResolution)
            
            
            # 右侧添加简单介绍
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(QRect(0,0, printer.pageRect().width(), 20),Qt.AlignCenter,"Test report of Parkinson Analyzer")
            painter.drawText(QRect(0,20, printer.pageRect().width(), 20),Qt.AlignCenter, "The data of the report is from Parkinson testing app ‘纽蓝’ ")
            
            
            
            # 设置笔属性
            pen = QPen()
            pen.setColor(Qt.black)
            pen.setWidth(2)
            painter.setPen(pen)
            # 画出水平分割线
            painter.drawLine(0, 50, printer.pageRect().width(), 50)
            
            # 3.postural tremor test
            font = QFont("Arial", 14)
            font.setBold(True)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50, 75, 300, 35),Qt.AlignLeft, "Postural Tremor Test")
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,120, 200, 30),Qt.AlignLeft, "Raw data charts")
            
            if self.tremor_test_clicked == True:
                painter.translate(0, 150)
                self.scene5.render(painter)
                painter.translate(0, -150)
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,400, 200, 30),Qt.AlignLeft, "Test data")
            
            font = QFont("Arial", 12)
            painter.setFont(font)
            painter.drawText(QRect(150,450, 200, 30),Qt.AlignLeft, "Acceleration(x)")
            painter.drawText(QRect(150,480, 200, 30),Qt.AlignLeft, "Acceleration(y)")
            painter.drawText(QRect(150,510, 200, 30),Qt.AlignLeft, "Acceleration(z)")
            painter.drawText(QRect(150,540, 200, 30),Qt.AlignLeft, "Gyroscope(x)")
            painter.drawText(QRect(150,570, 200, 30),Qt.AlignLeft, "Gyroscope(y)")
            painter.drawText(QRect(150,600, 200, 30),Qt.AlignLeft, "Gyroscope(z)")
            painter.drawText(QRect(150,630, 200, 30),Qt.AlignLeft, "Coordinate Gap(x)")
            painter.drawText(QRect(150,660, 200, 30),Qt.AlignLeft, "Coordinate Gap(y)")
            painter.drawText(QRect(150,690, 200, 30),Qt.AlignLeft, "Coordinate Gap(z)")
            if self.tremor_test_clicked == True:
                painter.drawText(QRect(350,450, 150, 30),Qt.AlignCenter, str(self.postural_tremor_acc_x_avg))
                painter.drawText(QRect(350,480, 150, 30),Qt.AlignCenter, str(self.postural_tremor_acc_y_avg))
                painter.drawText(QRect(350,510, 150, 30),Qt.AlignCenter, str(self.postural_tremor_acc_z_avg))
                painter.drawText(QRect(350,540, 150, 30),Qt.AlignCenter, str(self.postural_tremor_gyro_x_avg))
                painter.drawText(QRect(350,570, 150, 30),Qt.AlignCenter, str(self.postural_tremor_gyro_y_avg))
                painter.drawText(QRect(350,600, 150, 30),Qt.AlignCenter, str(self.postural_tremor_gyro_z_avg))
                painter.drawText(QRect(350,630, 150, 30),Qt.AlignCenter, str(self.postural_tremor_mag_x_max))
                painter.drawText(QRect(350,660, 150, 30),Qt.AlignCenter, str(self.postural_tremor_mag_y_max))
                painter.drawText(QRect(350,690, 150, 30),Qt.AlignCenter, str(self.postural_tremor_mag_z_max))
                if self.postural_tremor_acc_x_tag == '0':
                    postural_tremor_acc_x_judge = "below bottom line of healthy people"
                elif self.postural_tremor_acc_x_tag == '1':
                    postural_tremor_acc_x_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_acc_x_tag == '2':
                    postural_tremor_acc_x_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_acc_x_tag == '3':
                    postural_tremor_acc_x_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_acc_x_tag == '4':
                    postural_tremor_acc_x_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_acc_x_tag == '5':
                    postural_tremor_acc_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,450, 350, 30),Qt.AlignCenter, postural_tremor_acc_x_judge)
                if self.postural_tremor_acc_y_tag == '0':
                    postural_tremor_acc_y_judge = "below bottom line of healthy people"
                elif self.postural_tremor_acc_y_tag == '1':
                    postural_tremor_acc_y_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_acc_y_tag == '2':
                    postural_tremor_acc_y_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_acc_y_tag == '3':
                    postural_tremor_acc_y_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_acc_y_tag == '4':
                    postural_tremor_acc_y_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_acc_y_tag == '5':
                    postural_tremor_acc_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,480, 350, 30),Qt.AlignCenter, postural_tremor_acc_y_judge)
                if self.postural_tremor_acc_z_tag == '0':
                    postural_tremor_acc_z_judge = "below bottom line of healthy people"
                elif self.postural_tremor_acc_z_tag == '1':
                    postural_tremor_acc_z_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_acc_z_tag == '2':
                    postural_tremor_acc_z_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_acc_z_tag == '3':
                    postural_tremor_acc_z_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_acc_z_tag == '4':
                    postural_tremor_acc_z_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_acc_z_tag == '5':
                    postural_tremor_acc_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,510, 350, 30),Qt.AlignCenter, postural_tremor_acc_z_judge)
                if self.postural_tremor_gyro_x_tag == '0':
                    postural_tremor_gyro_x_judge = "below bottom line of healthy people"
                elif self.postural_tremor_gyro_x_tag == '1':
                    postural_tremor_gyro_x_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_gyro_x_tag == '2':
                    postural_tremor_gyro_x_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_gyro_x_tag == '3':
                    postural_tremor_gyro_x_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_gyro_x_tag == '4':
                    postural_tremor_gyro_x_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_gyro_x_tag == '5':
                    postural_tremor_gyro_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,540, 350, 30),Qt.AlignCenter, postural_tremor_gyro_x_judge)
                if self.postural_tremor_gyro_y_tag == '0':
                    postural_tremor_gyro_y_judge = "below bottom line of healthy people"
                elif self.postural_tremor_gyro_y_tag == '1':
                    postural_tremor_gyro_y_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_gyro_y_tag == '2':
                    postural_tremor_gyro_y_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_gyro_y_tag == '3':
                    postural_tremor_gyro_y_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_gyro_y_tag == '4':
                    postural_tremor_gyro_y_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_gyro_y_tag == '5':
                    postural_tremor_gyro_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,570, 350, 30),Qt.AlignCenter, postural_tremor_gyro_y_judge)
                if self.postural_tremor_gyro_z_tag == '0':
                    postural_tremor_gyro_z_judge = "below bottom line of healthy people"
                elif self.postural_tremor_gyro_z_tag == '1':
                    postural_tremor_gyro_z_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_gyro_z_tag == '2':
                    postural_tremor_gyro_z_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_gyro_z_tag == '3':
                    postural_tremor_gyro_z_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_gyro_z_tag == '4':
                    postural_tremor_gyro_z_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_gyro_z_tag == '5':
                    postural_tremor_gyro_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,600, 350, 30),Qt.AlignCenter, postural_tremor_gyro_z_judge)
                if self.postural_tremor_mag_x_tag == '0':
                    postural_tremor_mag_x_judge = "below bottom line of healthy people"
                elif self.postural_tremor_mag_x_tag == '1':
                    postural_tremor_mag_x_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_mag_x_tag == '2':
                    postural_tremor_mag_x_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_mag_x_tag == '3':
                    postural_tremor_mag_x_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_mag_x_tag == '4':
                    postural_tremor_mag_x_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_mag_x_tag == '5':
                    postural_tremor_mag_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,630, 350, 30),Qt.AlignCenter, postural_tremor_mag_x_judge)
                if self.postural_tremor_mag_y_tag == '0':
                    postural_tremor_mag_y_judge = "below bottom line of healthy people"
                elif self.postural_tremor_mag_y_tag == '1':
                    postural_tremor_mag_y_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_mag_y_tag == '2':
                    postural_tremor_mag_y_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_mag_y_tag == '3':
                    postural_tremor_mag_y_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_mag_y_tag == '4':
                    postural_tremor_mag_y_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_mag_y_tag == '5':
                    postural_tremor_mag_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,660, 350, 30),Qt.AlignCenter, postural_tremor_mag_y_judge)
                if self.postural_tremor_mag_z_tag == '0':
                    postural_tremor_mag_z_judge = "below bottom line of healthy people"
                elif self.postural_tremor_mag_z_tag == '1':
                    postural_tremor_mag_z_judge = "between 0%-25% of healthy people"
                elif self.postural_tremor_mag_z_tag == '2':
                    postural_tremor_mag_z_judge = "between 25%-50% of healthy people"
                elif self.postural_tremor_mag_z_tag == '3':
                    postural_tremor_mag_z_judge = "between 50%-75% of healthy people"
                elif self.postural_tremor_mag_z_tag == '4':
                    postural_tremor_mag_z_judge = "between 75%-100% of healthy people"
                elif self.postural_tremor_mag_z_tag == '5':
                    postural_tremor_mag_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,690, 350, 30),Qt.AlignCenter, postural_tremor_mag_z_judge)    
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,730, 200, 30),Qt.AlignLeft, "Analysis")
            if self.tremor_test_clicked == True:
                font = QFont("Arial", 12)
                painter.setFont(font)
                postural_tremor_explanation = 'the postural tremor test tests your arm shaking and muscle control when arm straight'
                painter.drawText(QRect(100,780, 800, 30),Qt.AlignLeft, postural_tremor_explanation)
                #acc
                if self.postural_tremor_acc_x_tag == '5':
                    if 0.2018 < self.postural_tremor_acc_x_avg <= 0.2433:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have low level of forward-backward arm movement and poor arm muscle control')
                    elif 0.2433 < self.postural_tremor_acc_x_avg <=0.2848:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have medium level of forward-backward arm movement and poor arm muscle control')
                    elif  0.2848 <self.postural_tremor_acc_x_avg <= 0.4093:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have high level of forward-backward arm movement and poor arm muscle control')
                    elif  self.postural_tremor_acc_x_avg > 0.4093:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have severe forward-backward arm movement and poor arm muscle control')
                else:
                    painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.postural_tremor_acc_y_tag == '5':
                    if 0.2445 < self.postural_tremor_acc_y_avg <= 0.2925:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have low level of left-right arm movement and poor arm muscle control')
                    elif 0.2925 < self.postural_tremor_acc_y_avg <=0.3405:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have medium level of left-right arm movement and poor arm muscle control')
                    elif  0.3405 <self.postural_tremor_acc_y_avg <= 0.4845:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have high level of left-right arm movement and poor arm muscle control')
                    elif  self.postural_tremor_acc_y_avg > 0.4845:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have severe left-right arm movement and poor arm muscle control')
                else:
                    painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                    
                if self.postural_tremor_acc_z_tag == '5':
                    if 0.2365< self.postural_tremor_acc_z_avg <= 0.2914:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have low level of up-down arm movement and poor arm muscle control')
                    elif 0.2914 < self.postural_tremor_acc_z_avg <=0.3463:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have medium level of up-down arm movement and poor arm muscle control')
                    elif  0.3463 <self.postural_tremor_acc_z_avg <= 0.511:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have high level of up-down arm movement and poor arm muscle control')
                    elif  self.postural_tremor_acc_z_avg > 0.511:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have severe up-down arm movement and poor arm muscle control')
                else:
                    painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                #gyro
                if self.postural_tremor_gyro_x_tag == '5':
                    if 0.1651 < self.postural_tremor_gyro_x_avg <= 0.1851:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have low level of forward-backward arm shaking')
                    elif 0.1851 < self.postural_tremor_gyro_x_avg <=0.2051:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have medium level of forward-backward arm shaking')
                    elif  0.2051 <self.postural_tremor_gyro_x_avg <= 0.2651:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have high level of forward-backward arm shaking')
                    elif  self.postural_tremor_gyro_x_avg > 0.2651:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have severe forward-backward arm shaking')
                else:
                    painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                    
                if self.postural_tremor_gyro_y_tag == '5':
                    if 0.1881 < self.postural_tremor_gyro_y_avg <= 0.2319:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have low level of left-right arm shaking')
                    elif 0.2319 < self.postural_tremor_gyro_y_avg <=0.2757:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have medium level of left-right arm shaking')
                    elif  0.2757 <self.postural_tremor_gyro_y_avg <= 0.4071:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have high level of left-right arm shaking')
                    elif  self.postural_tremor_gyro_y_avg > 0.4071:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have severe left-right arm shaking')
                else:
                    painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.postural_tremor_gyro_z_tag == '5':
                    if 0.1541 < self.postural_tremor_gyro_z_avg<= 0.1773:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have low level of up-down arm shaking')
                    elif 0.1773 < self.postural_tremor_gyro_z_avg <=0.2005:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have medium level of up-down arm shaking')
                    elif  0.2005 <self.postural_tremor_gyro_z_avg <= 0.2701:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have high level of up-down arm shaking')
                    elif  self.postural_tremor_gyro_z_avg > 0.2701:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have severe up-down arm shaking')
                else:
                    painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                #mag
                if self.postural_tremor_mag_x_tag == '5':
                    if 26.875 < self.postural_tremor_mag_x_max <= 29.2419:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have low level of quick forward-backward arm swing')
                    elif 29.2419 < self.postural_tremor_mag_x_max <=31.6088:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have medium level of quick forward-backward arm swing')
                    elif 31.6088 <self.postural_tremor_mag_x_max <= 38.7095:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have high level of quick forward-backward arm swing')
                    elif  self.postural_tremor_mag_x_max > 38.7095:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have severe quick forward-backward arm swing')
                else:
                    painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.postural_tremor_mag_y_tag == '5':
                    if 34.4284 < self.postural_tremor_mag_y_max <= 37.6846:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have low level of quick left-right arm swing')
                    elif 37.6846 < self.postural_tremor_mag_y_max <=40.9408:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have medium level of quick left-right arm swing')
                    elif  40.9408 <self.postural_tremor_mag_y_max <= 50.7094:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have high level of quick left-right arm swing')
                    elif  self.postural_tremor_mag_y_max > 50.7094:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have severe quick left-right arm swing')
                else:
                    painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.postural_tremor_mag_z_tag == '5':
                    if 44.8125 < self.postural_tremor_mag_z_max <= 49.0406:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have low level of quick up-down arm swing')
                    elif 49.0406 < self.postural_tremor_mag_z_max <=53.2687:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have medium level of quick up-down arm swing')
                    elif 53.2687 <self.postural_tremor_mag_z_max <= 65.953:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have high level of quick up-down arm swing')
                    elif  self.postural_tremor_mag_z_max > 65.953:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have severe quick up-down arm swing')
                else:
                    painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
            
        
            printer.newPage()
            printer.setResolution(QPrinter.HighResolution)
            
            
            
            # 右侧添加简单介绍
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(QRect(0,0, printer.pageRect().width(), 20),Qt.AlignCenter,"Test report of Parkinson Analyzer")
            painter.drawText(QRect(0,20, printer.pageRect().width(), 20),Qt.AlignCenter, "The data of the report is from Parkinson testing app ‘纽蓝’ ")
            
            
            
            # 设置笔属性
            pen = QPen()
            pen.setColor(Qt.black)
            pen.setWidth(2)
            painter.setPen(pen)
            # 画出水平分割线
            painter.drawLine(0, 50, printer.pageRect().width(), 50)    
            
            #4.static tremor test
            font = QFont("Arial", 14)
            font.setBold(True)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50, 75, 300, 35),Qt.AlignLeft, "Static Tremor Test")
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,120, 200, 30),Qt.AlignLeft, "Raw data charts")
            
            if self.tremor_test_clicked == True:
                painter.translate(0, 150)
                self.scene7.render(painter)
                painter.translate(0, -150)
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,400, 200, 30),Qt.AlignLeft, "Test data")
            
            font = QFont("Arial", 12)
            painter.setFont(font)
            painter.drawText(QRect(150,450, 200, 30),Qt.AlignLeft, "Acceleration(x)")
            painter.drawText(QRect(150,480, 200, 30),Qt.AlignLeft, "Acceleration(y)")
            painter.drawText(QRect(150,510, 200, 30),Qt.AlignLeft, "Acceleration(z)")
            painter.drawText(QRect(150,540, 200, 30),Qt.AlignLeft, "Gyroscope(x)")
            painter.drawText(QRect(150,570, 200, 30),Qt.AlignLeft, "Gyroscope(y)")
            painter.drawText(QRect(150,600, 200, 30),Qt.AlignLeft, "Gyroscope(z)")
            painter.drawText(QRect(150,630, 200, 30),Qt.AlignLeft, "Coordinate Gap(x)")
            painter.drawText(QRect(150,660, 200, 30),Qt.AlignLeft, "Coordinate Gap(y)")
            painter.drawText(QRect(150,690, 200, 30),Qt.AlignLeft, "Coordinate Gap(z)")
            if self.tremor_test_clicked == True:
                painter.drawText(QRect(350,450, 150, 30),Qt.AlignCenter, str(self.static_tremor_acc_x_avg))
                painter.drawText(QRect(350,480, 150, 30),Qt.AlignCenter, str(self.static_tremor_acc_y_avg))
                painter.drawText(QRect(350,510, 150, 30),Qt.AlignCenter, str(self.static_tremor_acc_z_avg))
                painter.drawText(QRect(350,540, 150, 30),Qt.AlignCenter, str(self.static_tremor_gyro_x_avg))
                painter.drawText(QRect(350,570, 150, 30),Qt.AlignCenter, str(self.static_tremor_gyro_y_avg))
                painter.drawText(QRect(350,600, 150, 30),Qt.AlignCenter, str(self.static_tremor_gyro_z_avg))
                painter.drawText(QRect(350,630, 150, 30),Qt.AlignCenter, str(self.static_tremor_mag_x_max))
                painter.drawText(QRect(350,660, 150, 30),Qt.AlignCenter, str(self.static_tremor_mag_y_max))
                painter.drawText(QRect(350,690, 150, 30),Qt.AlignCenter, str(self.static_tremor_mag_z_max))
                if self.static_tremor_acc_x_tag == '0':
                    static_tremor_acc_x_judge = "below bottom line of healthy people"
                elif self.static_tremor_acc_x_tag == '1':
                    static_tremor_acc_x_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_acc_x_tag == '2':
                    static_tremor_acc_x_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_acc_x_tag == '3':
                    static_tremor_acc_x_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_acc_x_tag == '4':
                    static_tremor_acc_x_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_acc_x_tag == '5':
                    static_tremor_acc_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,450, 350, 30),Qt.AlignCenter, static_tremor_acc_x_judge)
                if self.static_tremor_acc_y_tag == '0':
                    static_tremor_acc_y_judge = "below bottom line of healthy people"
                elif self.static_tremor_acc_y_tag == '1':
                    static_tremor_acc_y_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_acc_y_tag == '2':
                    static_tremor_acc_y_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_acc_y_tag == '3':
                    static_tremor_acc_y_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_acc_y_tag == '4':
                    static_tremor_acc_y_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_acc_y_tag == '5':
                    static_tremor_acc_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,480, 350, 30),Qt.AlignCenter, static_tremor_acc_y_judge)
                if self.static_tremor_acc_z_tag == '0':
                    static_tremor_acc_z_judge = "below bottom line of healthy people"
                elif self.static_tremor_acc_z_tag == '1':
                    static_tremor_acc_z_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_acc_z_tag == '2':
                    static_tremor_acc_z_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_acc_z_tag == '3':
                    static_tremor_acc_z_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_acc_z_tag == '4':
                    static_tremor_acc_z_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_acc_z_tag == '5':
                    static_tremor_acc_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,510, 350, 30),Qt.AlignCenter, static_tremor_acc_z_judge)
                if self.static_tremor_gyro_x_tag == '0':
                    static_tremor_gyro_x_judge = "below bottom line of healthy people"
                elif self.static_tremor_gyro_x_tag == '1':
                    static_tremor_gyro_x_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_gyro_x_tag == '2':
                    static_tremor_gyro_x_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_gyro_x_tag == '3':
                    static_tremor_gyro_x_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_gyro_x_tag == '4':
                    static_tremor_gyro_x_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_gyro_x_tag == '5':
                    static_tremor_gyro_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,540, 350, 30),Qt.AlignCenter, static_tremor_gyro_x_judge)
                if self.static_tremor_gyro_y_tag == '0':
                    static_tremor_gyro_y_judge = "below bottom line of healthy people"
                elif self.static_tremor_gyro_y_tag == '1':
                    static_tremor_gyro_y_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_gyro_y_tag == '2':
                    static_tremor_gyro_y_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_gyro_y_tag == '3':
                    static_tremor_gyro_y_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_gyro_y_tag == '4':
                    static_tremor_gyro_y_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_gyro_y_tag == '5':
                    static_tremor_gyro_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,570, 350, 30),Qt.AlignCenter, static_tremor_gyro_y_judge)
                if self.static_tremor_gyro_z_tag == '0':
                    static_tremor_gyro_z_judge = "below bottom line of healthy people"
                elif self.static_tremor_gyro_z_tag == '1':
                    static_tremor_gyro_z_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_gyro_z_tag == '2':
                    static_tremor_gyro_z_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_gyro_z_tag == '3':
                    static_tremor_gyro_z_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_gyro_z_tag == '4':
                    static_tremor_gyro_z_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_gyro_z_tag == '5':
                    static_tremor_gyro_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,600, 350, 30),Qt.AlignCenter, static_tremor_gyro_z_judge)
                if self.static_tremor_mag_x_tag == '0':
                    static_tremor_mag_x_judge = "below bottom line of healthy people"
                elif self.static_tremor_mag_x_tag == '1':
                    static_tremor_mag_x_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_mag_x_tag == '2':
                    static_tremor_mag_x_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_mag_x_tag == '3':
                    static_tremor_mag_x_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_mag_x_tag == '4':
                    static_tremor_mag_x_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_mag_x_tag == '5':
                    static_tremor_mag_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,630, 350, 30),Qt.AlignCenter, static_tremor_mag_x_judge)
                if self.static_tremor_mag_y_tag == '0':
                    static_tremor_mag_y_judge = "below bottom line of healthy people"
                elif self.static_tremor_mag_y_tag == '1':
                    static_tremor_mag_y_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_mag_y_tag == '2':
                    static_tremor_mag_y_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_mag_y_tag == '3':
                    static_tremor_mag_y_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_mag_y_tag == '4':
                    static_tremor_mag_y_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_mag_y_tag == '5':
                    static_tremor_mag_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,660, 350, 30),Qt.AlignCenter, static_tremor_mag_y_judge)
                if self.static_tremor_mag_z_tag == '0':
                    static_tremor_mag_z_judge = "below bottom line of healthy people"
                elif self.static_tremor_mag_z_tag == '1':
                    static_tremor_mag_z_judge = "between 0%-25% of healthy people"
                elif self.static_tremor_mag_z_tag == '2':
                    static_tremor_mag_z_judge = "between 25%-50% of healthy people"
                elif self.static_tremor_mag_z_tag == '3':
                    static_tremor_mag_z_judge = "between 50%-75% of healthy people"
                elif self.static_tremor_mag_z_tag == '4':
                    static_tremor_mag_z_judge = "between 75%-100% of healthy people"
                elif self.static_tremor_mag_z_tag == '5':
                    static_tremor_mag_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,690, 350, 30),Qt.AlignCenter, static_tremor_mag_z_judge)
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,730, 200, 30),Qt.AlignLeft, "Analysis")
            if self.tremor_test_clicked == True:
                font = QFont("Arial", 12)
                painter.setFont(font)
                static_tremor_explanation = 'the static tremor test tests your ability of hand and wrist muscle control during the test'
                painter.drawText(QRect(100,780, 800, 30),Qt.AlignLeft, static_tremor_explanation)
                #acc
                if self.static_tremor_acc_x_tag == '5':
                    if 0.3451 < self.static_tremor_acc_x_avg <= 0.3884:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have low level of forward-backward wrist movement and poor wrist muscle control')
                    elif 0.3884 < self.static_tremor_acc_x_avg <=0.4317:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have medium level of forward-backward wrist movement and poor wrist muscle control')
                    elif  0.4317 <self.static_tremor_acc_x_avg <= 0.5616:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have high level of forward-backward wrist movement and poor wrist muscle control')
                    elif  self.static_tremor_acc_x_avg > 0.5616:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have severe forward-backward wrist movement and poor wrist muscle control')
                else:
                    painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.static_tremor_acc_y_tag == '5':
                    if 0.1078 < self.static_tremor_acc_y_avg <= 0.133:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have low level of left-right wrist movement and poor wrist muscle control')
                    elif 0.133 < self.static_tremor_acc_y_avg <=0.1582:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have medium level of left-right wrist movement and poor wrist muscle control')
                    elif  0.1582 <self.static_tremor_acc_y_avg <= 0.2338:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have high level of left-right wrist movement and poor wrist muscle control')
                    elif  self.static_tremor_acc_y_avg > 0.2338:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have severe left-right wrist movement and poor wrist muscle control')
                else:
                    painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                    
                if self.static_tremor_acc_z_tag == '5':
                    if 0.0781< self.static_tremor_acc_z_avg <= 0.0991:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have low level of up-down wrist movement and poor wrist muscle control')
                    elif 0.0991 < self.static_tremor_acc_z_avg <=0.1201:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have medium level of up-down wrist movement and poor wrist muscle control')
                    elif  0.1201 <self.static_tremor_acc_z_avg <= 0.1831:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have high level of up-down wrist movement and poor wrist muscle control')
                    elif  self.static_tremor_acc_z_avg > 0.1831:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have severe up-down wrist movement and poor wrist muscle control')
                else:
                    painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                #gyro
                if self.static_tremor_gyro_x_tag == '5':
                    if 0.1215 < self.static_tremor_gyro_x_avg <= 0.1397:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have low level of forward-backward wrist shaking')
                    elif 0.1397 < self.static_tremor_gyro_x_avg <=0.1579:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have medium level of forward-backward wrist shaking')
                    elif  0.1579 <self.static_tremor_gyro_x_avg <= 0.2125:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have high level of forward-backward wrist shaking')
                    elif  self.static_tremor_gyro_x_avg > 0.2125:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have severe forward-backward wrist shaking')
                else:
                    painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                    
                if self.static_tremor_gyro_y_tag == '5':
                    if 0.0148 < self.static_tremor_gyro_y_avg <= 0.0407:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have low level of left-right wrist shaking')
                    elif 0.0407 < self.static_tremor_gyro_y_avg <=0.0666:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have medium level of left-right wrist shaking')
                    elif  0.0666 <self.static_tremor_gyro_y_avg <= 0.1443:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have high level of left-right wrist shaking')
                    elif  self.static_tremor_gyro_y_avg > 0.1443:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have severe left-right wrist shaking')
                else:
                    painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.static_tremor_gyro_z_tag == '5':
                    if 0.0515 < self.static_tremor_gyro_z_avg<= 0.06:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have low level of up-down wrist shaking')
                    elif 0.06 < self.static_tremor_gyro_z_avg <=0.0685:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have medium level of up-down wrist shaking')
                    elif  0.0685 <self.static_tremor_gyro_z_avg <= 0.094:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have high level of up-down wrist shaking')
                    elif  self.static_tremor_gyro_z_avg > 0.094:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have severe up-down wrist shaking')
                else:
                    painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                #mag
                if self.static_tremor_mag_x_tag == '5':
                    if 9.25 < self.static_tremor_mag_x_max <= 10.1433:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have low level of quick forward-backward wrist swing')
                    elif 10.1433 < self.static_tremor_mag_x_max <=11.0366:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have medium level of quick forward-backward wrist swing')
                    elif 11.0366 <self.static_tremor_mag_x_max <= 13.7165:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have high level of quick forward-backward wrist swing')
                    elif  self.static_tremor_mag_x_max > 13.7165:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have severe quick forward-backward wrist swing')
                else:
                    painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.static_tremor_mag_y_tag == '5':
                    if 10.875 < self.static_tremor_mag_y_max <= 11.9503:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have low level of quick left-right wrist swing')
                    elif 11.9503 < self.static_tremor_mag_y_max <=13.0256:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have medium level of quick left-right wrist swing')
                    elif  13.0256 <self.static_tremor_mag_y_max <= 16.2515:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have high level of quick left-right wrist swing')
                    elif  self.static_tremor_mag_y_max > 16.2515:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have severe quick left-right wrist swing')
                else:
                    painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.static_tremor_mag_z_tag == '5':
                    if 16.9375 < self.static_tremor_mag_z_max <= 18.602:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have low level of quick up-down wrist swing')
                    elif 18.602 < self.static_tremor_mag_z_max <=20.2665:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have medium level of quick up-down wrist swing')
                    elif 20.2665 <self.static_tremor_mag_z_max <= 25.26:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have high level of quick up-down wrist swing')
                    elif  self.static_tremor_mag_z_max > 25.26:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have severe quick up-down wrist swing')
                else:
                    painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
            
            
            printer.newPage()
            printer.setResolution(QPrinter.HighResolution)
            
            
            
            # 右侧添加简单介绍
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(QRect(0,0, printer.pageRect().width(), 20),Qt.AlignCenter,"Test report of Parkinson Analyzer")
            painter.drawText(QRect(0,20, printer.pageRect().width(), 20),Qt.AlignCenter, "The data of the report is from Parkinson testing app ‘纽蓝’ ")
            
            
            
            # 设置笔属性
            pen = QPen()
            pen.setColor(Qt.black)
            pen.setWidth(2)
            painter.setPen(pen)
            # 画出水平分割线
            painter.drawLine(0, 50, printer.pageRect().width(), 50) 
            
            # 5.turning test
            font = QFont("Arial", 14)
            font.setBold(True)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50, 75, 300, 35),Qt.AlignLeft, "Turning Test")
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,120, 200, 30),Qt.AlignLeft, "Raw data charts")
            
            if self.turning_test_clicked == True:
                painter.translate(0, 150)
                self.scene9.render(painter)
                painter.translate(0, -150)
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,400, 200, 30),Qt.AlignLeft, "Test data")
            
            font = QFont("Arial", 12)
            painter.setFont(font)
            painter.drawText(QRect(150,450, 200, 30),Qt.AlignLeft, "Acceleration(x)")
            painter.drawText(QRect(150,480, 200, 30),Qt.AlignLeft, "Acceleration(y)")
            painter.drawText(QRect(150,510, 200, 30),Qt.AlignLeft, "Acceleration(z)")
            painter.drawText(QRect(150,540, 200, 30),Qt.AlignLeft, "Gyroscope(x)")
            painter.drawText(QRect(150,570, 200, 30),Qt.AlignLeft, "Gyroscope(y)")
            painter.drawText(QRect(150,600, 200, 30),Qt.AlignLeft, "Gyroscope(z)")
            painter.drawText(QRect(150,630, 200, 30),Qt.AlignLeft, "Coordinate Gap(x)")
            painter.drawText(QRect(150,660, 200, 30),Qt.AlignLeft, "Coordinate Gap(y)")
            painter.drawText(QRect(150,690, 200, 30),Qt.AlignLeft, "Coordinate Gap(z)")
            if self.turning_test_clicked == True:
                painter.drawText(QRect(350,450, 150, 30),Qt.AlignCenter, str(self.turning_acc_x_avg))
                painter.drawText(QRect(350,480, 150, 30),Qt.AlignCenter, str(self.turning_acc_y_avg))
                painter.drawText(QRect(350,510, 150, 30),Qt.AlignCenter, str(self.turning_acc_z_avg))
                painter.drawText(QRect(350,540, 150, 30),Qt.AlignCenter, str(self.turning_gyro_x_avg))
                painter.drawText(QRect(350,570, 150, 30),Qt.AlignCenter, str(self.turning_gyro_y_avg))
                painter.drawText(QRect(350,600, 150, 30),Qt.AlignCenter, str(self.turning_gyro_z_avg))
                painter.drawText(QRect(350,630, 150, 30),Qt.AlignCenter, str(self.turning_mag_x_max))
                painter.drawText(QRect(350,660, 150, 30),Qt.AlignCenter, str(self.turning_mag_y_max))
                painter.drawText(QRect(350,690, 150, 30),Qt.AlignCenter, str(self.turning_mag_z_max))
                if self.turning_acc_x_tag == '0':
                    turning_acc_x_judge = "below bottom line of healthy people"
                elif self.turning_acc_x_tag == '1':
                    turning_acc_x_judge = "between 0%-25% of healthy people"
                elif self.turning_acc_x_tag == '2':
                    turning_acc_x_judge = "between 25%-50% of healthy people"
                elif self.turning_acc_x_tag == '3':
                    turning_acc_x_judge = "between 50%-75% of healthy people"
                elif self.turning_acc_x_tag == '4':
                    turning_acc_x_judge = "between 75%-100% of healthy people"
                elif self.turning_acc_x_tag == '5':
                    turning_acc_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,450, 350, 30),Qt.AlignCenter, turning_acc_x_judge)
                if self.turning_acc_y_tag == '0':
                    turning_acc_y_judge = "below bottom line of healthy people"
                elif self.turning_acc_y_tag == '1':
                    turning_acc_y_judge = "between 0%-25% of healthy people"
                elif self.turning_acc_y_tag == '2':
                    turning_acc_y_judge = "between 25%-50% of healthy people"
                elif self.turning_acc_y_tag == '3':
                    turning_acc_y_judge = "between 50%-75% of healthy people"
                elif self.turning_acc_y_tag == '4':
                    turning_acc_y_judge = "between 75%-100% of healthy people"
                elif self.turning_acc_y_tag == '5':
                    turning_acc_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,480, 350, 30),Qt.AlignCenter, turning_acc_y_judge)
                if self.turning_acc_z_tag == '0':
                    turning_acc_z_judge = "below bottom line of healthy people"
                elif self.turning_acc_z_tag == '1':
                    turning_acc_z_judge = "between 0%-25% of healthy people"
                elif self.turning_acc_z_tag == '2':
                    turning_acc_z_judge = "between 25%-50% of healthy people"
                elif self.turning_acc_z_tag == '3':
                    turning_acc_z_judge = "between 50%-75% of healthy people"
                elif self.turning_acc_z_tag == '4':
                    turning_acc_z_judge = "between 75%-100% of healthy people"
                elif self.turning_acc_z_tag == '5':
                    turning_acc_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,510, 350, 30),Qt.AlignCenter, turning_acc_z_judge)
                if self.turning_gyro_x_tag == '0':
                    turning_gyro_x_judge = "below bottom line of healthy people"
                elif self.turning_gyro_x_tag == '1':
                    turning_gyro_x_judge = "between 0%-25% of healthy people"
                elif self.turning_gyro_x_tag == '2':
                    turning_gyro_x_judge = "between 25%-50% of healthy people"
                elif self.turning_gyro_x_tag == '3':
                    turning_gyro_x_judge = "between 50%-75% of healthy people"
                elif self.turning_gyro_x_tag == '4':
                    turning_gyro_x_judge = "between 75%-100% of healthy people"
                elif self.turning_gyro_x_tag == '5':
                    turning_gyro_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,540, 350, 30),Qt.AlignCenter, turning_gyro_x_judge)
                if self.turning_gyro_y_tag == '0':
                    turning_gyro_y_judge = "below bottom line of healthy people"
                elif self.turning_gyro_y_tag == '1':
                    turning_gyro_y_judge = "between 0%-25% of healthy people"
                elif self.turning_gyro_y_tag == '2':
                    turning_gyro_y_judge = "between 25%-50% of healthy people"
                elif self.turning_gyro_y_tag == '3':
                    turning_gyro_y_judge = "between 50%-75% of healthy people"
                elif self.turning_gyro_y_tag == '4':
                    turning_gyro_y_judge = "between 75%-100% of healthy people"
                elif self.turning_gyro_y_tag == '5':
                    turning_gyro_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,570, 350, 30),Qt.AlignCenter, turning_gyro_y_judge)
                if self.turning_gyro_z_tag == '0':
                    turning_gyro_z_judge = "below bottom line of healthy people"
                elif self.turning_gyro_z_tag == '1':
                    turning_gyro_z_judge = "between 0%-25% of healthy people"
                elif self.turning_gyro_z_tag == '2':
                    turning_gyro_z_judge = "between 25%-50% of healthy people"
                elif self.turning_gyro_z_tag == '3':
                    turning_gyro_z_judge = "between 50%-75% of healthy people"
                elif self.turning_gyro_z_tag == '4':
                    turning_gyro_z_judge = "between 75%-100% of healthy people"
                elif self.turning_gyro_z_tag == '5':
                    turning_gyro_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,600, 350, 30),Qt.AlignCenter, turning_gyro_z_judge)
                if self.turning_mag_x_tag == '0':
                    turning_mag_x_judge = "below bottom line of healthy people"
                elif self.turning_mag_x_tag == '1':
                    turning_mag_x_judge = "between 0%-25% of healthy people"
                elif self.turning_mag_x_tag == '2':
                    turning_mag_x_judge = "between 25%-50% of healthy people"
                elif self.turning_mag_x_tag == '3':
                    turning_mag_x_judge = "between 50%-75% of healthy people"
                elif self.turning_mag_x_tag == '4':
                    turning_mag_x_judge = "between 75%-100% of healthy people"
                elif self.turning_mag_x_tag == '5':
                    turning_mag_x_judge = "above top line of healthy people"
                painter.drawText(QRect(500,630, 350, 30),Qt.AlignCenter, turning_mag_x_judge)
                if self.turning_mag_y_tag == '0':
                    turning_mag_y_judge = "below bottom line of healthy people"
                elif self.turning_mag_y_tag == '1':
                    turning_mag_y_judge = "between 0%-25% of healthy people"
                elif self.turning_mag_y_tag == '2':
                    turning_mag_y_judge = "between 25%-50% of healthy people"
                elif self.turning_mag_y_tag == '3':
                    turning_mag_y_judge = "between 50%-75% of healthy people"
                elif self.turning_mag_y_tag == '4':
                    turning_mag_y_judge = "between 75%-100% of healthy people"
                elif self.turning_mag_y_tag == '5':
                    turning_mag_y_judge = "above top line of healthy people"
                painter.drawText(QRect(500,660, 350, 30),Qt.AlignCenter, turning_mag_y_judge)
                if self.turning_mag_z_tag == '0':
                    turning_mag_z_judge = "below bottom line of healthy people"
                elif self.turning_mag_z_tag == '1':
                    turning_mag_z_judge = "between 0%-25% of healthy people"
                elif self.turning_mag_z_tag == '2':
                    turning_mag_z_judge = "between 25%-50% of healthy people"
                elif self.turning_mag_z_tag == '3':
                    turning_mag_z_judge = "between 50%-75% of healthy people"
                elif self.turning_mag_z_tag == '4':
                    turning_mag_z_judge = "between 75%-100% of healthy people"
                elif self.turning_mag_z_tag == '5':
                    turning_mag_z_judge = "above top line of healthy people"
                painter.drawText(QRect(500,690, 350, 30),Qt.AlignCenter, turning_mag_z_judge)
            
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(100,730, 200, 30),Qt.AlignLeft, "Analysis")
            if self.turning_test_clicked == True:
                font = QFont("Arial", 12)
                painter.setFont(font)
                turning_tremor_explanation = 'the turning tremor test tests your ability of body coordination during walking and turning'
                painter.drawText(QRect(100,780, 800, 30),Qt.AlignLeft, turning_tremor_explanation)
                #acc
                if self.turning_acc_x_tag == '0':
                    if -0.2395 < self.turning_acc_x_avg <= -0.1980:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is within 10% lower than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have low level of slow movement when turning')
                    elif -0.281 < self.turning_acc_x_avg <= -0.2395:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 10%-20% lower than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have medium level of slow movement when turning')
                    elif  -0.4055 < self.turning_acc_x_avg <= -0.281:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 20%-50% lower than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have high level of slow movement when turning')
                    elif  self.turning_acc_x_avg <= -0.4055:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is more than 50% lower than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have severe slow movement when turning')
                elif self.turning_acc_x_tag == '5':
                    if 0.2169 < self.turning_acc_x_avg <= 0.2584:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have low level of quick movement when turning')
                    elif 0.2584 < self.turning_acc_x_avg <=0.2999:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have medium level of quick movement when turning')
                    elif  0.2999 <self.turning_acc_x_avg <= 0.4244:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have high level of quick movement when turning')
                    elif  self.turning_acc_x_avg > 0.4244:
                        painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'you may have severe quick movement when turning')
                else:
                    painter.drawText(QRect(150,810, 800, 30),Qt.AlignLeft, 'your X acceleration is within the range of healthy people')
                    painter.drawText(QRect(150,840, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.turning_acc_y_tag == '5':
                    if 0.0359 < self.turning_acc_y_avg <= 0.0633:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have low level of left-right quick movement and large gap when turning')
                    elif 0.0633 < self.turning_acc_y_avg <=0.0907:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have medium level of left-right quick movement and large gap when turning')
                    elif  0.0907 <self.turning_acc_y_avg <= 0.1729:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have high level of left-right quick movement and large gap when turning')
                    elif  self.turning_acc_y_avg > 0.1729:
                        painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'you may have severe left-right quick movement and large gap when turning')
                else:
                    painter.drawText(QRect(150,870, 800, 30),Qt.AlignLeft, 'your Y acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,900, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                    
                if self.turning_acc_z_tag == '5':
                    if 0.1815< self.turning_acc_z_avg <= 0.2101:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is within 10% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have low level of up-down quick movement like knee bending')
                    elif 0.2101 < self.turning_acc_z_avg <=0.2387:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have medium level of up-down quick movement like knee bending')
                    elif  0.2387 <self.turning_acc_z_avg <= 0.3245:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have high level of up-down quick movement like knee bending')
                    elif  self.turning_acc_z_avg > 0.3245:
                        painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'you may have severe up-down quick movement like knee bending')
                else:
                    painter.drawText(QRect(150,930, 800, 30),Qt.AlignLeft, 'your Z acceleration did not exceed top line of healthy people')
                    painter.drawText(QRect(150,960, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                #gyro
                if self.turning_gyro_x_tag == '5':
                    if 0.1181 < self.turning_gyro_x_avg <= 0.1374:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have low level of unsteady pace and poor muscle control')
                    elif 0.1374 < self.turning_gyro_x_avg <=0.1567:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have medium level of unsteady pace and poor muscle control')
                    elif  0.1567 <self.turning_gyro_x_avg <= 0.2146:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have high level of unsteady pace and poor muscle control')
                    elif  self.turning_gyro_x_avg > 0.2146:
                        painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'you may have severe unsteady pace and poor muscle control')
                else:
                    painter.drawText(QRect(150,990, 800, 30),Qt.AlignLeft, 'your X gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1020, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                    
                if self.turning_gyro_y_tag == '5':
                    if 0.2453 < self.turning_gyro_y_avg <= 0.284:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have low level of poor left-right body control and risk of falling')
                    elif 0.284 < self.turning_gyro_y_avg <=0.3227:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have medium level of poor left-right body control and risk of falling')
                    elif  0.3227 <self.turning_gyro_y_avg <= 0.4388:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have high level of poor left-right body control and risk of falling')
                    elif  self.turning_gyro_y_avg > 0.4388:
                        painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'you may have severe poor left-right body control and risk of falling')
                else:
                    painter.drawText(QRect(150,1050, 800, 30),Qt.AlignLeft, 'your Y gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1080, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.turning_gyro_z_tag == '5':
                    if 0.0999 < self.turning_gyro_z_avg<= 0.122:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have low level of poor up-down body control and risk of falling')
                    elif 0.122 < self.turning_gyro_z_avg <=0.1441:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have medium level of poor up-down body control and risk of falling')
                    elif  0.1441 <self.turning_gyro_z_avg <= 0.2104:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have high level of poor up-down body control and risk of falling')
                    elif  self.turning_gyro_z_avg > 0.2104:
                        painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'you may have severe poor up-down body control and risk of falling')
                else:
                    painter.drawText(QRect(150,1110, 800, 30),Qt.AlignLeft, 'your Z gyroscope data did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1140, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                #mag
                if self.turning_mag_x_tag == '5':
                    if 27.8125 < self.turning_mag_x_max <= 30.1325:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have low level of unsteady forward-backward body control')
                    elif 30.1325 < self.turning_mag_x_max <=32.4525:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have medium level of unsteady forward-backward body control')
                    elif  32.4525 <self.turning_mag_x_max <= 39.4125:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have high level of unsteady forward-backward body control')
                    elif  self.turning_mag_x_max > 39.4125:
                        painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'you may have severe unsteady forward-backward body control')
                else:
                    painter.drawText(QRect(150,1170, 800, 30),Qt.AlignLeft, 'your X coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1200, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.turning_mag_y_tag == '5':
                    if 30.5 < self.turning_mag_y_max <= 33.0888:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have low level of poor body balance when turning')
                    elif 33.0888 < self.turning_mag_y_max <=35.6776:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have medium level of poor body balance when turning')
                    elif  35.6776 <self.turning_mag_y_max <= 43.444:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have high level of poor body balance when turning')
                    elif  self.turning_mag_y_max > 43.444:
                        painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'you may have severe poor body balance when turning')
                else:
                    painter.drawText(QRect(150,1230, 800, 30),Qt.AlignLeft, 'your Y coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1260, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
                
                if self.turning_mag_z_tag == '5':
                    if 37.8668 < self.turning_mag_z_max <= 41.2999:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is within 10% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have low level of unsteady up-down body control')
                    elif 41.2999 < self.turning_mag_z_max <=44.733:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is between 10%-20% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have medium level of unsteady up-down body control')
                    elif 44.733 <self.turning_mag_z_max <= 50.0323:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is between 20%-50% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have high level of unsteady up-down body control')
                    elif  self.turning_mag_z_max > 50.0323:
                        painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap is more than 50% higher than healthy people')
                        painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'you may have severe unsteady up-down body control')
                else:
                    painter.drawText(QRect(150,1290, 800, 30),Qt.AlignLeft, 'your Z coordinate gap did not exceed top line of healthy people')
                    painter.drawText(QRect(150,1320, 800, 30),Qt.AlignLeft, 'please keep the good performance!')
            
            
            printer.newPage()
            printer.setResolution(QPrinter.HighResolution)
            
            
            
            # 右侧添加简单介绍
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(QRect(0,0, printer.pageRect().width(), 20),Qt.AlignCenter,"Test report of Parkinson Analyzer")
            painter.drawText(QRect(0,20, printer.pageRect().width(), 20),Qt.AlignCenter, "The data of the report is from Parkinson testing app ‘纽蓝’ ")
            
            
            # 设置笔属性
            pen = QPen()
            pen.setColor(Qt.black)
            pen.setWidth(2)
            painter.setPen(pen)
            # 画出水平分割线
            painter.drawLine(0, 50, printer.pageRect().width(), 50) 
            
            
            font = QFont("Arial", 16)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(QRect(0,75, printer.pageRect().width(), 40),Qt.AlignLeft, "Comprehensive Analysis")
            
            #precise movements (hand,finger)
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50,125, 200, 30),Qt.AlignLeft, "Precise Movements")
            font = QFont("Arial", 12)
            painter.setFont(font)
            precise_movement_rate = 0
            precise_movement_judge = []
            #drawing stroke
            if self.drawing_test_clicked == True:
                if self.drawing_test_tag == '5':
                    if 15 < self.drawing_stroke < 16.2:
                        precise_movement_rate -= 1
                        painter.drawText(QRect(75,170, 900, 30),Qt.AlignLeft, 'your stroke data in drawing test is within 10% over healthy people')
                        precise_movement_judge.append('you have little difficulty doing continuous hand movements')
                    elif 16.2 <= self.drawing_stroke < 17.4:
                        precise_movement_rate -= 2
                        painter.drawText(QRect(75,170, 900, 30),Qt.AlignLeft, 'your stroke data in drawing test is between 10%-20% over healthy people')
                        precise_movement_judge.append('you have difficulty doing continuous hand movements')
                    elif 17.4 <= self.drawing_stroke < 21:
                        precise_movement_rate -= 3
                        painter.drawText(QRect(75,170, 900, 30),Qt.AlignLeft, 'your stroke data in drawing test is between 20%-50% over healthy people')
                        precise_movement_judge.append('you have high difficulty doing continuous hand movements')
                    elif 21 <= self.drawing_stroke :
                        precise_movement_rate -= 4
                        painter.drawText(QRect(75,170, 900, 30),Qt.AlignLeft, 'your stroke data in drawing test is more than 50% over healthy people')
                        precise_movement_judge.append('you have severe difficulty doing continuous hand movements')
                else:
                    painter.drawText(QRect(75,170, 900, 30),Qt.AlignLeft, 'your strike data in drawing test did not exceed the top line of healthy people')
                    precise_movement_judge.append('you are fine with doing continuous hand movements')
            else:
                painter.drawText(QRect(75,170, 900, 30),Qt.AlignLeft, 'you did not analyze drawing test of this user')
                precise_movement_judge.append('no stroke data of drawing test collected for analysis!')
            #rhythm pixel to center
            if self.rhythm_test_clicked == True:
                if self.rhythm_pixel_tag == '5':
                    if 35.931 < self.rhythm_pixel_to_center <38.647:
                        precise_movement_rate -= 1
                        painter.drawText(QRect(75,200, 900, 30),Qt.AlignLeft, 'your pixel number in rhythm test is within 10% higher than healthy people')
                        precise_movement_judge.append('you have little difficulty doing precise individual clicks')
                    elif 38.647 <= self.rhythm_count <41.363:
                        precise_movement_rate -= 2
                        painter.drawText(QRect(75,200, 900, 30),Qt.AlignLeft, 'your pixel number in rhythm test is between 10%-20% higher than healthy people')
                        precise_movement_judge.append('you have difficulty doing precise individual clicks')
                    elif  41.363 <=self.rhythm_count <49.511:
                        precise_movement_rate -= 3
                        painter.drawText(QRect(75,200, 900, 30),Qt.AlignLeft, 'your pixel number in rhythm test is between 20%-50% higher than healthy people')
                        precise_movement_judge.append('you have high difficulty doing precise individual clicks')
                    elif 49.511 <=self.rhythm_count :
                        precise_movement_rate -= 4
                        painter.drawText(QRect(75,200, 900, 30),Qt.AlignLeft, 'your pixel number in rhythm test is more than 50% higher than healthy people')
                        precise_movement_judge.append('you have severe difficulty doing precise individual clicks')
                else:
                    painter.drawText(QRect(75,200, 900, 30),Qt.AlignLeft, 'your pixel number in rhythm test did not exceed top line of healthy people')
                    precise_movement_judge.append('you are fine with doing precise individual clicks')
            else:
                painter.drawText(QRect(75,200, 900, 30),Qt.AlignLeft, 'you did not analyze rhythm test of this user')
                precise_movement_judge.append('no pixel data of rhythm test is collected for analysis!')
                
            if not (self.drawing_test_clicked == False and self.rhythm_test_clicked == False):
                font = QFont("Arial", 12)
                font.setBold(True)
                painter.setFont(font)
                precise_movement_rate_avg = int(precise_movement_rate / 2)
                if precise_movement_rate_avg == 0:
                    painter.drawText(QRect(75,250, 900, 30),Qt.AlignLeft, 'you had good performance of precise finger muscle control!')
                elif precise_movement_rate_avg == -1:
                    painter.drawText(QRect(75,250, 900, 30),Qt.AlignLeft, 'you had disappointing performance of precise finger muscle control!')
                elif precise_movement_rate_avg == -2:
                    painter.drawText(QRect(75,250, 900, 30),Qt.AlignLeft, 'you had poor performance of precise finger muscle control!')
                elif precise_movement_rate_avg == -3:
                    painter.drawText(QRect(75,250, 900, 30),Qt.AlignLeft, 'you had awful performance of precise finger muscle control!')
                elif precise_movement_rate_avg == -4:
                    painter.drawText(QRect(75,250, 900, 30),Qt.AlignLeft, 'you had terrible performance of precise finger muscle control!')
            
            for i in range(len(precise_movement_judge)):
                painter.drawText(QRect(75,280+30*i, 900, 30),Qt.AlignLeft, precise_movement_judge[i])
            
            #hand movement (wrist)
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50,380, 200, 30),Qt.AlignLeft, "Hand Movement")
            font = QFont("Arial", 12)
            painter.setFont(font)
            hand_movement_rate = 0
            hand_movement_judge = []
            
            #rhythm count
            if self.rhythm_test_clicked == True:
                if self.rhythm_count_tag == '0':
                    if 26 < self.rhythm_count <50:
                        hand_movement_rate -= 1
                        painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'your count number in rhythm test is within 10% lower than healthy people')
                        hand_movement_judge.append('you have little difficulty doing continuous clicks fast enough')
                    elif 2 < self.rhythm_count <=26:
                        hand_movement_rate -= 2
                        painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'your count number in rhythm test is between 10%-20% lower than healthy people')
                        hand_movement_judge.append('you have difficulty doing continuous clicks fast enough')
                    elif  self.rhythm_count <=2:
                        hand_movement_rate -= 3
                        painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'your count number in rhythm test is between 20%-50% lower than healthy people')
                        hand_movement_judge.append('you have high difficulty doing continuous clicks fast enough')
                elif self.rhythm_count_tag == '5':
                    if 289 < self.rhythm_count <313:
                        hand_movement_rate -= 1
                        painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'your count number in rhythm test is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from uncontrolled muscle movements')
                    elif 313 <= self.rhythm_count <337:
                        hand_movement_rate -= 2
                        painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'your count number in rhythm test is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from uncontrolled muscle movements')
                    elif  337 <=self.rhythm_count <409:
                        hand_movement_rate -= 3
                        painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'your count number in rhythm test is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from uncontrolled muscle movements')
                    elif 409 <=self.rhythm_count :
                        hand_movement_rate -= 4
                        painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'your count number in rhythm test is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from uncontrolled muscle movements')
                else:
                    painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'your count number in rhythm test is within the range of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from uncontrolled muscle movements')
            else:
                painter.drawText(QRect(75,430, 900, 30),Qt.AlignLeft, 'you did not analyze rhythm test of this user')
                hand_movement_judge.append('no count data in rhythm test is collected for analysis!')
                
            #static tremor acc
            if self.tremor_test_clicked == True:
                if self.static_tremor_acc_x_tag == '5':
                    if 0.3451 < self.static_tremor_acc_x_avg <= 0.3884:
                        hand_movement_rate -= 1
                        painter.drawText(QRect(75,460, 900, 30),Qt.AlignLeft, 'your X acceleration in static tremor test is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from forward-backward accelerations')
                    elif 0.3884 < self.static_tremor_acc_x_avg <=0.4317:
                        hand_movement_rate -= 2
                        painter.drawText(QRect(75,460, 900, 30),Qt.AlignLeft, 'your X acceleration in static tremor test is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from forward-backward accelerations')
                    elif  0.4317 <self.static_tremor_acc_x_avg <= 0.5616:
                        hand_movement_rate -= 3
                        painter.drawText(QRect(75,460, 900, 30),Qt.AlignLeft, 'your X acceleration in static tremor test is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from forward-backward accelerations')
                    elif  self.static_tremor_acc_x_avg > 0.5616:
                        hand_movement_rate -= 4
                        painter.drawText(QRect(75,460, 900, 30),Qt.AlignLeft, 'your X acceleration in static tremor test is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from forward-backward accelerations')
                else:
                    painter.drawText(QRect(75,460, 900, 30),Qt.AlignLeft, 'your X acceleration in static tremor test did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from forward-backward accelerations')
            else:
                painter.drawText(QRect(75,460, 900, 30),Qt.AlignLeft, 'you did not analyze static tremor test of this user')
                hand_movement_judge.append('no X acceleration data in static tremor test is collected for analysis!')
            
            if self.tremor_test_clicked == True:
                if self.static_tremor_acc_y_tag == '5':
                    if 0.1078 < self.static_tremor_acc_y_avg <= 0.133:
                        hand_movement_rate -= 1
                        painter.drawText(QRect(75,490, 900, 30),Qt.AlignLeft, 'your Y acceleration in static tremor test is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from left-right accelerations')
                    elif 0.133 < self.static_tremor_acc_y_avg <=0.1582:
                        hand_movement_rate -= 2
                        painter.drawText(QRect(75,490, 900, 30),Qt.AlignLeft, 'your Y acceleration in static tremor test is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from left-right accelerations')
                    elif  0.1582 <self.static_tremor_acc_y_avg <= 0.2338:
                        hand_movement_rate -= 3
                        painter.drawText(QRect(75,490, 900, 30),Qt.AlignLeft, 'your Y acceleration in static tremor test is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from left-right accelerations')
                    elif  self.static_tremor_acc_y_avg > 0.2338:
                        hand_movement_rate -= 4
                        painter.drawText(QRect(75,490, 900, 30),Qt.AlignLeft, 'your Y acceleration in static tremor test is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from left-right accelerations')
                else:
                    painter.drawText(QRect(75,490, 900, 30),Qt.AlignLeft, 'your Y acceleration in static tremor test did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from left-right accelerations')
            else:
                painter.drawText(QRect(75,490, 900, 30),Qt.AlignLeft, 'you did not analyze static tremor test of this user')
                hand_movement_judge.append('no Y acceleration data in static tremor test is collected for analysis!')
                
            if self.tremor_test_clicked == True:    
                if self.static_tremor_acc_z_tag == '5':
                    if 0.0781< self.static_tremor_acc_z_avg <= 0.0991:
                        hand_movement_rate -= 1
                        painter.drawText(QRect(75,520, 900, 30),Qt.AlignLeft, 'your Z acceleration in static tremor test is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from up-down accelerations')
                    elif 0.0991 < self.static_tremor_acc_z_avg <=0.1201:
                        hand_movement_rate -= 2
                        painter.drawText(QRect(75,520, 900, 30),Qt.AlignLeft, 'your Z acceleration in static tremor test is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from up-down accelerations')
                    elif  0.1201 <self.static_tremor_acc_z_avg <= 0.1831:
                        hand_movement_rate -= 3
                        painter.drawText(QRect(75,520, 900, 30),Qt.AlignLeft, 'your Z acceleration in static tremor test is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from up-down accelerations')
                    elif  self.static_tremor_acc_z_avg > 0.1831:
                        hand_movement_rate -= 4
                        painter.drawText(QRect(75,520, 900, 30),Qt.AlignLeft, 'your Z acceleration in static tremor test is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from up-down accelerations')
                else:
                    painter.drawText(QRect(75,520, 900, 30),Qt.AlignLeft, 'your Z acceleration in static tremor test did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from up-down accelerations')
            else:
                painter.drawText(QRect(75,520, 900, 30),Qt.AlignLeft, 'you did not analyze static tremor test of this user')
                hand_movement_judge.append('no Z acceleration data in static tremor test is collected for analysis!')        
                    
            #static tremor gyro        
            if self.tremor_test_clicked == True:
                if self.static_tremor_gyro_x_tag == '5':
                    if 0.1215 < self.static_tremor_gyro_x_avg <= 0.1397:
                        hand_movement_rate -= 1
                        painter.drawText(QRect(75,550, 900, 30),Qt.AlignLeft, 'your X gyroscope data in static tremor test is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from keeping forward-backward stable')
                    elif 0.1397 < self.static_tremor_gyro_x_avg <=0.1579:
                        hand_movement_rate -= 2
                        painter.drawText(QRect(75,550, 900, 30),Qt.AlignLeft, 'your X gyroscope data in static tremor test is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from keeping forward-backward stable')
                    elif  0.1579 <self.static_tremor_gyro_x_avg <= 0.2125:
                        hand_movement_rate -= 3
                        painter.drawText(QRect(75,550, 900, 30),Qt.AlignLeft, 'your X gyroscope data in static tremor test is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from keeping forward-backward stable')
                    elif  self.static_tremor_gyro_x_avg > 0.2125:
                        hand_movement_rate -= 4
                        painter.drawText(QRect(75,550, 900, 30),Qt.AlignLeft, 'your X gyroscope data in static tremor test is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from keeping forward-backward stable')
                else:
                    painter.drawText(QRect(75,550, 900, 30),Qt.AlignLeft, 'your X gyroscope data in static tremor test did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from keeping forward-backward stable')
            else:
                painter.drawText(QRect(75,550, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                hand_movement_judge.append('no X gyroscope data in static tremor test is collected for analysis!')  
            
            if self.tremor_test_clicked == True:
                if self.static_tremor_gyro_y_tag == '5':
                    if 0.0148 < self.static_tremor_gyro_y_avg <= 0.0407:
                        hand_movement_rate -= 1
                        painter.drawText(QRect(75,580, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in static tremor test is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from keeping left-right stable')
                    elif 0.0407 < self.static_tremor_gyro_y_avg <=0.0666:
                        hand_movement_rate -= 2
                        painter.drawText(QRect(75,580, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in static tremor test is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from keeping left-right stable')
                    elif  0.0666 <self.static_tremor_gyro_y_avg <= 0.1443:
                        hand_movement_rate -= 3
                        painter.drawText(QRect(75,580, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in static tremor test is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from keeping left-right stable')
                    elif  self.static_tremor_gyro_y_avg > 0.1443:
                        hand_movement_rate -= 4
                        painter.drawText(QRect(75,580, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in static tremor test is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from keeping left-right stable')
                else:
                    painter.drawText(QRect(75,580, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in static tremor test did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from keeping left-right stable')
            else:
                painter.drawText(QRect(75,580, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                hand_movement_judge.append('no Y gyroscope data in static tremor test is collected for analysis!') 
            
            if self.tremor_test_clicked == True:
                if self.static_tremor_gyro_z_tag == '5':
                    if 0.0515 < self.static_tremor_gyro_z_avg<= 0.06:
                        hand_movement_rate -= 1
                        painter.drawText(QRect(75,610, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in static tremor test is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from keeping up-down stable')
                    elif 0.06 < self.static_tremor_gyro_z_avg <=0.0685:
                        hand_movement_rate -= 2
                        painter.drawText(QRect(75,610, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in static tremor test is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from keeping up-down stable')
                    elif  0.0685 <self.static_tremor_gyro_z_avg <= 0.094:
                        hand_movement_rate -= 3
                        painter.drawText(QRect(75,610, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in static tremor test is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from keeping up-down stable')
                    elif  self.static_tremor_gyro_z_avg > 0.094:
                        hand_movement_rate -= 4
                        painter.drawText(QRect(75,610, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in static tremor test is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from keeping up-down stable')
                else:
                    painter.drawText(QRect(75,610, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in static tremor test did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from keeping up-down stable')
            else:
                painter.drawText(QRect(75,610, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                hand_movement_judge.append('no Z gyroscope data in static tremor test is collected for analysis!') 
            
            #static test mag
            if self.tremor_test_clicked == True:
                if self.static_tremor_mag_x_tag == '5':
                    if 9.25 < self.static_tremor_mag_x_max <= 10.1433:
                        painter.drawText(QRect(75,640, 900, 30),Qt.AlignLeft, 'your X coordinate gap in static tremor test is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from quick forward-backward movements')
                    elif 10.1433 < self.static_tremor_mag_x_max <=11.0366:
                        painter.drawText(QRect(75,640, 900, 30),Qt.AlignLeft, 'your X coordinate gap in static tremor test is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from quick forward-backward movements')
                    elif 11.0366 <self.static_tremor_mag_x_max <= 13.7165:
                        painter.drawText(QRect(75,640, 900, 30),Qt.AlignLeft, 'your X coordinate gap in static tremor test is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from quick forward-backward movements')
                    elif  self.static_tremor_mag_x_max > 13.7165:
                        painter.drawText(QRect(75,640, 900, 30),Qt.AlignLeft, 'your X coordinate gap in static tremor test is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from quick forward-backward movements')
                else:
                    painter.drawText(QRect(75,640, 900, 30),Qt.AlignLeft, 'your X coordinate gap in static tremor test did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from quick forward-backward movements')
            else:
                painter.drawText(QRect(75,640, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                hand_movement_judge.append('no X coordinate data in static tremor test is collected for analysis!') 
                
            if self.tremor_test_clicked == True:
                if self.static_tremor_mag_y_tag == '5':
                    if 10.875 < self.static_tremor_mag_y_max <= 11.9503:
                        painter.drawText(QRect(75,670, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in static tremor is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from quick left-right movements')
                    elif 11.9503 < self.static_tremor_mag_y_max <=13.0256:
                        painter.drawText(QRect(75,670, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in static tremor is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from quick left-right movements')
                    elif  13.0256 <self.static_tremor_mag_y_max <= 16.2515:
                        painter.drawText(QRect(75,670, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in static tremor is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from quick left-right movements')
                    elif  self.static_tremor_mag_y_max > 16.2515:
                        painter.drawText(QRect(75,670, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in static tremor is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from quick left-right movements')
                else:
                    painter.drawText(QRect(75,670, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in static tremor did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from quick left-right movements')
            else:
                painter.drawText(QRect(75,670, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                hand_movement_judge.append('no Y coordinate data in static tremor test is collected for analysis!')     
            
            if self.tremor_test_clicked == True:
                if self.static_tremor_mag_z_tag == '5':
                    if 16.9375 < self.static_tremor_mag_z_max <= 18.602:
                        painter.drawText(QRect(75,700, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in static tremor is within 10% higher than healthy people')
                        hand_movement_judge.append('you have little difficulty controlling your hand from quick up-down movements')
                    elif 18.602 < self.static_tremor_mag_z_max <=20.2665:
                        painter.drawText(QRect(75,700, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in static tremor is between 10%-20% higher than healthy people')
                        hand_movement_judge.append('you have difficulty controlling your hand from quick up-down movements')
                    elif 20.2665 <self.static_tremor_mag_z_max <= 25.26:
                        painter.drawText(QRect(75,700, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in static tremor is between 20%-50% higher than healthy people')
                        hand_movement_judge.append('you have high difficulty controlling your hand from quick up-down movements')
                    elif  self.static_tremor_mag_z_max > 25.26:
                        painter.drawText(QRect(75,700, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in static tremor is more than 50% higher than healthy people')
                        hand_movement_judge.append('you have severe difficulty controlling your hand from quick up-down movements')
                else:
                    painter.drawText(QRect(75,700, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in static tremor did not exceed top line of healthy people')
                    hand_movement_judge.append('you are fine with controlling your hand from quick up-down movements')
            else:
                painter.drawText(QRect(75,700, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                hand_movement_judge.append('no Z coordinate data in static tremor test is collected for analysis!')  
            
            
            if not (self.rhythm_test_clicked == False and self.tremor_test_clicked == False):
                font = QFont("Arial", 12)
                font.setBold(True)
                painter.setFont(font)
                hand_movement_rate_avg = int(hand_movement_rate / 10)
                if hand_movement_rate_avg== 0:
                    painter.drawText(QRect(75,750, 900, 30),Qt.AlignLeft, 'you had good performance of hand movement!')
                elif hand_movement_rate_avg == -1:
                    painter.drawText(QRect(75,750, 900, 30),Qt.AlignLeft, 'you had disappointing performance of hand movement!')
                elif hand_movement_rate_avg == -2:
                    painter.drawText(QRect(75,750, 900, 30),Qt.AlignLeft, 'you had poor performance of hand movement!')
                elif hand_movement_rate_avg == -3:
                    painter.drawText(QRect(75,750, 900, 30),Qt.AlignLeft, 'you had awful performance of hand movement!')
                elif hand_movement_rate_avg == -4:
                    painter.drawText(QRect(75,750, 900, 30),Qt.AlignLeft, 'you had terrible performance of hand movement!')
            
            for i in range(len(hand_movement_judge)):
                painter.drawText(QRect(75,780+30*i, 900, 30),Qt.AlignLeft, hand_movement_judge[i])
            
            
            printer.newPage()
            printer.setResolution(QPrinter.HighResolution)
            
            
            
            # 右侧添加简单介绍
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(QRect(0,0, printer.pageRect().width(), 20),Qt.AlignCenter,"Test report of Parkinson Analyzer")
            painter.drawText(QRect(0,20, printer.pageRect().width(), 20),Qt.AlignCenter, "The data of the report is from Parkinson testing app ‘纽蓝’ ")
            
            
            
            # 设置笔属性
            pen = QPen()
            pen.setColor(Qt.black)
            pen.setWidth(2)
            painter.setPen(pen)
            # 画出水平分割线
            painter.drawLine(0, 50, printer.pageRect().width(), 50) 
            
            #arm movement 
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50,75, 200, 30),Qt.AlignLeft, "Arm Movement")
            font = QFont("Arial", 12)
            painter.setFont(font)
            arm_movement_rate = 0
            arm_movement_judge = []
            
            #postural tremor acc
            if self.tremor_test_clicked == True:
                if self.postural_tremor_acc_x_tag == '5':
                    if 0.2018 < self.postural_tremor_acc_x_avg <= 0.2433:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X acceleration in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from forward-backward accelerations')
                    elif 0.2433 < self.postural_tremor_acc_x_avg <=0.2848:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X acceleration in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from forward-backward accelerations')
                    elif  0.2848 <self.postural_tremor_acc_x_avg <= 0.4093:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X acceleration in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from forward-backward accelerations')
                    elif  self.postural_tremor_acc_x_avg > 0.4093:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X acceleration in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from forward-backward accelerations')
                else:
                    painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X acceleration in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from forward-backward accelerations')
            else:
                painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no X acceleration data in postural tremor test is collected for analysis!') 
            
            if self.tremor_test_clicked == True:    
                if self.postural_tremor_acc_y_tag == '5':
                    if 0.2445 < self.postural_tremor_acc_y_avg <= 0.2925:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y acceleration in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from left-right accelerations')
                    elif 0.2925 < self.postural_tremor_acc_y_avg <=0.3405:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y acceleration in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from left-right accelerations')
                    elif  0.3405 <self.postural_tremor_acc_y_avg <= 0.4845:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y acceleration in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from left-right accelerations')
                    elif  self.postural_tremor_acc_y_avg > 0.4845:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y acceleration in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from left-right accelerations')
                else:
                    painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y acceleration in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from left-right accelerations')
            else:
                painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no Y acceleration data in postural tremor test is collected for analysis!') 
                
            if self.tremor_test_clicked == True:   
                if self.postural_tremor_acc_z_tag == '5':
                    if 0.2365< self.postural_tremor_acc_z_avg <= 0.2914:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z acceleration in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from up-down accelerations')
                    elif 0.2914 < self.postural_tremor_acc_z_avg <=0.3463:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z acceleration in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from up-down accelerations')
                    elif  0.3463 <self.postural_tremor_acc_z_avg <= 0.511:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z acceleration in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from up-down accelerations')
                    elif  self.postural_tremor_acc_z_avg > 0.511:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z acceleration in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from up-down accelerations')
                else:
                    painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z acceleration in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from up-down accelerations')
            else:
                painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no Z acceleration data in postural tremor test is collected for analysis!') 
            
            #postural tremor gyro
            if self.tremor_test_clicked == True:   
                if self.postural_tremor_gyro_x_tag == '5':
                    if 0.1651 < self.postural_tremor_gyro_x_avg <= 0.1851:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X gyroscope data in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from keeping forward-backward stable')
                    elif 0.1851 < self.postural_tremor_gyro_x_avg <=0.2051:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X gyroscope data in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from keeping forward-backward stable')
                    elif  0.2051 <self.postural_tremor_gyro_x_avg <= 0.2651:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X gyroscope data in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from keeping forward-backward stable')
                    elif  self.postural_tremor_gyro_x_avg > 0.2651:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X gyroscope data in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from keeping forward-backward stable')
                else:
                    painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X gyroscope data in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from keeping forward-backward stable')
            else:
                painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no X gyroscope data in postural tremor test is collected for analysis!') 
                
            if self.tremor_test_clicked == True:   
                if self.postural_tremor_gyro_y_tag == '5':
                    if 0.1881 < self.postural_tremor_gyro_y_avg <= 0.2319:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from keeping left-right stable')
                    elif 0.2319 < self.postural_tremor_gyro_y_avg <=0.2757:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from keeping left-right stable')
                    elif  0.2757 <self.postural_tremor_gyro_y_avg <= 0.4071:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,240, 900, 30), Qt.AlignLeft, 'your Y gyroscope data in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from keeping left-right stable')
                    elif  self.postural_tremor_gyro_y_avg > 0.4071:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from keeping left-right stable')
                else:
                    painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from keeping left-right stable')
            else:
                painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no Y gyroscope data in postural tremor test is collected for analysis!') 
                
            if self.tremor_test_clicked == True:   
                if self.postural_tremor_gyro_z_tag == '5':
                    if 0.1541 < self.postural_tremor_gyro_z_avg<= 0.1773:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from keeping up-down stable')
                    elif 0.1773 < self.postural_tremor_gyro_z_avg <=0.2005:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from keeping up-down stable')
                    elif  0.2005 <self.postural_tremor_gyro_z_avg <= 0.2701:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from keeping up-down stable')
                    elif  self.postural_tremor_gyro_z_avg > 0.2701:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from keeping up-down stable')
                else:
                    painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from keeping up-down stable')
            else:
                painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no Z gyroscope data in postural tremor test is collected for analysis!') 
            
            #postural tremor mag
            if self.tremor_test_clicked == True:   
                if self.postural_tremor_mag_x_tag == '5':
                    if 26.875 < self.postural_tremor_mag_x_max <= 29.2419:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X coordinate gap in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from quick forward-backward movements')
                    elif 29.2419 < self.postural_tremor_mag_x_max <=31.6088:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X coordinate gap in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from quick forward-backward movements')
                    elif 31.6088 <self.postural_tremor_mag_x_max <= 38.7095:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X coordinate gap in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from quick forward-backward movements')
                    elif  self.postural_tremor_mag_x_max > 38.7095:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X coordinate gap in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from quick forward-backward movements')
                else:
                    painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X coordinate gap in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from quick forward-backward movements')
            else:
                painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no X coordinate data in postural tremor test is collected for analysis!') 
                
            if self.tremor_test_clicked == True: 
                if self.postural_tremor_mag_y_tag == '5':
                    if 34.4284 < self.postural_tremor_mag_y_max <= 37.6846:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from quick left-right movements')
                    elif 37.6846 < self.postural_tremor_mag_y_max <=40.9408:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from quick left-right movements')
                    elif  40.9408 <self.postural_tremor_mag_y_max <= 50.7094:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from quick left-right movements')
                    elif  self.postural_tremor_mag_y_max > 50.7094:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from quick left-right movements')
                else:
                    painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from quick left-right movements')
            else:
                painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no Y coordinate data in postural tremor test is collected for analysis!') 
                    
            if self.tremor_test_clicked == True: 
                if self.postural_tremor_mag_z_tag == '5':
                    if 44.8125 < self.postural_tremor_mag_z_max <= 49.0406:
                        arm_movement_rate -= 1
                        painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in postural tremor test is within 10% higher than healthy people')
                        arm_movement_judge.append('you have little difficulty controlling your arm from quick up-down movements')
                    elif 49.0406 < self.postural_tremor_mag_z_max <=53.2687:
                        arm_movement_rate -= 2
                        painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in postural tremor test is between 10%-20% higher than healthy people')
                        arm_movement_judge.append('you have difficulty controlling your arm from quick up-down movements')
                    elif 53.2687 <self.postural_tremor_mag_z_max <= 65.953:
                        arm_movement_rate -= 3
                        painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in postural tremor test is between 20%-50% higher than healthy people')
                        arm_movement_judge.append('you have high difficulty controlling your arm from quick up-down movements')
                    elif  self.postural_tremor_mag_z_max > 65.953:
                        arm_movement_rate -= 4
                        painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in postural tremor test is more than 50% higher than healthy people')
                        arm_movement_judge.append('you have severe difficulty controlling your arm from quick up-down movements')
                else:
                    painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in postural tremor test did not exceed top line of healthy people')
                    arm_movement_judge.append('you are fine with controlling your arm from quick up-down movements')
            else:
                painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'you did not analyze tremor test of this user')
                arm_movement_judge.append('no Z coordinate data in postural tremor test is collected for analysis!') 
                    
            
            if not (self.tremor_test_clicked == False):
                font = QFont("Arial", 12)
                font.setBold(True)
                painter.setFont(font)
                arm_movement_rate_avg = int(arm_movement_rate / 9)
                if arm_movement_rate_avg== 0:
                    painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'you had good performance of arm movement!')
                elif arm_movement_rate_avg == -1:
                    painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'you had disappointing performance of arm movement!')
                elif arm_movement_rate_avg == -2:
                    painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'you had poor performance of arm movement!')
                elif arm_movement_rate_avg == -3:
                    painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'you had awful performance of arm movement!')
                elif arm_movement_rate_avg == -4:
                    painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'you had terrible performance of arm movement!')
            
            for i in range(len(arm_movement_judge)):
                painter.drawText(QRect(75,450+30*i, 900, 30),Qt.AlignLeft, arm_movement_judge[i])
            
            #leg movement
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50,750, 200, 30),Qt.AlignLeft, "Leg Movement")
            font = QFont("Arial", 12)
            painter.setFont(font)
            leg_movement_rate = 0
            leg_movement_judge = []
            
            #walking acc
            if self.walking_test_clicked == True:
                if self.walking_acc_x_tag == '0':
                    if -0.4189 < self.walking_acc_x_avg <= -0.3184:
                        leg_movement_rate -= 1
                        painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is within 10% lower than healthy people')
                        leg_movement_judge.append('you have little difficulty controlling your leg from slow forward-backward accelerations')
                    elif -0.5194 < self.walking_acc_x_avg <= -0.4189:
                        leg_movement_rate -= 2
                        painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is between 10%-20% lower than healthy people')
                        leg_movement_judge.append('you have difficulty controlling your leg from slow forward-backward accelerations')
                    elif  -0.8209 < self.walking_acc_x_avg <= -0.5194:
                        leg_movement_rate -= 3
                        painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is between 20%-50% lower than healthy people')
                        leg_movement_judge.append('you have high difficulty controlling your leg from slow forward-backward accelerations')
                    elif  self.walking_acc_x_avg <= -0.8209:
                        leg_movement_rate -= 4
                        painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is more than 50% lower than healthy people')
                        leg_movement_judge.append('you have severe difficulty controlling your leg from slow forward-backward accelerations')
                elif self.walking_acc_x_tag == '5':
                    if 0.6867 < self.walking_acc_x_avg <= 0.7872:
                        leg_movement_rate -= 1
                        painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is within 10% higher than healthy people')
                        leg_movement_judge.append('you have little difficulty controlling your leg from quick forward-backward accelerations')
                    elif 0.7872 < self.walking_acc_x_avg <=0.8877:
                        leg_movement_rate -= 2
                        painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is between 10%-20% higher than healthy people')
                        leg_movement_judge.append('you have difficulty controlling your leg from quick forward-backward accelerations')
                    elif  0.8877 <self.walking_acc_x_avg <= 1.1892:
                        leg_movement_rate -= 3
                        painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is between 20%-50% higher than healthy people')
                        leg_movement_judge.append('you have high difficulty controlling your leg from quick forward-backward accelerations')
                    elif  self.walking_acc_x_avg > 1.1892:
                        leg_movement_rate -= 4
                        painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is more than 50% higher than healthy people')
                        leg_movement_judge.append('you have severe difficulty controlling your leg from quick forward-backward accelerations')
                else:
                    painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'your X acceleration in walking test is within the range of healthy people')
                    leg_movement_judge.append('you are fine with controlling your leg from quick forward-backward accelerations')
            else:
                painter.drawText(QRect(75,800, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                leg_movement_judge.append('no X acceleration data in walking test is collected for analysis!') 
                
            if self.walking_test_clicked == True:
                if self.walking_acc_y_tag == '5':
                    if 0.0745 < self.walking_acc_y_avg <= 0.2228:
                        leg_movement_rate -= 1
                        painter.drawText(QRect(75,830, 900, 30),Qt.AlignLeft, 'your Y acceleration in walking test is within 10% higher than healthy people')
                        leg_movement_judge.append('you have little difficulty controlling your leg from quick left-right accelerations')
                    elif 0.2228 < self.walking_acc_y_avg <=0.3711:
                        leg_movement_rate -= 2
                        painter.drawText(QRect(75,830, 900, 30),Qt.AlignLeft, 'your Y acceleration in walking test is between 10%-20% higher than healthy people')
                        leg_movement_judge.append('you have difficulty controlling your leg from quick left-right accelerations')
                    elif  0.3711 <self.walking_acc_y_avg <= 0.816:
                        leg_movement_rate -= 3
                        painter.drawText(QRect(75,830, 900, 30),Qt.AlignLeft, 'your Y acceleration in walking test is between 20%-50% higher than healthy people')
                        leg_movement_judge.append('you have high difficulty controlling your leg from quick left-right accelerations')
                    elif  self.walking_acc_y_avg > 0.816:
                        leg_movement_rate -= 4
                        painter.drawText(QRect(75,830, 900, 30),Qt.AlignLeft, 'your Y acceleration in walking test is more than 50% higher than healthy people')
                        leg_movement_judge.append('you have severe difficulty controlling your leg from quick left-right accelerations')
                else:
                    painter.drawText(QRect(75,830, 900, 30),Qt.AlignLeft, 'your Y acceleration in walking test did not exceed top line of healthy people')
                    leg_movement_judge.append('you are fine with controlling your leg from quick left-right accelerations')
            else:
                painter.drawText(QRect(75,830, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                leg_movement_judge.append('no Y acceleration data in walking test is collected for analysis!') 
                
            if self.walking_test_clicked == True:
                if self.walking_acc_z_tag == '5':
                    if 0.5012< self.walking_acc_z_avg <= 0.5974:
                        leg_movement_rate -= 1
                        painter.drawText(QRect(75,860, 900, 30),Qt.AlignLeft, 'your Z acceleration in walking test is within 10% higher than healthy people')
                        leg_movement_judge.append('you have little difficulty controlling your leg from quick up-down accelerations')
                    elif 0.5974 < self.walking_acc_z_avg <=0.6936:
                        leg_movement_rate -= 2
                        painter.drawText(QRect(75,860, 900, 30),Qt.AlignLeft, 'your Z acceleration in walking test is between 10%-20% higher than healthy people')
                        leg_movement_judge.append('you have difficulty controlling your leg from quick up-down accelerations')
                    elif  0.6936 <self.walking_acc_z_avg <= 0.9822:
                        leg_movement_rate -= 3
                        painter.drawText(QRect(75,860, 900, 30),Qt.AlignLeft, 'your Z acceleration in walking test is between 20%-50% higher than healthy people')
                        leg_movement_judge.append('you have high difficulty controlling your leg from quick up-down accelerations')
                    elif  self.walking_acc_z_avg > 0.9822:
                        leg_movement_rate -= 4
                        painter.drawText(QRect(75,860, 900, 30),Qt.AlignLeft, 'your Z acceleration in walking test is more than 50% higher than healthy people')
                        leg_movement_judge.append('you have severe difficulty controlling your leg from quick up-down accelerations')
                else:
                    painter.drawText(QRect(75,860, 900, 30),Qt.AlignLeft, 'your Z acceleration in walking test did not exceed top line of healthy people')
                    leg_movement_judge.append('you are fine with controlling your leg from quick up-down accelerations')
            else:
                painter.drawText(QRect(75,860, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                leg_movement_judge.append('no Z acceleration data in walking test is collected for analysis!') 
            
            #turning acc
            if self.turning_test_clicked == True:
                if self.turning_acc_x_tag == '0':
                    if -0.2395 < self.turning_acc_x_avg <= -0.1980:
                        leg_movement_rate -= 1
                        painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is within 10% lower than healthy people')
                        leg_movement_judge.append('you have little difficulty keeping your leg forward-backward stable when turning')
                    elif -0.281 < self.turning_acc_x_avg <= -0.2395:
                        leg_movement_rate -= 2
                        painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is between 10%-20% lower than healthy people')
                        leg_movement_judge.append('you have difficulty keeping your leg forward-backward stable when turning')
                    elif  -0.4055 < self.turning_acc_x_avg <= -0.281:
                        leg_movement_rate -= 3
                        painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is between 20%-50% lower than healthy people')
                        leg_movement_judge.append('you have high difficulty keeping your leg forward-backward stable when turning')
                    elif  self.turning_acc_x_avg <= -0.4055:
                        leg_movement_rate -= 4
                        painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is more than 50% lower than healthy people')
                        leg_movement_judge.append('you have severe difficulty keeping your leg forward-backward stable when turning')
                elif self.turning_acc_x_tag == '5':
                    if 0.2169 < self.turning_acc_x_avg <= 0.2584:
                        leg_movement_rate -= 1
                        painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is within 10% higher than healthy people')
                        leg_movement_judge.append('you have little difficulty keeping your leg forward-backward stable when turning')
                    elif 0.2584 < self.turning_acc_x_avg <=0.2999:
                        leg_movement_rate -= 2
                        painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is between 10%-20% higher than healthy people')
                        leg_movement_judge.append('you have difficulty keeping your leg forward-backward stable when turning')
                    elif  0.2999 <self.turning_acc_x_avg <= 0.4244:
                        leg_movement_rate -= 3
                        painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is between 20%-50% higher than healthy people')
                        leg_movement_judge.append('you have high difficulty keeping your leg forward-backward stable when turning')
                    elif  self.turning_acc_x_avg > 0.4244:
                        leg_movement_rate -= 4
                        painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is more than 50% higher than healthy people')
                        leg_movement_judge.append('you have severe difficulty keeping your leg forward-backward stable when turning')
                else:
                    painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'your X acceleration in turning test is within the range of healthy people')
                    leg_movement_judge.append('you are fine with keeping your leg forward-backward stable when turning')
            else:
                painter.drawText(QRect(75,890, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                leg_movement_judge.append('no X acceleration data in turning test is collected for analysis!') 
                
            if self.turning_test_clicked == True:
                if self.turning_acc_y_tag == '5':
                    if 0.0359 < self.turning_acc_y_avg <= 0.0633:
                        leg_movement_rate -= 1
                        painter.drawText(QRect(75,920, 900, 30),Qt.AlignLeft, 'your Y acceleration in turning test is within 10% higher than healthy people')
                        leg_movement_judge.append('you have little difficulty keeping your leg left-right stable when turning')
                    elif 0.0633 < self.turning_acc_y_avg <=0.0907:
                        leg_movement_rate -= 2
                        painter.drawText(QRect(75,920, 900, 30),Qt.AlignLeft, 'your Y acceleration in turning test is between 10%-20% higher than healthy people')
                        leg_movement_judge.append('you have difficulty keeping your leg left-right stable when turning')
                    elif  0.0907 <self.turning_acc_y_avg <= 0.1729:
                        leg_movement_rate -= 3
                        painter.drawText(QRect(75,920, 900, 30),Qt.AlignLeft, 'your Y acceleration in turning test is between 20%-50% higher than healthy people')
                        leg_movement_judge.append('you have high difficulty keeping your leg left-right stable when turning')
                    elif  self.turning_acc_y_avg > 0.1729:
                        leg_movement_rate -= 4
                        painter.drawText(QRect(75,920, 900, 30),Qt.AlignLeft, 'your Y acceleration in turning test is more than 50% higher than healthy people')
                        leg_movement_judge.append('you have severe difficulty keeping your leg left-right stable when turning')
                else:
                    painter.drawText(QRect(75,920, 900, 30),Qt.AlignLeft, 'your Y acceleration in turning test did not exceed top line of healthy people')
                    leg_movement_judge.append('you are fine with keeping your leg left-right stable when turning')
            else:
                painter.drawText(QRect(75,920, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                leg_movement_judge.append('no Y acceleration data in turning test is collected for analysis!')
                
            if self.turning_test_clicked == True:
                if self.turning_acc_z_tag == '5':
                    if 0.1815< self.turning_acc_z_avg <= 0.2101:
                        leg_movement_rate -= 1
                        painter.drawText(QRect(75,950, 900, 30),Qt.AlignLeft, 'your Z acceleration in turning test is within 10% higher than healthy people')
                        leg_movement_judge.append('you have little difficulty keeping your leg up-down stable when turning')
                    elif 0.2101 < self.turning_acc_z_avg <=0.2387:
                        leg_movement_rate -= 2
                        painter.drawText(QRect(75,950, 900, 30),Qt.AlignLeft, 'your Z acceleration in turning test is between 10%-20% higher than healthy people')
                        leg_movement_judge.append('you have difficulty keeping your leg up-down stable when turning')
                    elif  0.2387 <self.turning_acc_z_avg <= 0.3245:
                        leg_movement_rate -= 3
                        painter.drawText(QRect(75,950, 900, 30),Qt.AlignLeft, 'your Z acceleration in turning test is between 20%-50% higher than healthy people')
                        leg_movement_judge.append('you have high difficulty keeping your leg up-down stable when turning')
                    elif  self.turning_acc_z_avg > 0.3245:
                        leg_movement_rate -= 4
                        painter.drawText(QRect(75,950, 900, 30),Qt.AlignLeft, 'your Z acceleration in turning test is more than 50% higher than healthy people')
                        leg_movement_judge.append('you have severe difficulty keeping your leg up-down stable when turning')
                else:
                    painter.drawText(QRect(75,950, 900, 30),Qt.AlignLeft, 'your Z acceleration in turning test did not exceed top line of healthy people')
                    leg_movement_judge.append('you are fine with keeping your leg up-down stable when turning')
            else:
                painter.drawText(QRect(75,950, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                leg_movement_judge.append('no Z acceleration data in turning test is collected for analysis!')
                    
            
            if not (self.walking_test_clicked == False and self.turning_test_clicked == False):
                font = QFont("Arial", 12)
                font.setBold(True)
                painter.setFont(font)
                leg_movement_rate_avg = int(leg_movement_rate / 6)
                if leg_movement_rate_avg== 0:
                    painter.drawText(QRect(75,1000, 900, 30),Qt.AlignLeft, 'you had good performance of leg movement!')
                elif leg_movement_rate_avg == -1:
                    painter.drawText(QRect(75,1000, 900, 30),Qt.AlignLeft, 'you had disappointing performance of leg movement!')
                elif leg_movement_rate_avg == -2:
                    painter.drawText(QRect(75,1000, 900, 30),Qt.AlignLeft, 'you had poor performance of leg movement!')
                elif leg_movement_rate_avg == -3:
                    painter.drawText(QRect(75,1000, 900, 30),Qt.AlignLeft, 'you had awful performance of leg movement!')
                elif leg_movement_rate_avg == -4:
                    painter.drawText(QRect(75,1000, 900, 30),Qt.AlignLeft, 'you had terrible performance of leg movement!')
            
            for i in range(len(leg_movement_judge)):
                painter.drawText(QRect(75,1030+30*i, 900, 30),Qt.AlignLeft, leg_movement_judge[i])

            
            printer.newPage()
            printer.setResolution(QPrinter.HighResolution)
            
            
            # 右侧添加简单介绍
            font = QFont("Arial", 8)
            painter.setFont(font)
            painter.drawText(QRect(0,0, printer.pageRect().width(), 20),Qt.AlignCenter,"Test report of Parkinson Analyzer")
            painter.drawText(QRect(0,20, printer.pageRect().width(), 20),Qt.AlignCenter, "The data of the report is from Parkinson testing app ‘纽蓝’ ")
            
            
            
            # 设置笔属性
            pen = QPen()
            pen.setColor(Qt.black)
            pen.setWidth(2)
            painter.setPen(pen)
            # 画出水平分割线
            painter.drawLine(0, 50, printer.pageRect().width(), 50)    
            
            #body balance (falling to left/right and forward/backward falling)
            font = QFont("Arial", 13)
            font.setItalic(True)
            painter.setFont(font)
            painter.drawText(QRect(50,75, 200, 30),Qt.AlignLeft, "Body Balance")
            font = QFont("Arial", 12)
            painter.setFont(font)
            body_balance_rate = 0
            body_balance_judge = []
            
            #walking gyro
            if self.walking_test_clicked == True:
                if self.walking_gyro_x_tag == '5':
                    if 0.1197 < self.walking_gyro_x_avg <= 0.1672:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X gyroscope data in walking test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty keeping your body forward-backward stable when walking')
                    elif 0.1672 < self.walking_gyro_x_avg <=0.2147:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X gyroscope data in walking test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty keeping your body forward-backward stable when walking')
                    elif  0.2147 <self.walking_gyro_x_avg <= 0.3572:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X gyroscope data in walking test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty keeping your body forward-backward stable when walking')
                    elif  self.walking_gyro_x_avg > 0.3572:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X gyroscope data in walking test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty keeping your body forward-backward stable when walking')
                else:
                    painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'your X gyroscope data in walking test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with keeping your body forward-backward stable when walking')
            else:
                painter.drawText(QRect(75,120, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                body_balance_judge.append('no X gyroscope data in walking test is collected for analysis!')
                
            if self.walking_test_clicked == True:
                if self.walking_gyro_y_tag == '5':
                    if 0.4537 < self.walking_gyro_y_avg <= 0.5504:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in walking test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty keeping your body left-right stable when walking')
                    elif 0.5504 < self.walking_gyro_y_avg <=0.6471:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in walking test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty keeping your body left-right stable when walking')
                    elif  0.6471 <self.walking_gyro_y_avg <= 0.9372:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in walking test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty keeping your body left-right stable when walking')
                    elif  self.walking_gyro_y_avg > 0.9372:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in walking test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty keeping your body left-right stable when walking')
                else:
                    painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in walking test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with keeping your body left-right stable when walking')
            else:
                painter.drawText(QRect(75,150, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                body_balance_judge.append('no Y gyroscope data in walking test is collected for analysis!')
                
            if self.walking_test_clicked == True:
                if self.walking_gyro_z_tag == '5':
                    if 0.1076 < self.walking_gyro_z_avg<= 0.127:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in walking test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty keeping your body up-down stable when walking')
                    elif 0.127 < self.walking_gyro_z_avg <=0.1464:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in walking test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty keeping your body up-down stable when walking')
                    elif  0.1464 <self.walking_gyro_z_avg <= 0.2046:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in walking test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty keeping your body up-down stable when walking')
                    elif  self.walking_gyro_z_avg > 0.2046:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in walking test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty keeping your body up-down stable when walking')
                else:
                    painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in walking test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with keeping your body up-down stable when walking')
            else:
                painter.drawText(QRect(75,180, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                body_balance_judge.append('no Z gyroscope data in walking test is collected for analysis!')
            
            #walking mag
            if self.walking_test_clicked == True:
                if self.walking_mag_x_tag == '5':
                    if 35.2875 < self.walking_mag_x_max <= 38.3441:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X coordinate gap in walking test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty avoiding quick forward-backward body movements when walking')
                    elif 38.3441 < self.walking_mag_x_max <=41.4007:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X coordinate gap in walking test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty avoiding quick forward-backward body movements when walking')
                    elif  41.4007 <self.walking_mag_x_max <= 50.5705:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X coordinate gap in walking test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty avoiding quick forward-backward body movements when walking')
                    elif  self.walking_mag_x_max > 50.5705:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X coordinate gap in walking test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty avoiding quick forward-backward body movements when walking')
                else:
                    painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'your X coordinate gap in walking test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with avoiding quick forward-backward body movements when walking')
            else:
                painter.drawText(QRect(75,210, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                body_balance_judge.append('no X coordinate data in walking test is collected for analysis!')
                
            if self.walking_test_clicked == True:
                if self.walking_mag_y_tag == '5':
                    if 33.7696 < self.walking_mag_y_max <= 36.733:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in walking test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty avoiding quick left-right body movements when walking')
                    elif 36.733 < self.walking_mag_y_max <=39.6964:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in walking test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty avoiding quick left-right body movements when walking')
                    elif  39.6964 <self.walking_mag_y_max <= 48.5866:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in walking test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty avoiding quick left-right body movements when walking')
                    elif  self.walking_mag_y_max > 48.5866:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in walking test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty avoiding quick left-right body movements when walking')
                else:
                    painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in walking test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with avoiding quick left-right body movements when walking')
            else:
                painter.drawText(QRect(75,240, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                body_balance_judge.append('no Y coordinate data in walking test is collected for analysis!')
                
            if self.walking_test_clicked == True:
                if self.walking_mag_z_tag == '5':
                    if 30.4375 < self.walking_mag_z_max <= 32.9847:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in walking test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty avoiding quick up-down body movements when walking')
                    elif 32.9847 < self.walking_mag_z_max <=35.5379:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in walking test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty avoiding quick up-down body movements when walking')
                    elif 35.5379 <self.walking_mag_z_max <= 43.1735:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in walking test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty avoiding quick up-down body movements when walking')
                    elif  self.walking_mag_z_max > 43.1735:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in walking test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty avoiding quick up-down body movements when walking')
                else:
                    painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in walking test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with avoiding quick up-down body movements when walking')
            else:
                painter.drawText(QRect(75,270, 900, 30),Qt.AlignLeft, 'you did not analyze walking test of this user')
                body_balance_judge.append('no Z coordinate data in walking test is collected for analysis!')
            
            #turning gyro
            if self.turning_test_clicked == True:
                if self.turning_gyro_x_tag == '5':
                    if 0.1181 < self.turning_gyro_x_avg <= 0.1374:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X gyroscope data in turning test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty keeping your body forward-backward stable when turning')
                    elif 0.1374 < self.turning_gyro_x_avg <=0.1567:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X gyroscope data in turning test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty keeping your body forward-backward stable when turning')
                    elif  0.1567 <self.turning_gyro_x_avg <= 0.2146:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X gyroscope data in turning test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty keeping your body forward-backward stable when turning')
                    elif  self.turning_gyro_x_avg > 0.2146:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X gyroscope data in turning test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty keeping your body forward-backward stable when turning')
                else:
                    painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'your X gyroscope data in turning test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with keeping your body forward-backward stable when turning')
            else:
                painter.drawText(QRect(75,300, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                body_balance_judge.append('no X gyroscope data in walking test is collected for analysis!')
             
            if self.turning_test_clicked == True:
                if self.turning_gyro_y_tag == '5':
                    if 0.2453 < self.turning_gyro_y_avg <= 0.284:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in turning test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty keeping your body left-right stable when turning')
                    elif 0.284 < self.turning_gyro_y_avg <=0.3227:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in turning test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty keeping your body left-right stable when turning')
                    elif  0.3227 <self.turning_gyro_y_avg <= 0.4388:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in turning test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty keeping your body left-right stable when turning')
                    elif  self.turning_gyro_y_avg > 0.4388:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in turning test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty keeping your body left-right stable when turning')
                else:
                    painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'your Y gyroscope data in turning test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with keeping your body left-right stable when turning')
            else:
                painter.drawText(QRect(75,330, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                body_balance_judge.append('no Y gyroscope data in walking test is collected for analysis!')
                
            if self.turning_test_clicked == True:
                if self.turning_gyro_z_tag == '5':
                    if 0.0999 < self.turning_gyro_z_avg<= 0.122:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in turning test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty keeping your body up-down stable when turning')
                    elif 0.122 < self.turning_gyro_z_avg <=0.1441:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in turning test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty keeping your body up-down stable when turning')
                    elif  0.1441 <self.turning_gyro_z_avg <= 0.2104:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in turning test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty keeping your body up-down stable when turning')
                    elif  self.turning_gyro_z_avg > 0.2104:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in turning test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty keeping your body up-down stable when turning')
                else:
                    painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'your Z gyroscope data in turning test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with keeping your body up-down stable when turning')
            else:
                painter.drawText(QRect(75,360, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                body_balance_judge.append('no Z gyroscope data in walking test is collected for analysis!')
                
            #turning mag
            if self.turning_test_clicked == True:
                if self.turning_mag_x_tag == '5':
                    if 27.8125 < self.turning_mag_x_max <= 30.1325:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,390, 900, 30),Qt.AlignLeft, 'your X coordinate gap in turning test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty avoiding quick forward-backward body movements when turning')
                    elif 30.1325 < self.turning_mag_x_max <=32.4525:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,390, 900, 30),Qt.AlignLeft, 'your X coordinate gap in turning test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty avoiding quick forward-backward body movements when turning')
                    elif  32.4525 <self.turning_mag_x_max <= 39.4125:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,390, 900, 30),Qt.AlignLeft, 'your X coordinate gap in turning test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty avoiding quick forward-backward body movements when turning')
                    elif  self.turning_mag_x_max > 39.4125:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,390, 900, 30),Qt.AlignLeft, 'your X coordinate gap in turning test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty avoiding quick forward-backward body movements when turning')
                else:
                    painter.drawText(QRect(75,390, 900, 30),Qt.AlignLeft, 'your X coordinate gap in turning test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with avoiding quick forward-backward body movements when turning')
            else:
                painter.drawText(QRect(75,390, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                body_balance_judge.append('no X coordinate data in walking test is collected for analysis!')
            
            if self.turning_test_clicked == True:
                if self.turning_mag_y_tag == '5':
                    if 30.5 < self.turning_mag_y_max <= 33.0888:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in turning test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty avoiding quick left-right body movements when turning')
                    elif 33.0888 < self.turning_mag_y_max <=35.6776:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in turning test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty avoiding quick left-right body movements when turning')
                    elif  35.6776 <self.turning_mag_y_max <= 43.444:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in turning test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty avoiding quick left-right body movements when turning')
                    elif  self.turning_mag_y_max > 43.444:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in turning test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty avoiding quick left-right body movements when turning')
                else:
                    painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'your Y coordinate gap in turning test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with avoiding quick left-right body movements when turning')
            else:
                painter.drawText(QRect(75,420, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                body_balance_judge.append('no Y coordinate data in walking test is collected for analysis!')
                
            if self.turning_test_clicked == True:
                if self.turning_mag_z_tag == '5':
                    if 37.8668 < self.turning_mag_z_max <= 41.2999:
                        body_balance_rate -= 1
                        painter.drawText(QRect(75,450, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in turning test is within 10% higher than healthy people')
                        body_balance_judge.append('you have little difficulty avoiding quick up-down body movements when turning')
                    elif 41.2999 < self.turning_mag_z_max <=44.733:
                        body_balance_rate -= 2
                        painter.drawText(QRect(75,450, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in turning test is between 10%-20% higher than healthy people')
                        body_balance_judge.append('you have difficulty avoiding quick up-down body movements when turning')
                    elif 44.733 <self.turning_mag_z_max <= 50.0323:
                        body_balance_rate -= 3
                        painter.drawText(QRect(75,450, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in turning test is between 20%-50% higher than healthy people')
                        body_balance_judge.append('you have high difficulty avoiding quick up-down body movements when turning')
                    elif  self.turning_mag_z_max > 50.0323:
                        body_balance_rate -= 4
                        painter.drawText(QRect(75,450, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in turning test is more than 50% higher than healthy people')
                        body_balance_judge.append('you have severe difficulty avoiding quick up-down body movements when turning')
                else:
                    painter.drawText(QRect(75,450, 900, 30),Qt.AlignLeft, 'your Z coordinate gap in turning test did not exceed top line of healthy people')
                    body_balance_judge.append('you are fine with avoiding quick up-down body movements when turning')
            else:
                painter.drawText(QRect(75,450, 900, 30),Qt.AlignLeft, 'you did not analyze turning test of this user')
                body_balance_judge.append('no Z coordinate data in walking test is collected for analysis!')

            
            if not (self.walking_test_clicked == False and self.turning_test_clicked == False):
                font = QFont("Arial", 12)
                font.setBold(True)
                painter.setFont(font)
                body_balance_rate_avg = int(body_balance_rate / 12)
                if body_balance_rate_avg== 0:
                    painter.drawText(QRect(75,500, 900, 30),Qt.AlignLeft, 'you had good performance of body balance!')
                elif body_balance_rate_avg == -1:
                    painter.drawText(QRect(75,500, 900, 30),Qt.AlignLeft, 'you had disappointing performance of body balance!')
                elif body_balance_rate_avg == -2:
                    painter.drawText(QRect(75,500, 900, 30),Qt.AlignLeft, 'you had poor performance of body balance!')
                elif body_balance_rate_avg == -3:
                    painter.drawText(QRect(75,500, 900, 30),Qt.AlignLeft, 'you had awful performance of body balance!')
                elif body_balance_rate_avg == -4:
                    painter.drawText(QRect(75,500, 900, 30),Qt.AlignLeft, 'you had terrible performance of body balance!')
            
            for i in range(len(body_balance_judge)):
                painter.drawText(QRect(75,530+30*i, 900, 30),Qt.AlignLeft, body_balance_judge[i])
          
            painter.end()
            QMessageBox.information(self, "Notice", "Export PDF successfully!‌")
        else:
            QMessageBox.information(self, "Notice", "No PDF file Chosen!")
            
            
    # the knowledge learning part
    def open_link(self):
        if self.ui.comboBox.currentText() == 'Causes':
            webbrowser.open('https://www.nia.nih.gov/health/parkinsons-disease/parkinsons-disease-causes-symptoms-and-treatments#causes')
        elif self.ui.comboBox.currentText() == 'Symptoms':
            webbrowser.open('https://www.nia.nih.gov/health/parkinsons-disease/parkinsons-disease-causes-symptoms-and-treatments#symptoms')
        elif self.ui.comboBox.currentText() == 'Diagnosis':
            webbrowser.open('https://www.nia.nih.gov/health/parkinsons-disease/parkinsons-disease-causes-symptoms-and-treatments#diagnosis')
        elif self.ui.comboBox.currentText() == 'Early signs':
            webbrowser.open('https://www.medicalnewstoday.com/articles/323396#early-signs')
        elif self.ui.comboBox.currentText() == 'Risk factors':
            webbrowser.open('https://www.medicalnewstoday.com/articles/323396#risk-factors')
        elif self.ui.comboBox.currentText() == 'Prevention':
            webbrowser.open('https://www.medicalnewstoday.com/articles/323396#prevention')
        elif self.ui.comboBox.currentText() == 'Treatments':
            webbrowser.open('https://www.nia.nih.gov/health/parkinsons-disease/parkinsons-disease-causes-symptoms-and-treatments#treatments')
        
